#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#Get file path
pwdpath = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwdpath + "/LaTeX/ModelTest.png" 
ResultFigure = pwdpath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
Po     = 1.000
d      = 0.050
c      = 0.200
k      = 4.000
m      = 1.000
wn     = np.sqrt(k/m)
wd     = wn*np.sqrt(1.0 - d**2)

dt     = 0.10
this   = pwdpath + '/Solution/'
time   = np.arange(dt, 25.1, dt)

#ANALYTICAL SOLUTION:
x0    = m*wn**2*1.00/k
disp  = -x0/(2*d)*(np.exp(-d*wn*time)*(np.cos(wd*time) + d/np.sqrt(1.0 - d**2)*np.sin(wd*time)) - np.cos(wn*time))*10*Po/k

disp  = np.concatenate((-time*10*Po/k/25.0,disp-10*Po/k), axis=0)
time  = np.concatenate((time,time+25.1), axis=0)

#SeismoVLAB SOLUTION:
phase1 = np.loadtxt(this + 'Phase-1/Displacement.0.out', dtype='float', skiprows=3)
phase2 = np.loadtxt(this + 'Phase-2/Displacement.0.out', dtype='float', skiprows=3)
displacement = np.concatenate((phase1,phase2), axis=0)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,10.5))
plt.plot(time, displacement[1:,2], 'r-', time, disp, 'b.')
plt.xlabel("$t \;[s]$", fontsize=30)
plt.ylabel("$U(t)$" , fontsize=30)
plt.xlim((0,50))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """The problem setting is the same as shown in Figure~\\ref{fig:Verification-model_MassSpringDashpot} and 
correspond to a mass-spring-dashpot oscillator for which $M = 1 \;[kg]$, $K = 4 \;[N/m]$, $C = 0.2 \;[N\,s/m]$. The 
nodes $(1)$, and $(2)$ have the coordinate $(x,y) = (0.0, 0.0)$. Node $(1)$ is fixed in \\textrm{X}- and \\textrm{Y}-
directions, while node (2) is fixed in \\textrm{Y}-direction. This problem tests the \\texttt{Progressive} analysis option. First, 
a static analysis with $P_0 = -10$ is applied at Node $(2)$. Then, a dynamic analysis with $P(t) = P_0 \, \sin(\omega_n \,t)$ 
with $\omega_n = 2 \;[rad/s]$ is applied to Node $(2)$. The responses are verified against analytical solution. 
Figure~\\ref{fig:Validation_Progressive_PointLoad_MassSpringDashpot} shows the displacement and reactive force responses at node (2). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.75\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Validation_Progressive_PointLoad_MassSpringDashpot}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.close()
