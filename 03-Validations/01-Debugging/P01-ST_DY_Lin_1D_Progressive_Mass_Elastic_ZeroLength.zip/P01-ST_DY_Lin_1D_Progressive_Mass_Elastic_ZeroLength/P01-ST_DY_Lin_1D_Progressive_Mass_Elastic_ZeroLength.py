"""

"""
from Core import SeismoVLAB as SVL

SVL.Options['file'     ] = 'Debugging_P01'
SVL.Options['update'   ] = 'Progressive'
SVL.Options['nparts'   ] = 1
SVL.Options['dimension'] = 2

#Create Recorder 
SVL.addRecorder(tag=1, attributes={'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [1,2]})
SVL.addRecorder(tag=2, attributes={'name': 'NODE', 'file': 'Velocity.out', 'ndps': 8, 'resp': 'vel', 'list': [1,2]})
SVL.addRecorder(tag=3, attributes={'name': 'NODE', 'file': 'Acceleration.out', 'ndps': 8, 'resp': 'accel', 'list': [1,2]})

#==============================================================================
# FIRST PHASE - STATIC LOAD
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 4.00, 'nu': 0.00, 'rho': 0.00})
SVL.addMaterial(tag=2, name='Viscous1DLinear', attributes={'eta': 0.20})

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.0, 0.0])
SVL.addNode(tag=2, ndof=2, coords=[0.0, 0.0])

#Create Mass
SVL.addMass(tag=2, dof=[1,2], vals=[1.0, 1.0])

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=2, dof=2)

#Create Element
SVL.addElement(tag=1, conn=[1, 2], name='ZeroLength1D', attributes={'material': 1, 'dir': 1})
SVL.addElement(tag=2, conn=[1, 2], name='ZeroLength1D', attributes={'material': 2, 'dir': 1})

#Create function
SVL.addFunction(tag=1, name='Constant', attributes={'mag': 10.0, 'dir': [-1.0, 0.0]})

#Create a Load
SVL.addLoad(tag=1, name='PointLoad', attributes={'fun': 1, 'type': 'Concentrated', 'list': [2]})

#Create a Combination
SVL.addCombinationCase(tag=1, name='Phase-1', attributes={'load': 1, 'factor': 1.0})

#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 251})
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles(combo=1)

#==============================================================================
# SECOND PHASE - SUPPORT MOTION
#==============================================================================
#Create function
SVL.addFunction(tag=2, name='TimeSeries', attributes={'file': 'StressLoad.txt', 'dir': [-1.0, 0.0]})

#Create a Load
SVL.addLoad(tag=2, name='PointLoad', attributes={'fun': 2, 'type': 'Concentrated', 'list': [2]})

#Create a Combination
SVL.addCombinationCase(tag=2, name='Phase-2', attributes={'load': 2, 'factor': 10.0})

#Create Analysis
SVL.addAnalysis(tag=2, attributes={'name': 'Dynamic', 'nt': 251})
SVL.addAlgorithm(tag=2, attributes={'name': 'Linear', 'nstep': 1})
SVL.addIntegrator(tag=2, attributes={'name': 'Newmark', 'dt': 0.1})
SVL.addSolver(tag=2, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=2, combo=2, attributes={'analysis': 2, 'algorithm': 2, 'integrator': 2, 'solver': 2})

#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles(combo=2)
