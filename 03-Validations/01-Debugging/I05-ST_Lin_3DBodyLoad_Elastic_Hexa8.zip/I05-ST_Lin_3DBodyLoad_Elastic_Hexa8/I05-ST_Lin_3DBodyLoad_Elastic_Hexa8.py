"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_I05'
SVL.Options['format'] = 'json'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic3DLinear', attributes={'E': 1.0E+05, 'nu': 0.30, 'rho': 25.0})

#Create Nodes (for quads)
SVL.addNode(tag=1, ndof=3, coords=[0.00, 0.00, 0.00])
SVL.addNode(tag=2, ndof=3, coords=[0.20, 0.00, 0.00])
SVL.addNode(tag=3, ndof=3, coords=[0.20, 0.00, 0.20])
SVL.addNode(tag=4, ndof=3, coords=[0.00, 0.00, 0.20])
SVL.addNode(tag=5, ndof=3, coords=[0.00, 0.20, 0.00])
SVL.addNode(tag=6, ndof=3, coords=[0.20, 0.20, 0.00])
SVL.addNode(tag=7, ndof=3, coords=[0.20, 0.20, 0.20])
SVL.addNode(tag=8, ndof=3, coords=[0.00, 0.20, 0.20])
SVL.addNode(tag=9, ndof=3, coords=[0.00, 0.40, 0.00])
SVL.addNode(tag=10, ndof=3, coords=[0.20, 0.40, 0.00])
SVL.addNode(tag=11, ndof=3, coords=[0.20, 0.40, 0.20])
SVL.addNode(tag=12, ndof=3, coords=[0.00, 0.40, 0.20])
SVL.addNode(tag=13, ndof=3, coords=[0.00, 0.60, 0.00])
SVL.addNode(tag=14, ndof=3, coords=[0.20, 0.60, 0.00])
SVL.addNode(tag=15, ndof=3, coords=[0.20, 0.60, 0.20])
SVL.addNode(tag=16, ndof=3, coords=[0.00, 0.60, 0.20])
SVL.addNode(tag=17, ndof=3, coords=[0.00, 0.80, 0.00])
SVL.addNode(tag=18, ndof=3, coords=[0.20, 0.80, 0.00])
SVL.addNode(tag=19, ndof=3, coords=[0.20, 0.80, 0.20])
SVL.addNode(tag=20, ndof=3, coords=[0.00, 0.80, 0.20])
SVL.addNode(tag=21, ndof=3, coords=[0.00, 1.00, 0.00])
SVL.addNode(tag=22, ndof=3, coords=[0.20, 1.00, 0.00])
SVL.addNode(tag=23, ndof=3, coords=[0.20, 1.00, 0.20])
SVL.addNode(tag=24, ndof=3, coords=[0.00, 1.00, 0.20])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1,2,3])
SVL.addRestrain(tag=2, dof=[1,2,3])
SVL.addRestrain(tag=3, dof=[1,2,3])
SVL.addRestrain(tag=4, dof=[1,2,3])

#Create Element
SVL.addElement(tag=1, conn=[ 1,  2,  6,  5,  4,  3,  7,  8], name='lin3DHexa8', attributes={'material': 1, 'rule': 'Gauss', 'np': 8})
SVL.addElement(tag=2, conn=[ 5,  6, 10,  9,  8,  7, 11, 12], name='lin3DHexa8', attributes={'material': 1, 'rule': 'Gauss', 'np': 8})
SVL.addElement(tag=3, conn=[ 9, 10, 14, 13, 12, 11, 15, 16], name='lin3DHexa8', attributes={'material': 1, 'rule': 'Gauss', 'np': 8})
SVL.addElement(tag=4, conn=[13, 14, 18, 17, 16, 15, 19, 20], name='lin3DHexa8', attributes={'material': 1, 'rule': 'Gauss', 'np': 8})
SVL.addElement(tag=5, conn=[17, 18, 22, 21, 20, 19, 23, 24], name='lin3DHexa8', attributes={'material': 1, 'rule': 'Gauss', 'np': 8})

#Create function
fun = {'mag': 10.00, 'dir': [0.0, 0.0, -1.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Body', 'list': [1,2,3,4,5]}
SVL.addLoad(tag=1, name='ElementLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='HexaElasticStatic', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [21,22,23,24]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Reaction.out', 'ndps': 8, 'resp': 'reaction', 'list': [1,2,3,4]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': [1]}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
