"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

P  = 8.75E5
h  = 28.0
b  = 14.0
tw = 0.725
tf = 1.200

A   = 2.0*b*tf + tw*(h - 2.0*tf)
As2 = tw*h/A
As3 = 5.0/6.0*(2.0*b*tf)/A

#Global model settings
SVL.Options['file'] = 'Debugging_D24'
SVL.Options['dimension'] = 3

SVL.addMaterial(tag=1, name='Elastic1DFiber', attributes={'E': 29000000.0, 'nu': 0.33})

#CReate Section
patch = {
    '1': {'name': 'RECTANGULAR', 'fiber': 1, 'nfibz': 12,'nfiby':  1, 'coords': [[0.0,  0.0],[b, tf]]}, 
    '2': {'name': 'RECTANGULAR', 'fiber': 1, 'nfibz':  1,'nfiby': 20, 'coords': [[0.5*(b-tw),tf],[0.5*(b+tw),h-tf]]}, 
    '3': {'name': 'RECTANGULAR', 'fiber': 1, 'nfibz': 12,'nfiby':  1, 'coords': [[0.0, h-tf],[b, h]]}
}

SVL.addSection(tag=1, name='Fib3DLineSection', model='Fiber', attributes={'patch': patch, 'b': b, 'h': h, 'kappa2': As2, 'kappa3': As3, 'ip': 10, 'theta': 0.0})

#Create Nodes
SVL.addNode(tag=1, ndof=6, coords=[  0.0, 0.0, 0.0])
SVL.addNode(tag=2, ndof=6, coords=[  7.5, 0.0, 0.0])
SVL.addNode(tag=3, ndof=6, coords=[ 15.0, 0.0, 0.0])
SVL.addNode(tag=4, ndof=6, coords=[ 30.0, 0.0, 0.0])
SVL.addNode(tag=5, ndof=6, coords=[ 45.0, 0.0, 0.0])
SVL.addNode(tag=6, ndof=6, coords=[ 60.0, 0.0, 0.0])
SVL.addNode(tag=7, ndof=6, coords=[ 80.0, 0.0, 0.0])
SVL.addNode(tag=8, ndof=6, coords=[100.0, 0.0, 0.0])

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2, 3, 4, 5, 6])

#Create Element
SVL.addElement(tag=1, conn=[1,2], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Lobatto', 'np': 5})
SVL.addElement(tag=2, conn=[2,3], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Lobatto', 'np': 5})
SVL.addElement(tag=3, conn=[3,4], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Lobatto', 'np': 5})
SVL.addElement(tag=4, conn=[4,5], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Lobatto', 'np': 5})
SVL.addElement(tag=5, conn=[5,6], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Lobatto', 'np': 5})
SVL.addElement(tag=6, conn=[6,7], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Lobatto', 'np': 5})
SVL.addElement(tag=7, conn=[7,8], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Lobatto', 'np': 5})

#Create function
SVL.addFunction(tag=1, name='TimeSerie', attributes={'file':  'Load.txt', 'dir': [0.0, 0.0, -1.0, 0.0, 0.0, 0.0]})

#Create a Load
SVL.addLoad(tag=1, name='PointLoad', attributes={'fun': 1, 'type': 'TimeSerie', 'list': [8]})

#Create a Combination
SVL.addCombinationCase(tag=1, name='Load', attributes={'load': [1], 'factor': [P]})

#Create Recorder
SVL.addRecorder(tag=1, attributes={'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [8]})
SVL.addRecorder(tag=2, attributes={'name': 'NODE', 'file': 'Reactions.out', 'ndps': 8, 'resp': 'reaction', 'list': [1]})
SVL.addRecorder(tag=3, attributes={'name': 'ELEMENT', 'file': 'SectionForces.out', 'ndps': 8, 'resp': 'Stress', 'list': [1,4,7]})
SVL.addRecorder(tag=4, attributes={'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8, 'nsamp': 1})

#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 2001})
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.01})
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#Create Run-Analysis Files
SVL.CreateRunAnalysisFiles()
