#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#Get file path
pwdpath = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwdpath + "/LaTeX/ModelTest.png" 
ResultFigure = pwdpath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
Po     = 1.000
d      = 0.050
c      = 0.200
k      = 4.000
m      = 1.000
ust    = Po/k
wn     = np.sqrt(k/m)
wd     = wn*np.sqrt(1.0 - d**2)
dt     = 0.050
this   = pwdpath + '/Solution/NodalMass/'
time   = np.arange(dt, 9.501, dt)

#ANALYTICAL SOLUTION:
force  = np.loadtxt('PointLoad.txt', dtype='float', skiprows=2)
disp1  = ust/(2.0*d)*(np.exp(-d*wn*time)*(np.cos(wd*time) + d/np.sqrt(1.0 - d**2)*np.sin(wd*time)) - np.cos(wn*time))

#SeismoVLAB SOLUTION:
disp2        = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)
acceleration = np.loadtxt(this + 'Acceleration.0.out', dtype='float', skiprows=2)
ForceSpring  = np.loadtxt(this + 'ForceSpring.0.out', dtype='float', skiprows=2)
ForceDashpot = np.loadtxt(this + 'ForceDashpot.0.out', dtype='float', skiprows=2)

Reaction = m*acceleration[:,0] + ForceSpring + ForceDashpot

#COMPUTES ERRORS:
delta1 = abs(disp1 - disp2[:,0])
delta2 = abs(force - Reaction)

#Root mean square error.
rms1 = np.sqrt(np.mean(delta1**2))
rms2 = np.sqrt(np.mean(delta2**2))

#Maximum absolute difference.
mad1 = max(delta1)
mad2 = max(delta2)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 2, 1)
plt.plot(time, disp2[:,0], 'r-', time, disp1, 'b.')
plt.xlabel("$t \;[s]$", fontsize=30)
plt.ylabel("$U_x(t)$" , fontsize=30)
plt.xlim((0,9.5))
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(time, Reaction, 'r-', time, force, 'b.')
plt.xlabel("$t\;[s]$"  , fontsize=30)
plt.ylabel("$R_{x}(t)$", fontsize=30)
plt.xlim((0,9.5))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_MassSpringDashpot} and 
correspond to a mass-spring-dashpot oscillator for which $M = 1 \;[kg]$, $K = 4 \;[N/m]$, $C = 0.2 \;[N\,s/m]$. 
This problem tests \\texttt{Point Mass} and \\texttt{ZeroLength1D}. The nodes $(1)$, and $(2)$ have the coordinate 
$(x,y) = (0.0, 0.0)$. Node $(1)$ is fixed in \\textrm{X}- and \\textrm{Y}-directions, while node (2) is fixed in 
\\textrm{Y}-direction. For dynamic analysis, the nodal force applied at node (2) is defined as 
$P(t) = 1.000 \, \sin(\omega_n \,t) \; N$, with $\omega_n = 4 \;[rad/s]$. The responses are verified against analytical 
solution. Figure~\\ref{fig:Verification_MassSpringDashpot} shows the displacement and reactive force responses at node (2). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.250 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{ZeroLength1D} with \\texttt{Viscous1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_MassSpringDashpot}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.925\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_MassSpringDashpot}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The root mean square error for the displacements and reaction are : (\\texttt{%#1.6g}, \\texttt{%#1.6g}), while the maximum relative error for the displacement and reaction are : (\\texttt{%#1.6g},\\texttt{%#1.6g}) respectively." % (rms1,rms2,mad1,mad2))
LaTeXfile.close()
