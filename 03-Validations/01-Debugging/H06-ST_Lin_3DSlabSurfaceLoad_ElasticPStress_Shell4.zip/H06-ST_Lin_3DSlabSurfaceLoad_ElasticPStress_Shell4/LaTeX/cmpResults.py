#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
this     = filepath + '/Solution/ShellSlab/'
opensees = filepath + '/ETABS/'

#ANALYTICAL SOLUTION:
eps        = 1E-15
nodalETABS = np.loadtxt(opensees + 'Displacement.out',dtype='float')
nodalETABS = nodalETABS[[26,27,33],:]

#SeismoVLab SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=4)
nodal = np.reshape(nodal, (3,6))

#COMPUTES ERRORS:
error1 = np.amax(np.absolute(np.divide(nodalETABS - nodal, nodalETABS + eps)))

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-Shell4_Slab_SurfaceLoad} is a horizontal shell (slab) elements defined to 
test \\texttt{lin3DShell4} elements with material type \\texttt{Elastic2DPlaneStress}. The slab elements have material with elasticity 
moduli $E = 25.0 \;GPa$, and a Poisson's ratio $\\nu = 0.25$. Nodes (1), (2), (3), and (4) have coordinate $(0.0, 0.0, 0.0)$, 
$(6.0, 0.0, 0.0)$, and $(6.0, 6.0, 0.0)$, and $(0.0, 6.0, 0.0)$ respectively. Nodes at the boundaries are clamped, i.e., displacements and 
rotation along/about \\textrm{X}, \\textrm{Y} and \\textrm{Z} are restrained. The shell has a thickness of $t_h = 0.1\;m$. A vertical out-plane 
surface load is added with magnitude $q = 2450 \; N/m$ and direction $\hat{n} = (0,0,-1)$. Responses are verified against numerical (ETABS) solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.395 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3DShell4} with \\texttt{Elastic2DPlaneStress} material and Surface Load.}\n")
LaTeXfile.write("\t\label{fig:Verification-Shell4_Slab_SurfaceLoad}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the horizontal deformation at node (25), (26) and (32) is : \\texttt{%#1.6g}." % error1)
LaTeXfile.close()
