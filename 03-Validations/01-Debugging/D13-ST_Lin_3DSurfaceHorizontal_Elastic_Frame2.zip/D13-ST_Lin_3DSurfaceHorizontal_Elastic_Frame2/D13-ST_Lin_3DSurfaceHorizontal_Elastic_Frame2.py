"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_D13'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 100000.0, 'nu': 0.30, 'rho': 0.00})

#CReate Section
SVL.addSection(tag=1, name='Lin3DRectangular', model='Plain', attributes={'material': 1, 'b': 0.2, 'h': 0.2})

#Create Nodes
nNodes = 6
for k in range(nNodes):
    SVL.addNode(tag=(k+1), ndof=6, coords=[float(k)/(nNodes-1), 0.00, 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2, 3, 4, 5, 6])

#Create Element
for k in range(nNodes-1):
    SVL.addElement(tag=(k+1), conn=[k+1, k+2], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
#SVL.printAll('Elements')

#Create surfaces
for k in range(nNodes-1):
    SVL.addSurface(tag=(k+1), etag=(k+1), conn=[k+1, k+2])

#Create function
fun = {'mag': 10.0, 'dir': [0.0, 0.0, -1.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Surface', 'list': 'ALL'}
SVL.addLoad(tag=1, name='ElementLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='Cantilever3D', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': 6}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': 1}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('partition')
#SVL.printAll('Nodes')
