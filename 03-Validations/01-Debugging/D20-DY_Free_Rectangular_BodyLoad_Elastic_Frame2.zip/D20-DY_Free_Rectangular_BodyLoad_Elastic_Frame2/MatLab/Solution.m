h = 1.0;
L   = 10;
E   = 20000.0;
I   = 1/12*h^4;
rho = 0.1;
T   = 5.0;
dt  = 0.010;
dx  = 0.625;

x      = 0:dx:L;
nmodes = 500;
qo     = -0.1;
time   = 0:dt:T;

k = 1;
sols = zeros(length(time),4);
for t = time,
    u = zeros(1, length(x));
    M = zeros(1, length(x));
    V = zeros(1, length(x));
    for n = 1:2:nmodes,
        phin = sin(n*pi*x/L);
        wn   = (n*pi/L)^2*sqrt(E*I/rho);

        qn   =  4*qo*L^4/(n^5*pi^5*E*I)*(1 - cos(wn*t));
        Mn   = -E*I*(n*pi/L)^2*sin(n*pi*x/L);
        Vn   = -E*I*(n*pi/L)^3*cos(n*pi*x/L);
        u    =  u + qn*phin;
        M    =  M + qn*Mn;
        V    =  V + qn*Vn;
    end;
    sols(k,:) = [t, u(9), V(1), M(5)]; k = k + 1;
    subplot(3,1,1); plot(x,u); xlim([0, L]); ylim([-0.02,0.010]);
    subplot(3,1,2); plot(x,V); xlim([0, L]); ylim([-1.0,1.0]);
    subplot(3,1,3); plot(x,M); xlim([0, L]); ylim([-1.0,2.5]);
    drawnow;
end
