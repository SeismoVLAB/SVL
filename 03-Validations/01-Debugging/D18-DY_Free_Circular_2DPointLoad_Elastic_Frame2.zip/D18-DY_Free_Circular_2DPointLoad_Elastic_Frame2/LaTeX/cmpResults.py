#!/usr/bin/python3

import os
import math
import numpy as np
import matplotlib.pyplot as plt

pwd = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwd + "/LaTeX/ModelTest.png" 
ResultFigure = pwd + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this   = pwd + '/Solution/CantileverBeam/'

#ANALYTICAL SOLUTION:
E   =  35000.0
P   = -10.0
rho =  0.10
L   =  10.00
r   =  0.50
I   =  math.pi*r**4/4.0
A   =  math.pi*r**2
k   = 3.0*E*I/L**3
dt  = 0.02
wn  = (1.875/L)**2*np.sqrt(E*I/rho/A)

t   = np.arange(dt, 4.60+dt, dt)
x   = P/k*(1 - np.cos(wn*t))

#SeismoVLab SOLUTION:
displacement = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(10.5,9.0))
plt.plot(t+dt, x, 'r-', t, displacement[:,1], 'b.')
plt.xlabel("$t$", fontsize=30)
plt.ylabel("$u$", fontsize=30)
plt.xlim((0,4.5))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-D18-DY_Free_Circular_2DPointLoad_Elastic_Frame2} 
and is defined to test \\texttt{Lin2Drame2} element with material type \\texttt{Elastic1DLinear}. For this example, all beam 
members have a circular cross-section with radius $r = 0.5$, and modulus of elasticity, $E = 35000$. The beam is $10$ units 
long and is discretized with 16 equal length beam elements and 17 nodes. A vertical dynamic load is placed aat Node (17) of 
constant magnitude $10$. No damping is added. The responses are verified against (simplified 1 dof) analytical solution. 
Figure~\\ref{fig:Verification_D18-DY_Free_Circular_2DPointLoad_Elastic_Frame2} shows the force displacement curve at node (17). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.575 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DFrame2} with \\texttt{Lin2DCircular} Section.}\n")
LaTeXfile.write("\t\label{fig:Verification-D18-DY_Free_Circular_2DPointLoad_Elastic_Frame2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.35\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Force displacement curve at (11): Analytical ({\color{blue}{$\dots$}}), SeismoVLab (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_D18-DY_Free_Circular_2DPointLoad_Elastic_Frame2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.close()
