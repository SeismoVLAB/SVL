#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
this   = filepath + '/Solution/3DPiramid/'

#ANALYTICAL SOLUTION:
delta = -4.2401E-3
Internalforces = np.array([125./9., 200./9., 125./9., 75., 50.0*np.sqrt(17)/3.0, 75.0])

#SeismoVLab SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='double', skiprows=2)
force = np.loadtxt(this + 'InternalForce.0.out',dtype='double', skiprows=7)
force = np.reshape(force, (6,6))
force = np.sqrt(force[:,0]**2 + force[:,1]**2 + force[:,2]**2)/1000.0

#COMPUTES ERRORS:
error0 = abs((nodal[2] - delta)/delta);
error1 = max(np.divide(force - Internalforces, Internalforces));

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-3DPiramid_Elastic1DLinear} is an piramid 
defined to test \\texttt{lin3DTruss2} element with material type \\texttt{Elastic1DLinear} and the local axis 
transformations for Truss elements. The material has a elasticity moduli $E = 68.9 \;GPa$, and a Poisson's 
ratio $\\nu = 0.33$. Nodes (1), (2), (3), and (4) have coordinate $(-1.0, -4.0, 0.0)$, $(2.0, 0.0, 0.0)$, 
$(-1.0, 4.0, 0.0)$, and $(0.0, 0.0, 8.0)$ respectively. Node (1) is fixed in \\textrm{X}, \\textrm{Y}, 
and \\textrm{Z} directions, while node (2) and (3) are fixed in \\textrm{Z}-direction. The truss elements have 
an area $A = 0.0025 \, m^2$. A vertical load is placed at node (4) with magnitude $P = 200 \cdot 10^3 \; N$. 
Responses are verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.325 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3DTruss2} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-3DPiramid_Elastic1DLinear}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the vertical deformation at node (4) is : \\texttt{%#1.6g}, while the maximum relative error for the internal axial forces for all elements is : \\texttt{%#1.6g}." % (error0, error1))
LaTeXfile.close()
