"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_C05'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 6.89E+10, 'nu': 0.33, 'rho': 0.0})

#Create Nodes
SVL.addNode(tag=1, ndof=3, coords=[-1.00000, -4.00000, 0.00000])
SVL.addNode(tag=2, ndof=3, coords=[ 2.00000,  0.00000, 0.00000])
SVL.addNode(tag=3, ndof=3, coords=[-1.00000,  4.00000, 0.00000])
SVL.addNode(tag=4, ndof=3, coords=[ 0.00000,  0.00000, 8.00000])

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1,2,3])
SVL.addRestrain(tag=2, dof=3)
SVL.addRestrain(tag=3, dof=[1,3])

#Create Element
SVL.addElement(tag=1, conn=[1, 2], name='lin3DTruss2', attributes={'material': 1, 'area': 0.00250})
SVL.addElement(tag=2, conn=[1, 3], name='lin3DTruss2', attributes={'material': 1, 'area': 0.00250})
SVL.addElement(tag=3, conn=[2, 3], name='lin3DTruss2', attributes={'material': 1, 'area': 0.00250})
SVL.addElement(tag=4, conn=[1, 4], name='lin3DTruss2', attributes={'material': 1, 'area': 0.00250})
SVL.addElement(tag=5, conn=[2, 4], name='lin3DTruss2', attributes={'material': 1, 'area': 0.00250})
SVL.addElement(tag=6, conn=[3, 4], name='lin3DTruss2', attributes={'material': 1, 'area': 0.00250})

#Create function
fun = {'mag': 2.0E+05, 'dir': [0.0, 0.0, -1.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': [4]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='3DPiramid', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [4]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'internalforce', 'list': 'ALL'}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
