"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_A08'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.0, 0.0])
SVL.addNode(tag=2, ndof=2, coords=[0.5, 0.0])

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=2, dof=[2])

#Create Element
elem = {'alpha': 1.0, 'mu': 2.0, 'eta': 1.0, 'beta': 0.5, 'gamma': 0.5, 'tol': 1E-08, 'Fy': 250.0, 'k0': 250.0, 'a1': 0.1, 'a2': 0.0, 'dim': 2, 'dir': 1}
SVL.addElement(tag=1, conn=[1, 2], name='UnxBoucWen2DLink', attributes=elem)

#Create function
fun = {'file': 'StressLoad.txt', 'dir': [1.0, 0.0]}
SVL.addFunction(tag=1, name='TimeSerie', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'TimeSerie', 'list': [2]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='LinkBoucWen', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'ELEMENT', 'file': 'Stress.out', 'ndps': 8, 'resp': 'Stress', 'list': 1}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Strain.out', 'ndps': 8, 'resp': 'Strain', 'list': 1}
SVL.addRecorder(tag=2, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 501})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Newton', 'nstep': 50, 'cnvgtol': 1E-06, 'cnvgtest': 'RelativeIncrementalDisplacement'})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.010})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('partition')
#SVL.printAll('Nodes')
