#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#Get file path
pwdpath = os.getcwd()

dt    = 0.01
time  = np.arange(0.0, 5.0, dt)

#FIGURE OUTPUT NAMES:
ModelFigure  = pwdpath + "/LaTeX/ModelTest.png" 
ResultFigure = pwdpath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this   = pwdpath + '/Solution/LinkBoucWen/'

#ANALYTICAL SOLUTION:
solution = np.loadtxt('Numerical/Solution.txt',dtype='float', skiprows=0)

#SeismoVLAB SOLUTION:
disp  = np.loadtxt(this + 'Strain.0.out',dtype='float', skiprows=2)
force = np.loadtxt(this + 'Stress.0.out',dtype='float', skiprows=2)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 2, 1)
plt.plot(time, disp, 'r-', time, solution[:,0], 'b.')
plt.xlabel("$t$", fontsize=30)
plt.ylabel("$u_1(t)$", fontsize=30)
plt.xlim((0,5.0))
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(disp, force, 'r-', solution[:,0], solution[:,1], 'b.')
plt.xlabel("$u_1(t)$", fontsize=30)
plt.ylabel("$F_1(t)$", fontsize=30)
plt.xlim((-5.0,5.0))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-model_BoucWen2D_Param1} is 
defined to test \\texttt{UnxBoucWen2DLink} element and its behavior is defined on local axis 1. The link properties are $\\alpha=1.0$, $\\mu=2.0$, $\\beta=0.5$, $\\gamma=0.5$, $\eta=1.0$, $f_y=250.0$, $k_0=250.0$, $\\alpha_1 = 0.1$, and $\\alpha_2 = 0.0$. Nodes (1) has coordinate $(x,y) = (0.0, 0.0)$ and (2) has coordinate $(x,y) = (0.5, 0.0)$. Node (1) is fixed in \\textrm{X} and \\textrm{Y} directions, while 
node (2) is fixed in \\textrm{Y} direction. For dynamic analysis, a point load is applied at node (2). Responses are verified against analytical 
solution. Figure~\\ref{fig:Verification_BoucWen2D_Param1} shows the strain, stress, and material 
constitutive responses at (2). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.190 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{UnxBoucWen2DLink} element.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_BoucWen2D_Param1}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.900\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_BoucWen2D_Param1}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.close()
