"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_A18'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Steel1DFiber', attributes={'fy': 60.0, 'E': 29000.0, 'b': 0.01, 'R0': 20.0, 'cR1': 0.925, 'cR2': 0.15, 'a1': 0.000, 'a2': 1.00, 'a3': 0.000, 'a4': 1.00})

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.0, 0.0])
SVL.addNode(tag=2, ndof=2, coords=[0.0, 0.0])

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=2, dof=[1, 2])

#Restrain degree of freedom
SVL.addSupportMotion(tag=2, attributes={'file': 'SupportMotion.txt', 'type': 'TimeSeries', 'dof': 1})

#Create Element
SVL.addElement(tag=1, conn=[1, 2], name='ZeroLength1D', attributes={'material': 1, 'dir': 1})

#Create a Load
SVL.addLoad(tag=1, name='SupportMotion', attributes={'list': [2]})

#Create a Combination
SVL.addCombinationCase(tag=1, name='ZeroPlastic', attributes={'load': 1, 'factor': 1.0})

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'ELEMENT', 'file': 'Stress.out', 'ndps': 8, 'resp': 'Stress', 'list': 1}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Strain.out', 'ndps': 8, 'resp': 'Strain', 'list': 1}
SVL.addRecorder(tag=2, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 2001})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Newton', 'nstep': 50, 'cnvgtol': 1E-06, 'cnvgtest': 'RelativeIncrementalDisplacement'})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.01})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()
