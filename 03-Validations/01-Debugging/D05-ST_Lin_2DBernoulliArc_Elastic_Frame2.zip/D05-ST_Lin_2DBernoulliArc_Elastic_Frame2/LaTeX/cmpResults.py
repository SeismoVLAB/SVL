#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
this   = filepath + '/Solution/ArchBeam/'

#ANALYTICAL SOLUTION:
P  = 1000.0
R  = 10.0
h  = 1.00
b  = 0.20
E  = 68.9E9
A  = b*h
I  = b*h**3/12.0
pi = np.pi

deltax   = -P*R**3*pi/4.0/E/I 
deltay   = -P*R**3/2.0/E/I 
reaction = np.array([1000.0, 0.0, 10000.0])

#SeismoVLAB SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=2)
force = np.loadtxt(this + 'InternalForce.0.out',dtype='float', skiprows=2)

#COMPUTES ERRORS:
error0 = abs((nodal[0] - deltax)/deltax)
error1 = abs((nodal[1] - deltay)/deltay)
error2 = max(np.divide(force[0:3:2] - reaction[0:3:2], reaction[0:3:2]))

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-ArchBeam_Elastic1DLinear} is an arch beam 
defined to test \\texttt{lin2DFrame2} element with material type \\texttt{Elastic1DLinear} and the local axis 
transformations. The material has a elasticity moduli $E = 68.9 \;GPa$, and a Poisson's ratio $\\nu = 0.33$. 
Nodes (1) and node (2) have coordinate $(0.0, 10.0)$ and $(10.0, 0.0)$ respectively. Node (1) is fixed in \\textrm{X} 
and \\textrm{Y} directions, while node (20) is free. The Bernoulli beam has a rectangular cross section with $h = 1.0 \; m$ 
and $b = 0.2 \; m$. A horizontal load is placed at node (20) with magnitude $P = 1 \; kN$. Responses are verified 
against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.500 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DFrame2} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-ArchBeam_Elastic1DLinear}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the horizontal and vertical deformation at node (20) are : \\texttt{%#1.6g}, \\texttt{%#1.6g} respectively. The maximum relative error for the reaction forces at node (1) is : \\texttt{%#1.6g}." % (error0, error1, error2))
LaTeXfile.close()
