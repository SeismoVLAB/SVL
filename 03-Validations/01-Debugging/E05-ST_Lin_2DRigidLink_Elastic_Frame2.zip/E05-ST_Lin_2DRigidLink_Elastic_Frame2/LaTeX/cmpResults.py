#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#File path
pwd = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwd + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
L      = 1.0
h      = 0.1
E      = 100000.0
I      = 1.0/12.0*h**4
P      = 1.0

this   = pwd + '/Solution/CantileverBeam/'

#ANALYTICAL SOLUTION:
delta    = -4.0*P*L**3/(3.0*E*I)
reaction = np.array([0.0, P, P*L])

#SeismoVLab SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=2)
force = np.loadtxt(this + 'Reaction.0.out',dtype='float', skiprows=2)

#COMPUTES ERRORS:
error0 = abs((nodal[1] - delta)/delta)
error1 = max(abs(np.divide(force[[1,2]] - reaction[[1,2]], reaction[[1,2]])))

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-Cantilever_Frame2_RigidLink} is a portal frame 
defined to test \\texttt{RigidLink} constraints. The material has a elasticity modulus $E = 100000 \;Pa$, and a Poisson's ratio $\\nu = 0.30$. Nodes (1) and node (5) have coordinate $(0.0, 0.0)$ and $(1.0, 1.0)$ respectively. Node (1) is clamped i.e, displacement and rotation are fixed, while nodes from (6) are free. Two rigid links are added between node (2)-(3) and (3)-(4) of length 0.001. The Bernoulli beam has a rectangular cross section with $h = b = 0.10 \; m$. The beam is subjected to a vertical point load $P = 1\;[N]$. Responses are verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.300 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{RigidLink} constraint in 2D.}\n")
LaTeXfile.write("\t\label{fig:Verification-Cantilever_Frame2_RigidLink}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the vertical deformation at node (5) is : \\texttt{%#1.6g}. The maximum relative error for the reaction forces at node (1) is : \\texttt{%#1.6g}." % (error0, error1))
LaTeXfile.close()
