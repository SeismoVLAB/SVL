clc; clear; close all;

opensees = 'SoilColumnPlasticPlaneStrainBA-OpenSees/';
this     = 'SoilColumnPlasticPlaneStrainBA/';

dis1 = load([opensees 'displacement.out']);
vel1 = load([opensees 'velocity.out']);
acc1 = load([opensees 'acceleration.out']); 
stress1 = load([opensees 'stress.out']); stress1(:,1) = [];
strain1 = load([opensees 'strain.out']); strain1(:,1) = [];

dis2 = load([this 'SoilColumnPlasticPlaneStrainBA-Displacement.out']);
vel2 = load([this 'SoilColumnPlasticPlaneStrainBA-Velocity.out']);
acc2 = load([this 'SoilColumnPlasticPlaneStrainBA-Acceleration.out']); 
stress2 = load([this 'SoilColumnPlasticPlaneStrainBA-Stress.out']);
strain2 = load([this 'SoilColumnPlasticPlaneStrainBA-Strain.out']);

ricker = load('ricker-SoilColumnPlasticPlaneStrainBA-OpenSees.in');
% 
% t1 = dis1(:,1);

t2 = 0:0.001:9999*0.001;t1 = t2;

% [rw,t] = ricker(2,5000,0.001,1);
% csvwrite('rickePlasticPlaneStrainJ2-OpenSees',rw');

%% plot input incident wave
h = figure;
h.PaperUnits = 'inches';
h.PaperSize=[3 2];
h.Units = 'inches';
h.PaperPosition=[0 0 3 2];
plot(t2,ricker,'r-','linewidth',1); grid on;
xlabel('time [s]'); ylabel('input force - normalized');
print(h,'-dpng',[this 'ricker.png']);
print(h,'-dpng',[this 'ricker.png']);
%%

h = figure; 
h.PaperUnits = 'inches';
h.PaperSize=[8 3];
h.Units = 'inches';
h.PaperPosition=[0 0 8 3];
title('Displacement')
subplot(1,2,1); hold all;
plot(t1,dis1(:,2),'b-','linewidth',1);
plot(t2,dis2(:,1),'r--','linewidth',1);
xlabel('time [s]');ylabel('u_x(t) @ z = 0 [m]');
grid on;
subplot(1,2,2); hold all;
plot(t1,dis1(:,4),'b-','linewidth',1);
plot(t2,dis2(:,3),'r--','linewidth',1);
% plot(abaqus(:,1),abaqus(:,5));
xlabel('time [s]');ylabel('u_x(t) @ z = H [m]');
grid on;
print(h,'-dpng',[this 'displacement.png']);
print(h,'-dpng',[this 'displacement.png']);

h = figure; 
h.PaperUnits = 'inches';
h.PaperSize=[8 3];
h.Units = 'inches';
h.PaperPosition=[0 0 8 3];
title('Velocity')
subplot(1,2,1); hold all;
plot(t1,vel1(:,2),'b-','linewidth',1);
plot(t2,vel2(:,1),'r--','linewidth',1);
xlabel('time [s]');ylabel('v_x(t) @ z = 0 [m/s]');
grid on;
subplot(1,2,2);hold all;
plot(t1,vel1(:,4),'b-','linewidth',1);
plot(t2,vel2(:,3),'r--','linewidth',1);
xlabel('time [s]');ylabel('v_x(t) @ z = H [m/s]');
grid on;
print(h,'-dpng',[this 'velocity.png']);
print(h,'-dpng',[this 'velocity.png']);

h = figure; 
h.PaperUnits = 'inches';
h.PaperSize=[8 3];
h.Units = 'inches';
h.PaperPosition=[0 0 8 3];
title('Acceleration')
subplot(1,2,1); hold all;
plot(t1,acc1(:,2),'b-','linewidth',1);
plot(t2,acc2(:,1),'r--','linewidth',1);
xlabel('time [s]');ylabel('a_x(t) @ z = 0 [m/s/s]');
grid on;
legend('opensees','software')
subplot(1,2,2); hold all;
plot(t1,acc1(:,4),'b-','linewidth',1);
plot(t2,acc2(:,3),'r--','linewidth',1);
% plot(abaqus(:,1),abaqus(:,2));
xlabel('time [s]');ylabel('a_x(t) @ z = H [m/s/s]');
grid on;
print(h,'-dpng',[this 'acceleration.png']);
print(h,'-dpng',[this 'acceleration.png']);
%%
ha = 10000;
h = figure; 
h.PaperUnits = 'inches';
h.PaperSize=[10 3];
h.Units = 'inches';
h.PaperPosition=[0 0 10 3];
subplot(1,3,1); hold all;
plot(strain1(:,1),stress1(:,1),'b-','linewidth',1);
plot(strain2(1:ha,1),stress2(1:ha,1),'r--','linewidth',1);grid on;
xlabel('\epsilon_{11}');ylabel('\sigma_{11} [Pa]');
subplot(1,3,2); hold all;
plot(strain1(:,2),stress1(:,2),'b-','linewidth',1);
plot(strain2(1:ha,2),stress2(1:ha,2),'r--','linewidth',1);grid on;
xlabel('\epsilon_{22}');ylabel('\sigma_{22} [Pa]');
subplot(1,3,3); hold all;
plot(  strain1(:,3),stress1(:,3),'b','linewidth',1);
plot(2*strain2(1:ha,3),stress2(1:ha,3),'r--','linewidth',1);grid on;
% plot(2*abaqus(:,3),abaqus(:,4));
xlabel('\epsilon_{12}');ylabel('\sigma_{12} [Pa]');
print(h,'-dpng',[this 'stressstrain.png']);
print(h,'-dpng',[this 'stressstrain.png']);