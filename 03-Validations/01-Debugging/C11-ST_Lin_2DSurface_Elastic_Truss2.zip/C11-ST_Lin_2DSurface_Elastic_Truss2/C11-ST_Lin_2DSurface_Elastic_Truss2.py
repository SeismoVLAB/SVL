"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_C11'
SVL.Options['format'] = 'json'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 1.0E+05, 'nu': 0.30, 'rho': 0.0})

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.00, 0.00])
SVL.addNode(tag=2, ndof=2, coords=[0.20, 0.00])
SVL.addNode(tag=3, ndof=2, coords=[0.40, 0.00])
SVL.addNode(tag=4, ndof=2, coords=[0.60, 0.00])
SVL.addNode(tag=5, ndof=2, coords=[0.80, 0.00])
SVL.addNode(tag=6, ndof=2, coords=[1.00, 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=2, dof=2)
SVL.addRestrain(tag=3, dof=2)
SVL.addRestrain(tag=4, dof=2)
SVL.addRestrain(tag=5, dof=2)
SVL.addRestrain(tag=6, dof=2)

#Create Element
SVL.addElement(tag=1, conn=[1, 2], name='lin2DTruss2', attributes={'material': 1, 'area': 0.04})
SVL.addElement(tag=2, conn=[2, 3], name='lin2DTruss2', attributes={'material': 1, 'area': 0.04})
SVL.addElement(tag=3, conn=[3, 4], name='lin2DTruss2', attributes={'material': 1, 'area': 0.04})
SVL.addElement(tag=4, conn=[4, 5], name='lin2DTruss2', attributes={'material': 1, 'area': 0.04})
SVL.addElement(tag=5, conn=[5, 6], name='lin2DTruss2', attributes={'material': 1, 'area': 0.04})
#SVL.printAll('Elements')

#Create Surfaces
SVL.addSurface(tag=1, etag=1, conn=[1, 2])
SVL.addSurface(tag=2, etag=2, conn=[2, 3])
SVL.addSurface(tag=3, etag=3, conn=[3, 4])
SVL.addSurface(tag=4, etag=4, conn=[4, 5])
SVL.addSurface(tag=5, etag=5, conn=[5, 6])

#Create function
fun = {'mag': 10.0, 'dir': [1.0, 0.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'surface', 'list': [1, 2, 3, 4, 5]}
SVL.addLoad(tag=1, name='ElementLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='Truss2DAxial', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [6]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Reaction.out', 'ndps': 8, 'resp': 'reaction', 'list': [1]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Stress.out', 'ndps': 8, 'resp': 'Stress', 'list': [1]}
SVL.addRecorder(tag=3, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Strain.out', 'ndps': 8, 'resp': 'Strain', 'list': [1]}
SVL.addRecorder(tag=4, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
