#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#FIGURE OUTPUT NAMES:
ModelFigure  = os.getcwd() + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
P = 10.0
A = 0.04
L = 1.00
E = 100000.0

this   = os.getcwd() + '/Solution/Truss3DAxial/'

#ANALYTICAL SOLUTION:
Disp   = P*L**2/A/E/2.0
Stress = P*L/A
Strain = Stress/E

#SeismoVLab SOLUTION:
dis    = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)
strain = np.loadtxt(this + 'Strain.0.out',dtype='float', skiprows=2)
stress = np.loadtxt(this + 'Stress.0.out',dtype='float', skiprows=2)

err1 = abs(dis[0] - Disp)/Disp
err2 = abs(stress[0] - Stress)/Stress
err3 = abs(strain[0] - Strain)/Strain

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_lin3DTruss3_surfaceload} and is defined 
to test \\texttt{lin3DTruss3} element with material type \\texttt{Elastic1DLinear}. The material has modulus 
of elasticity $E = 100000 \; Pa$. The nodes (1), and (6) have the coordinates $(0.0, 0.0, 0.0)$ and $(1.0, 0.0, 0.0)$ 
respectively. Node (1) is fixed in \\textrm{X}-, \\textrm{Y}- and \\textrm{Z}-directions, while nodes (2), (3), (4), (5), and (6) are fixed 
in \\textrm{Y}- and \\textrm{Z}-directions. The truss element has an area of $A = 0.04 \; m^2$, and a length of $L = 1.00 \; m$. 
For static analysis, the surface load is applied on all elements and defined as $q = 10 \; N/m$. The responses are 
verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.275 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3DTruss3} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_lin3DTruss3_surfaceload}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("In this case, the relative absolute error for the displacement is : \\texttt{%#1.6g}, while The relative absolute error for the strain and stress are : \\texttt{%#1.6g}, \\texttt{%#1.6g} repectively." % (err1, err2, err3))
LaTeXfile.close()
