"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_F10'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic2DPlaneStrain', attributes={'E': 2.080E+08, 'nu': 0.30, 'rho': 2000.0})
SVL.addMaterial(tag=2, name='Viscous1DLinear', attributes={'eta': 4.0E+05})

#Create Nodes (for quads)
SVL.addNode(tag=1, ndof=2, coords=[0.00, 0.00])
SVL.addNode(tag=2, ndof=2, coords=[2.00, 0.00])
SVL.addNode(tag=3, ndof=2, coords=[2.00, 2.00])
SVL.addNode(tag=4, ndof=2, coords=[0.00, 2.00])
SVL.addNode(tag=5, ndof=2, coords=[1.00, 0.00])
SVL.addNode(tag=6, ndof=2, coords=[2.00, 1.00])
SVL.addNode(tag=7, ndof=2, coords=[1.00, 2.00])
SVL.addNode(tag=8, ndof=2, coords=[0.00, 1.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=2, dof=2)

#Create Element
SVL.addElement(tag=1, conn=[1,2,3,4,5,6,7,8], name='lin2DQuad8', attributes={'material': 1, 'th': 1.0, 'rule': 'Gauss', 'np': 16})

#Create function
fun = {'mag': 1000000.0, 'dir': [1.0, 0.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

fun = {'mag': 2000000.0, 'dir': [0.0, -1.0]}
SVL.addFunction(tag=2, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': [4]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

load = {'fun': 2, 'type': 'Constant', 'list': [4]}
SVL.addLoad(tag=2, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1,2], 'factor': [1.0, 1.0]}
SVL.addCombinationCase(tag=1, name='QuadPlaneStrainElasticStatic', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [2, 3, 4, 5, 6, 7, 8]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Stress.out', 'ndps': 8, 'resp': 'stress', 'list': [1]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Strain.out', 'ndps': 8, 'resp': 'strain', 'list': [1]}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.printAll('Elements')
#SVL.renderData('element')
