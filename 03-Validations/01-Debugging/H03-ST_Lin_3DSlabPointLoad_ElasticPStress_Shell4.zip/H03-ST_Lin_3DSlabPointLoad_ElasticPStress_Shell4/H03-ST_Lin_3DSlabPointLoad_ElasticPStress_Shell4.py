"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_H03'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic2DPlaneStress', attributes={'E': 2.5E+10, 'nu': 0.25, 'rho': 2500.0})

#Create Section
SVL.addSection(tag=1, name='Lin3DThinArea', model='Plain', attributes={'material': 1, 'th': 0.1})

#Create Nodes (for quads)
n = 7
m = 7
for j in range(n):
    for i in range(m):
        SVL.addNode(tag=(j*m + i + 1), ndof=6, coords=[float(j), float(i), 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
for k in range(m):
    SVL.addRestrain(tag=(k+1), dof=[1,2,3,4,5,6])
for k in range(m):
    SVL.addRestrain(tag=(m*(n-1)+k+1), dof=[1,2,3,4,5,6])
for k in range(m-1):
    SVL.addRestrain(tag=(m*(k+1)+1), dof=[1,2,3,4,5,6])
    SVL.addRestrain(tag=(m*(k+1)), dof=[1,2,3,4,5,6])

#Create Element
for j in range(n-1):
    for i in range(m-1):
        SVL.addElement(tag=(j*(m-1) + i + 1), conn=[j*n+i+1,(j+1)*n+i+1,(j+1)*n+i+2,j*n+i+2], name='lin3dshell4', attributes={'section': 1, 'th': 1.0, 'rule': 'Gauss', 'np': 9})
#SVL.printAll('Elements')

#Create function
fun = {'mag': 10000.8, 'dir': [0.0, 0.0, -1.0, 0.0, 0.0, 0.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': 25}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='ShellSlab', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [25, 26, 32]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8}
SVL.addRecorder(tag=2, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
