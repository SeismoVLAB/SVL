#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#Get file path
pwdpath = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwdpath + "/LaTeX/ModelTest.png" 
ResultFigure = pwdpath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
dt       = 0.010
this     = pwdpath + '/Solution/Load/'
openSeeS = pwdpath + '/OpenSees/'
time     = np.arange(0.0, 20.0, dt)

#OPENSEES SOLUTION:
nt = len(time)
disp1 = np.loadtxt(openSeeS + 'Displacements.out', dtype='float', skiprows=0)
reac1 = np.loadtxt(openSeeS + 'Reaction.out', dtype='float', skiprows=0)

#SeismoVLAB SOLUTION:
disp2 = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)
reac2 = np.loadtxt(this + 'Reactions.0.out', dtype='float', skiprows=2)

#COMPUTES ERRORS:
delta = abs(disp1[:,1] - disp2[:,2])

#Root mean square error.
rms = np.sqrt(np.mean(delta**2))

#Maximum absolute difference.
mad = max(delta)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 3, 1)
plt.plot(time, disp2[:,2], 'r-', time[::5], disp1[::5,1], 'b.')
plt.xlabel("$t$"               , fontsize=30)
plt.ylabel("$\Delta(t)\,[in]$", fontsize=30)
plt.xlim((0,20))
plt.grid(True)

plt.subplot(1, 3, 2)
plt.plot(time, reac2[:,0]/100000.0, 'r-', time[::5], (reac1[::5,1] + 100000.0)/100000.0, 'b.')
plt.xlabel("$t$", fontsize=30)
plt.ylabel("$P(t)$", fontsize=30)
plt.xlim((0,20))
plt.ylim((0,2))
plt.grid(True)

plt.subplot(1, 3, 3)
plt.plot(disp2[:,2], reac2[:,4]/1000000.0, 'r-', disp1[::5,1], reac1[::5,5]/1000000.0, 'b.')
plt.xlabel("$\Delta(t)$", fontsize=30)
plt.ylabel("$M_{33}(t)$"  , fontsize=30)
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """The problem setting is the same as shown in Figure~\\ref{fig:Verification-model_Fiber_Steel_Cantilever} and is defined to 
test \\texttt{Progressive} analysis option. The material has modulus of elasticity 
$E = 29000000$, yield strength $fy = 60000$, $b = 0.01$, $a_1 = a_3 = 0.0$, $a_2 = a_4 = 1.0$, $cR_1 = 0.925$, $cR_2 = 0.15$, 
and a Poisson's ratio $\\nu = 0.33$. The nodes (1), and (8) have the coordinate $(x,y) = (0.0, 0.0)$ and 
$(x,y) = (100.0, 0.0)$ respectively. Node (1) is clamped, this is fixed in \\textrm{X}, \\textrm{Y}-directions and rotation. First, a 
static axial load $P = -100000$ is applied at node (8), then a dynamic nodal force is applied at node (8) and is defined as 
$P(t) = 8.75 \cdot 10^5 t \, \sin(0.4 \pi\,t)$. The responses are verified against OpenSees. 
Figure~\\ref{fig:Verification_Progressive_Fiber_Steel_Cantilever} shows the vertical displacement at node (2) and the moment and axial forces 
developed at the fixed boundary. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.945\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal vertical responses at node (8) and shear force at node (8) : OpenSees ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_Progressive_Fiber_Steel_Cantilever}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The root mean square error for the displacement is : \\texttt{%#1.6g}, while The maximum absolute difference for the displacement is : \\texttt{%#1.6g}." % (rms, mad))
LaTeXfile.close()
