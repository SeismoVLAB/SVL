"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_C02'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 250E+09, 'nu': 0.33, 'rho': 0.0})

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.00, 0.00])
SVL.addNode(tag=2, ndof=2, coords=[3.00, 0.00])
SVL.addNode(tag=3, ndof=2, coords=[6.00, 0.00])
SVL.addNode(tag=4, ndof=2, coords=[9.00, 0.00])
SVL.addNode(tag=5, ndof=2, coords=[3.00, 4.00])
SVL.addNode(tag=6, ndof=2, coords=[6.00, 4.00])

#Restrain degree of freedom
SVL.addRestrain(tag=2, dof=2)
SVL.addRestrain(tag=4, dof=[1,2])

#Create Element
SVL.addElement(tag=1, conn=[1, 2], name='lin2DTruss2', attributes={'material': 1, 'area': 300E-06})
SVL.addElement(tag=2, conn=[2, 3], name='lin2DTruss2', attributes={'material': 1, 'area': 300E-06})
SVL.addElement(tag=3, conn=[3, 4], name='lin2DTruss2', attributes={'material': 1, 'area': 300E-06})
SVL.addElement(tag=4, conn=[1, 5], name='lin2DTruss2', attributes={'material': 1, 'area': 300E-06})
SVL.addElement(tag=5, conn=[2, 5], name='lin2DTruss2', attributes={'material': 1, 'area': 300E-06})
SVL.addElement(tag=6, conn=[5, 3], name='lin2DTruss2', attributes={'material': 1, 'area': 300E-06})
SVL.addElement(tag=7, conn=[5, 6], name='lin2DTruss2', attributes={'material': 1, 'area': 300E-06})
SVL.addElement(tag=8, conn=[3, 6], name='lin2DTruss2', attributes={'material': 1, 'area': 300E-06})
SVL.addElement(tag=9, conn=[6, 4], name='lin2DTruss2', attributes={'material': 1, 'area': 300E-06})

#Create function
fun = {'mag': 200E+03, 'dir': [0.0, -1.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': [1]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='Roof2D', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [1, 5]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'internalforce', 'list': 'ALL'}
SVL.addRecorder(tag=2, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()
