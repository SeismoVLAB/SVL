#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

pwd = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwd + "/LaTeX/ModelTest.png" 
ResultFigure = pwd + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this   = pwd + '/Solution/CantileverBeam/'

#ANALYTICAL SOLUTION:
h   =  1.00
b   =  1.00
tw  =  0.1
tf  =  0.1
A   =  tw*h + (b - tw)*tf
ycm = (tw*h*h/2.0 + (b - tw)*tf*(h - tf/2.0))/A

E   =  35000.0
P   = -10.0
rho =  0.10
L   =  10.00
I   = 1/3.0*tw*ycm**3 + 1.0/3.0*b*(h - ycm)**3 - 1.0/3.0*(b-tw)*(h - ycm - tf)**3
k   = 3*E*I/L**3
dt  = 0.020
wn  = (1.875/L)**2*np.sqrt(E*I/rho/A)
d   = 0.0200*wn/2.0
wd  = wn*np.sqrt(1-d**2)

t = np.arange(dt, 4.60+dt, dt)
x = P/k*(1 - np.exp(-d*wn*t)/np.sqrt(1-d**2)*np.cos(wd*t + np.arctan(-d/np.sqrt(1 - d**2))))

#SeismoVLAB SOLUTION:
displacement = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(10.5,9.0))
plt.plot(t+dt, x, 'r-', t, displacement[:,1], 'b.')
plt.xlabel("$t$", fontsize=30)
plt.ylabel("$u$", fontsize=30)
plt.xlim((0,4.5))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-D19-DY_Damped_Angle_2DPointLoad_Elastic_Frame2} 
and is defined to test \\texttt{Lin3Drame2} element with material type \\texttt{Elastic1DLinear}. For this example, all beam 
members have an Angle cross-section with height $h = 1$, width $b=1$, web and flange thickness $t_w=t_f=0.1$, and modulus of 
elasticity, $E = 35000$. The beam is $10$ units long and is discretized with 16 equal length beam elements and 17 nodes. A 
vertical dynamic load is placed aat Node (17) of constant magnitude $10$. Rayleigh damping is added with $a_0 = 0$, and 
$a_1=0.02$. The responses are verified against analytical (simplified 1 dof) solution. 
Figure~\\ref{fig:Verification_D19-DY_Damped_Angle_2DPointLoad_Elastic_Frame2} shows the force displacement curve at node (17). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.575 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DFrame2} with \\texttt{Lin2DAngle} Section.}\n")
LaTeXfile.write("\t\label{fig:Verification-D19-DY_Damped_Angle_2DPointLoad_Elastic_Frame2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.35\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Displacement time series at node (17): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_D19-DY_Damped_Angle_2DPointLoad_Elastic_Frame2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.close()
