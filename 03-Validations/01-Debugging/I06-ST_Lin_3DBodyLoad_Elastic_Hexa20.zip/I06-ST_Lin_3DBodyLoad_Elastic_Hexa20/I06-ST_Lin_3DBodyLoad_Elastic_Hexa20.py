"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_I06'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic3DLinear', attributes={'E': 1.0E+05, 'nu': 0.30, 'rho': 25.0})

#Create Nodes (for quads)
SVL.addNode(tag=1, ndof=3, coords=[0,0,0])
SVL.addNode(tag=2, ndof=3, coords=[0.2,0,0])
SVL.addNode(tag=3, ndof=3, coords=[0.4,0,0])
SVL.addNode(tag=4, ndof=3, coords=[0.6,0,0])
SVL.addNode(tag=5, ndof=3, coords=[0.8,0,0])
SVL.addNode(tag=6, ndof=3, coords=[1,0,0])
SVL.addNode(tag=7, ndof=3, coords=[0,0.2,0])
SVL.addNode(tag=8, ndof=3, coords=[0.2,0.2,0])
SVL.addNode(tag=9, ndof=3, coords=[0.4,0.2,0])
SVL.addNode(tag=10, ndof=3, coords=[0.6,0.2,0])
SVL.addNode(tag=11, ndof=3, coords=[0.8,0.2,0])
SVL.addNode(tag=12, ndof=3, coords=[1,0.2,0])
SVL.addNode(tag=13, ndof=3, coords=[0,0,0.2])
SVL.addNode(tag=14, ndof=3, coords=[0.2,0,0.2])
SVL.addNode(tag=15, ndof=3, coords=[0.4,0,0.2])
SVL.addNode(tag=16, ndof=3, coords=[0.6,0,0.2])
SVL.addNode(tag=17, ndof=3, coords=[0.8,0,0.2])
SVL.addNode(tag=18, ndof=3, coords=[1,0,0.2])
SVL.addNode(tag=19, ndof=3, coords=[0,0.2,0.2])
SVL.addNode(tag=20, ndof=3, coords=[0.2,0.2,0.2])
SVL.addNode(tag=21, ndof=3, coords=[0.4,0.2,0.2])
SVL.addNode(tag=22, ndof=3, coords=[0.6,0.2,0.2])
SVL.addNode(tag=23, ndof=3, coords=[0.8,0.2,0.2])
SVL.addNode(tag=24, ndof=3, coords=[1,0.2,0.2])
SVL.addNode(tag=25, ndof=3, coords=[0.1,0,0])
SVL.addNode(tag=26, ndof=3, coords=[0.3,0,0])
SVL.addNode(tag=27, ndof=3, coords=[0.5,0,0])
SVL.addNode(tag=28, ndof=3, coords=[0.7,0,0])
SVL.addNode(tag=29, ndof=3, coords=[0.9,0,0])
SVL.addNode(tag=30, ndof=3, coords=[0,0.1,0])
SVL.addNode(tag=31, ndof=3, coords=[0.2,0.1,0])
SVL.addNode(tag=32, ndof=3, coords=[0.4,0.1,0])
SVL.addNode(tag=33, ndof=3, coords=[0.6,0.1,0])
SVL.addNode(tag=34, ndof=3, coords=[0.8,0.1,0])
SVL.addNode(tag=35, ndof=3, coords=[1,0.1,0])
SVL.addNode(tag=36, ndof=3, coords=[0.1,0.2,0])
SVL.addNode(tag=37, ndof=3, coords=[0.3,0.2,0])
SVL.addNode(tag=38, ndof=3, coords=[0.5,0.2,0])
SVL.addNode(tag=39, ndof=3, coords=[0.7,0.2,0])
SVL.addNode(tag=40, ndof=3, coords=[0.9,0.2,0])
SVL.addNode(tag=41, ndof=3, coords=[0.1,0,0.2])
SVL.addNode(tag=42, ndof=3, coords=[0.3,0,0.2])
SVL.addNode(tag=43, ndof=3, coords=[0.5,0,0.2])
SVL.addNode(tag=44, ndof=3, coords=[0.7,0,0.2])
SVL.addNode(tag=45, ndof=3, coords=[0.9,0,0.2])
SVL.addNode(tag=46, ndof=3, coords=[0,0.1,0.2])
SVL.addNode(tag=47, ndof=3, coords=[0.2,0.1,0.2])
SVL.addNode(tag=48, ndof=3, coords=[0.4,0.1,0.2])
SVL.addNode(tag=49, ndof=3, coords=[0.6,0.1,0.2])
SVL.addNode(tag=50, ndof=3, coords=[0.8,0.1,0.2])
SVL.addNode(tag=51, ndof=3, coords=[1,0.1,0.2])
SVL.addNode(tag=52, ndof=3, coords=[0.1,0.2,0.2])
SVL.addNode(tag=53, ndof=3, coords=[0.3,0.2,0.2])
SVL.addNode(tag=54, ndof=3, coords=[0.5,0.2,0.2])
SVL.addNode(tag=55, ndof=3, coords=[0.7,0.2,0.2])
SVL.addNode(tag=56, ndof=3, coords=[0.9,0.2,0.2])
SVL.addNode(tag=57, ndof=3, coords=[0,0,0.1])
SVL.addNode(tag=58, ndof=3, coords=[0.2,0,0.1])
SVL.addNode(tag=59, ndof=3, coords=[0.4,0,0.1])
SVL.addNode(tag=60, ndof=3, coords=[0.6,0,0.1])
SVL.addNode(tag=61, ndof=3, coords=[0.8,0,0.1])
SVL.addNode(tag=62, ndof=3, coords=[1,0,0.1])
SVL.addNode(tag=63, ndof=3, coords=[0,0.2,0.1])
SVL.addNode(tag=64, ndof=3, coords=[0.2,0.2,0.1])
SVL.addNode(tag=65, ndof=3, coords=[0.4,0.2,0.1])
SVL.addNode(tag=66, ndof=3, coords=[0.6,0.2,0.1])
SVL.addNode(tag=67, ndof=3, coords=[0.8,0.2,0.1])
SVL.addNode(tag=68, ndof=3, coords=[1,0.2,0.1])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1,2,3])
SVL.addRestrain(tag=7, dof=[1,2,3])
SVL.addRestrain(tag=13, dof=[1,2,3])
SVL.addRestrain(tag=19, dof=[1,2,3])
SVL.addRestrain(tag=30, dof=[1,2,3])
SVL.addRestrain(tag=46, dof=[1,2,3])
SVL.addRestrain(tag=57, dof=[1,2,3])
SVL.addRestrain(tag=63, dof=[1,2,3])

#Create Element
SVL.addElement(tag=1, conn=[1, 2,  8,  7, 13, 14, 20, 19, 25, 31, 36, 30, 41, 47, 52, 46, 57, 58, 64, 63], name='lin3DHexa20', attributes={'material': 1, 'rule': 'Gauss', 'np': 27})
SVL.addElement(tag=2, conn=[2, 3,  9,  8, 14, 15, 21, 20, 26, 32, 37, 31, 42, 48, 53, 47, 58, 59, 65, 64], name='lin3DHexa20', attributes={'material': 1, 'rule': 'Gauss', 'np': 27})
SVL.addElement(tag=3, conn=[3, 4, 10,  9, 15, 16, 22, 21, 27, 33, 38, 32, 43, 49, 54, 48, 59, 60, 66, 65], name='lin3DHexa20', attributes={'material': 1, 'rule': 'Gauss', 'np': 27})
SVL.addElement(tag=4, conn=[4, 5, 11, 10, 16, 17, 23, 22, 28, 34, 39, 33, 44, 50, 55, 49, 60, 61, 67, 66], name='lin3DHexa20', attributes={'material': 1, 'rule': 'Gauss', 'np': 27})
SVL.addElement(tag=5, conn=[5, 6, 12, 11, 17, 18, 24, 23, 29, 35, 40, 34, 45, 51, 56, 50, 61, 62, 68, 67], name='lin3DHexa20', attributes={'material': 1, 'rule': 'Gauss', 'np': 27})

#Create function
fun = {'mag': 10.00, 'dir': [0.0, 0.0, -1.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Body', 'list': [1,2,3,4,5]}
SVL.addLoad(tag=1, name='ElementLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='HexaElasticStatic', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [6, 12, 18, 24]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Reaction.out', 'ndps': 8, 'resp': 'reaction', 'list': [1,7,13,19,30,46,57,63]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': [1]}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()
