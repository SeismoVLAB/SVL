#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png"
ResultFigure = filepath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
eps      = 1E-15
this     = filepath + '/Solution/SoilColumnElasticPlaneStrainPML/'

#SeismoVLab SOLUTION:
dt = 0.01
time = np.arange(dt, 10.0, dt)
vels = np.loadtxt(this + 'Velocity.0.out', dtype='float', skiprows=3)

plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(12,7.0))
plt.plot(time, vels[:,1], 'r-', time, vels[:,3], 'b-')
plt.xlabel("$t$"               , fontsize=30)
plt.ylabel("$v(t)$", fontsize=30)
plt.xlim((0,10))
plt.ylim((-0.3,0.6))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """The Problem is shown in Figure~\\ref{fig:Verification-2DPMLSoilColumn_ElasticPStrain_Quad4} and is defined 
to test \\texttt{PML2DQuad4} element with material type provided in \\texttt{Elastic2DPlaneStrain}. The material has 
$E = 50 \; MPa$, $\\nu = 0.25$, and $\\rho = 2000 \; kg/m^3$. The rod is $100 \;m$ long and is fixed on the left hand side 
and isfree to move in the axial direction. Two nodal forces are placed on the right end with $P_1=0.1 \;MN$. The velocity 
responses are evaluated at the right border (blue) and PML/Quad interface (red) and they should show no reflections after 
$t \geq 2\;[s]$. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.65 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Verification for \\texttt{PML2DQuad4} with \\texttt{Elastic2DPlaneStrain} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-2DPMLSoilColumn_ElasticPStrain_Quad4}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.50\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal velocity responses in SeismoVLab (blue $PC_2$) (red $PC_1$).}\n")
LaTeXfile.write("\label{fig:Verification_Viscous1DLinear}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.close()