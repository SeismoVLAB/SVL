"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_F11'
SVL.Options['format'] = 'json'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic2DPlaneStrain', attributes={'E': 5.0E+07, 'nu': 0.25, 'rho': 2000.0})
SVL.addMaterial(tag=2, name='Elastic2DPlaneStrain', attributes={'E': 5.0E+07, 'nu': 0.25, 'rho': 2000.0})

#Create the PML domain
opts1 = {
    'ne': [1, 10], 
    'class': 'PML2DQuad4', 
    'ndof' : 5, 
    'P0': [0, 0], 
    'P1': [1.0, 0], 
    'P2': [0, 10.0], 
    'elems': 'QUAD4',
    'attributes': {'material': 2, 'th': 1.00, 'n': 2.0, 'L': 5.0, 'R': 1E-5, 'x0': [0.5, 10.0], 'npml': [0.0, -1.0], 'rule': 'Gauss', 'np': 4}
    }
mesh1 = SVL.makeDomainArea(options=opts1)
#SVL.printFormatted(mesh1['Nodes'])

#Create the Hexahedron domain
opts2 = {
    'ne': [1, 90], 
    'class': 'LIN2DQuad4', 
    'ndof' : 2, 
    'P0': [0.0, 10.0], 
    'P1': [1.0, 10.0], 
    'P2': [0.0, 100.0], 
    'elems': 'QUAD4',
    'attributes': {'material': 1, 'th': 1.00, 'rule': 'Gauss', 'np': 4}
    }
mesh2 = SVL.makeDomainArea(options=opts2)
#SVL.printFormatted(mesh2['Nodes'])

#Merge both domain togeteher
SVL.mergeDomain(mesh1, mesh2)

#Assign the merge mesh to Entities
SVL.Entities['Nodes'] = mesh1['Nodes']
SVL.Entities['Elements'] = mesh1['Elements']
#SVL.renderData('element')

#Restrain degree of freedom
for nTag in SVL.Entities['Nodes']:
    if nTag <= 2:
        SVL.addRestrain(tag=nTag, dof=[1,2])
    else:
        SVL.addRestrain(tag=nTag, dof=1)

#Constraint degree of freedom
SVL.addConstraint(tag=-2, name='Equal', attributes={'stag':21, 'sdof': 2, 'mtag':23, 'mdof': 2})
SVL.addConstraint(tag=-3, name='Equal', attributes={'stag':22, 'sdof': 2, 'mtag':24, 'mdof': 2})
#SVL.printFormatted(SVL.Entities['Nodes'])

#Create function
fun = {'type': 'TimeSerie', 'file': 'ricker-SoilColumnElasticPlaneStrainPML.txt', 'dir': [0.0, 1.0E+05]}
SVL.addFunction(tag=1, name='TimeSerie', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'TimeSerie', 'list': [203, 204]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='SoilColumnElasticPlaneStrainPML', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8, 'nsamp': 5}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [23, 203]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'NODE', 'file': 'Velocity.out', 'ndps': 8, 'resp': 'vel', 'list': [23, 203]}
SVL.addRecorder(tag=3, attributes=rec)

rec = {'name': 'NODE', 'file': 'Acceleration.out', 'ndps': 8, 'resp': 'accel', 'list': [23, 203]}
SVL.addRecorder(tag=4, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 1000})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.010})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
