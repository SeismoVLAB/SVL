"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_F06'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2
SVL.Options['massform'] = 'lumped'

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Damping
SVL.addDamping(tag=1, name='Rayleigh', attributes={'am': 0.1244195110, 'ak': 0.0007878958, 'list': 'ALL'})

#Create Material
SVL.addMaterial(tag=1, name='Elastic2DPlaneStrain', attributes={'E': 1.3E+07, 'nu': 0.30, 'rho': 2000.0})
SVL.addMaterial(tag=2, name='Viscous1DLinear', attributes={'eta': 5.0E+04})

#Create Nodes (for quads)
nNodes = 101
for k in range(nNodes):
    SVL.addNode(tag=(2*k+1), ndof=2, coords=[0.00, float(k)])
    SVL.addNode(tag=(2*k+2), ndof=2, coords=[1.00, float(k)])
#Create Ndes (for zero)
SVL.addNode(tag=203, ndof=2, coords=[0.00, 0.00])
SVL.addNode(tag=204, ndof=2, coords=[1.00, 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
for k in range(nNodes):
    SVL.addRestrain(tag=(2*k+1), dof=2)
    SVL.addRestrain(tag=(2*k+2), dof=2)
SVL.addRestrain(tag=203, dof=[1, 2])
SVL.addRestrain(tag=204, dof=[1, 2])

#Create Element
for k in range(nNodes-1):
    SVL.addElement(tag=(k+1), conn=[ 2*k+1,  2*k+2,  2*k+4, 2*k+3], name='lin2DQuad4', attributes={'material': 1, 'th': 1.0, 'rule': 'Gauss', 'np': 4})
SVL.addElement(tag=101, conn=[1, 203], name='ZeroLength1D', attributes={'material': 2, 'dir': 1})
SVL.addElement(tag=102, conn=[2, 204], name='ZeroLength1D', attributes={'material': 2, 'dir': 1})

#Create function
fun = {'file': 'ricker.in', 'dir': [5.0E+04, 0.0]}
SVL.addFunction(tag=1, name='TimeSerie', attributes=fun)

fun = {'file': 'ricker.in', 'dir': [5.0E+04, 0.0]}
SVL.addFunction(tag=2, name='TimeSerie', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'TimeSerie', 'list': [1]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

load = {'fun': 2, 'type': 'TimeSerie', 'list': [2]}
SVL.addLoad(tag=2, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1,2], 'factor': [1.0, 1.0]}
SVL.addCombinationCase(tag=1, name='SoilColumn', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [1,201]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Velocity.out', 'ndps': 8, 'resp': 'vel', 'list': [1,201]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'NODE', 'file': 'Acceleration.out', 'ndps': 8, 'resp': 'accel', 'list': [1,201]}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 1000})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.01})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.printAll('Elements')
#SVL.renderData('element')
