#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 
ResultFigure = filepath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this   = filepath + '/Solution/CantileverShellBeam/'

#ANALYTICAL SOLUTION:
E   =  35000.0
P   = -10.0
rho =  0.10
L   =  10.00
h   =  1.00
I   =  1/12.0*h**4
k   = 3*E*I/L**3
dt  = 0.020
d   = 0.06
A   = 1.00

wn  = (1.875/L)**2*np.sqrt(E*I/rho/A)
wd  = wn*np.sqrt(1-d**2);

t = np.arange(dt, 4.60, dt)
x = P/k*(1 - np.exp(-d*wn*t)/np.sqrt(1-d**2)*np.cos(wd*t + np.arctan(-d/np.sqrt(1 - d**2))));

#SeismoVLAB SOLUTION:
displacement = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(10.5,9.0))
plt.plot(t+dt, x, 'r-', t, displacement[:,2], 'b.')
plt.xlabel("$t$", fontsize=30)
plt.ylabel("$u$", fontsize=30)
plt.xlim((0,4.5))
plt.ylim((-2.5,0.0))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-DY_Damped_3DPointLoad_Plate_Elastic_Shell4} and is 
defined to test \\texttt{lin3DShell4} element with material type \\texttt{Elastic2DPlaneStress}. For this example, all shell 
members have a rectangular cross-section with thickness $t = 1$, and modulus of elasticity, $E = 35000$. The beam is $10$ long 
and is discretized with 10 equal length shell elements and 22 nodes. A vertical dynamic load is placed at Node (11) and (22) 
of constant magnitude $5$. Rayleigh damping is added with $a_0 = 0$, and $a_1=0.02$. The responses are verified against analytical 
solution. Figure~\\ref{fig:Verification_Damped_3DPointLoad_Plate_Elastic_Shell4} shows the force displacement curve at node (11). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.350 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3DShell4} with \\texttt{Lin3DThinArea} Section.}\n")
LaTeXfile.write("\t\label{fig:Verification-DY_Damped_3DPointLoad_Plate_Elastic_Shell4}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.35\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Force displacement curve at (11): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_Damped_3DPointLoad_Plate_Elastic_Shell4}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.close()
