#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#Get file path
pwdpath = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwdpath + "/LaTeX/ModelTest.png" 
ResultFigure = pwdpath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
E        = 200E9
dt       = 0.025
this     = pwdpath + '/Solution/ZeroPlastic/'
openSeeS = pwdpath + '/OpenSees/'
time     = np.arange(dt, 5.0+dt, dt)

#OPENSEES SOLUTION:
nt = len(time)
strain1 = np.loadtxt(openSeeS + 'strain.out', dtype='float', skiprows=0)
stress1 = np.loadtxt(openSeeS + 'stress.out', dtype='float', skiprows=0)

#SeismoVLab SOLUTION:
strain2 = np.loadtxt(this + 'Strain.0.out', dtype='float', skiprows=2)
stress2 = np.loadtxt(this + 'Stress.0.out', dtype='float', skiprows=2)

#COMPUTES ERRORS:
delta = abs(strain1[0:nt,1] - strain2)

#Root mean square error.
rms = np.sqrt(np.mean(delta**2))

#Maximum absolute difference.
mad = max(delta)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 3, 1)
plt.plot(time, strain2, 'r-', strain1[:,0], strain1[:,1], 'b.')
plt.xlabel("$t$"               , fontsize=30)
plt.ylabel("$\epsilon_{11}(t)$", fontsize=30)
plt.xlim((0,5))
plt.grid(True)

plt.subplot(1, 3, 2)
plt.plot(time, stress2, 'r-', stress1[:,0], -stress1[:,1], 'b.')
plt.xlabel("$t$"             , fontsize=30)
plt.ylabel("$\sigma_{11}(t)$", fontsize=30)
plt.xlim((0,5))
plt.grid(True)

plt.subplot(1, 3, 3)
plt.plot(strain2, stress2, 'r-', strain1[:,1], -stress1[:,1], 'b.')
plt.xlabel("$\epsilon_{11}(t)$", fontsize=30)
plt.ylabel("$\sigma_{11}(t)$"  , fontsize=30)
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_Plastic1DJ2} and is defined to 
test \\texttt{Plastic1DJ2} element with material type \\texttt{Plastic1DJ2}. The material has modulus of elasticity 
$E = 200 \; GPa$, and a Poisson's ratio $\\nu = 0.25$, hardening modulus $H = 375$, and kinematic modulus $K = 0.0$, the yield 
stress is taken as $\sigma_Y = 250$. The nodes (1), and (2) have the coordinate $(x,y) = (0.0, 0.0)$. Node (1) is 
fixed in \\textrm{X}- and \\textrm{Y}-directions, while node (2) is fixed in \\textrm{Y}-direction. For dynamic analysis, the nodal stress 
applied at node (2) is defined as $\sigma(t) = 107.5 \cdot t \, \sin(2 \pi\,t) \; Pa$. The responses are verified against 
analytical solution. Figure~\\ref{fig:Verification_Plastic1DJ2} shows uniaxial strain, stress, and material 
constitutive response at node (2). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.185 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{ZeroLength1D} with \\texttt{Plastic1DJ2} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_Plastic1DJ2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.945\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): Analytical ({\color{blue}{$\dots$}}), SeismoVLab (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_Plastic1DJ2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The root mean square error for the strain is : \\texttt{%#1.6g}, while The maximum absolute difference for the strain is : \\texttt{%#1.6g}." % (rms, mad))
LaTeXfile.close()
