#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#Get file path
pwdpath = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwdpath + "/LaTeX/ModelTest.png" 
ResultFigure = pwdpath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
E      = 200E9
dt     = 0.025
this   = pwdpath + '/Solution/ZeroElastic/'
time   = np.arange(0.0, 5.0, dt)

#ANALYTICAL SOLUTION:
stress1  = np.loadtxt('StressLoad.txt',dtype='float', skiprows=2)
strain1  = stress1/E

#SeismoVLAB SOLUTION:
strain2 = np.loadtxt(this + 'Strain.0.out',dtype='float', skiprows=2)
stress2 = np.loadtxt(this + 'Stress.0.out',dtype='float', skiprows=2)

#COMPUTES ERRORS:
delta = abs(strain1 - strain2)

#Root mean square error.
rms = np.sqrt(np.mean(delta**2))

#Maximum absolute difference.
mad = max(delta)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 3, 1)
plt.plot(time, strain2, 'r-', time, strain1, 'b.')
plt.xlabel("$t$"               , fontsize=30)
plt.ylabel("$\epsilon_{11}(t)$", fontsize=30)
plt.xlim((0,5.0))
plt.grid(True)

plt.subplot(1, 3, 2)
plt.plot(time, stress2, 'r-', time, stress1, 'b.')
plt.xlabel("$t$"             , fontsize=30)
plt.ylabel("$\sigma_{11}(t)$", fontsize=30)
plt.xlim((0,5.0))
plt.grid(True)

plt.subplot(1, 3, 3)
plt.plot(strain2, stress2, 'r-', strain1, stress1, 'b.')
plt.xlabel("$\epsilon_{11}(t)$", fontsize=30)
plt.ylabel("$\sigma_{11}(t)$"  , fontsize=30)
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-model_Elastic1DLinear} is 
defined to test \\texttt{ZeroLength1D} element with material type \\texttt{Elastic1DLinear}. The material 
has a elasticity moduli $E = 200 \;GPa$, and a Poisson's ratio $\\nu = 0.25$. Both nodes (1) and 
(2) have coordinate $(x,y) = (0.0, 0.0)$. Node (1) is fixed in \\textrm{X} and \\textrm{Y} directions, while 
node (2) is fixed in \\textrm{Y} direction. For dynamic analysis, the nodal stress applied at node (2) is 
defined as $\sigma(t) = 107.5 \cdot t \, \sin(2 \pi\,t) \; Pa$. Responses are verified against analytical 
solution. Figure~\\ref{fig:Verification_Elastic1DLinear} shows the strain, stress, and material 
constitutive responses at (2). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.185 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{ZeroLength1D} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_Elastic1DLinear}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.925\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_Elastic1DLinear}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The root mean square error for the strain is : \\texttt{%#1.6g}, while The maximum absolute difference for the strain is : \\texttt{%#1.6g}." % (rms, mad))
LaTeXfile.close()
