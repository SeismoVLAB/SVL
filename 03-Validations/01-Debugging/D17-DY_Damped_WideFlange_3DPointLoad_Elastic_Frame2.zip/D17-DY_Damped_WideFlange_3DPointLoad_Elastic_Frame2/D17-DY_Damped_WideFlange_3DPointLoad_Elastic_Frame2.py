"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_D17'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3
SVL.Options['massform'] = 'Lumped'

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Damping
SVL.addDamping(tag=1, name='Rayleigh', attributes={'am': 0.0, 'ak': 0.020, 'list': 'ALL'})

#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 3.5E+04, 'nu': 0.33, 'rho': 0.10})

#CReate Section
SVL.addSection(tag=1, name='Lin3DWideFlange', model='Plain', attributes={'material': 1, 'b': 1.0, 'h': 1.0, 'tw': 0.1, 'tf': 0.1, 'theta': 0.0, 'ip': 10})

#Create Nodes
nNodes = 17
theta = np.pi/4.0
for k in range(nNodes):
    SVL.addNode(tag=(k+1), ndof=6, coords=[10.0*k/(nNodes-1)*math.cos(theta), 10.0*k/(nNodes-1)*math.sin(theta), 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2, 3, 4, 5, 6])

#Create Element
for k in range(nNodes-1):
    SVL.addElement(tag=(k+1), conn=[k+1, k+2], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 5})
#SVL.printAll('Elements')

#Create a Function
fun = {'file': 'PointLoad.txt', 'dir': [0.0, 0.0, -1.0, 0.0, 0.0, 0.0]}
SVL.addFunction(tag=1, name='TimeSerie', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'TimeSerie', 'list': [17]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='CantileverBeam', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8, 'nsamp': 1}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [17]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': [1]}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 230})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.02})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('partition')
#SVL.printAll('Nodes')
