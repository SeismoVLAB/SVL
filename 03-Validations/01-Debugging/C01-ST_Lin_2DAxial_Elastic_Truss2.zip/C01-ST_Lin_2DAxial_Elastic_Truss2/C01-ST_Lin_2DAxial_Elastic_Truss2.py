"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_C01'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 6.89E+10, 'nu': 0.33, 'rho': 0.0})

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.00, 0.00])
SVL.addNode(tag=2, ndof=2, coords=[1.00, 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=2, dof=2)

#Create Element
SVL.addElement(tag=1, conn=[1, 2], name='lin2DTruss2', attributes={'material': 1, 'area': 1.0})

#Create function
fun = {'mag': 1000.0, 'dir': [1.0, 0.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': [2]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='Truss2DAxial', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [2]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Stress.out', 'ndps': 8, 'resp': 'Stress', 'list': [1]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Strain.out', 'ndps': 8, 'resp': 'Strain', 'list': [1]}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()
