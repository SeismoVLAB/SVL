#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
P = 1000
A = 1.00
L = 1.00
E = 68.9000E+9

this   = filepath + '/Solution/Truss2DAxial/'

#ANALYTICAL SOLUTION:
Disp   = P*L/A/E;
Stress = P/A;
Strain = Disp/L;

#SeismoVLab SOLUTION:
dis    = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)
strain = np.loadtxt(this + 'Strain.0.out',dtype='float', skiprows=2)
stress = np.loadtxt(this + 'Stress.0.out',dtype='float', skiprows=2)

err1 = abs(dis[0] - Disp)/Disp
err2 = abs(stress - Stress)/Stress
err3 = abs(strain - Strain)/Strain

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_lin2DTruss2} and is defined 
to test \\texttt{lin2DTruss2} element with material type \\texttt{Elastic1DLinear}. The material has modulus 
of elasticity $E = 68.9 \; GPa$. The nodes (1), and (2) have the coordinates $(0.0, 0.0)$ and $(1.0, 0.0)$ 
respectively. Node (1) is fixed in \\textrm{X}-, and \\textrm{Y}-directions, while node (2) is fixed 
in \\textrm{Y}-direction. The truss element has an area of $A = 0.0025 \; m^2$, and a length of $L = 1.00 \; m$. 
For static analysis, the nodal force applied at node (2) is defined as $P = 1000 \; N$. The responses are 
verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.275 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DTruss2} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_lin2DTruss2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("In this case, the relative absolute error for the displacement is : \\texttt{%#1.6g}, while The relative absolute error for the strain and stress are : \\texttt{%#1.6g}, \\texttt{%#1.6g} repectively." % (err1, err2, err3))
LaTeXfile.close()
