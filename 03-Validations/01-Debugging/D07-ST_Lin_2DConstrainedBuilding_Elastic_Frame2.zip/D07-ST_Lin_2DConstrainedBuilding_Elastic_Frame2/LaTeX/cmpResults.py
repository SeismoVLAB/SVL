#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
this   = filepath + '/Solution/Building/'

#ANALYTICAL SOLUTION:
delta = 5.7016E-3
reaction0 = np.array([-500.0, -350.0, 875.0])
reaction1 = np.array([-500.0,  350.0, 875.0])

#SeismoVLAB SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=2)
force = np.loadtxt(this + 'InternalForce.0.out',dtype='float', skiprows=3)

#COMPUTES ERRORS:
error0 = abs((nodal[0] - delta)/delta)
error1 = abs(max(np.divide(force[[0, 1, 2]] - reaction0, reaction0)))
error2 = abs(max(np.divide(force[[9,10,11]] - reaction1, reaction1)))

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-building_Elastic1DLinear} is a portal frame 
defined to test \\texttt{lin2DFrame2} element with material type \\texttt{Elastic1DLinear}, local axis transformations 
and kinemtic constraints. The material has a elasticity moduli $E = 2.35 \;GPa$, and a Poisson's ratio $\\nu = 0.20$. 
Nodes (1), (8) and (25) have coordinate $(0.0, 0.0)$, $(0.0, 3.5)$, and $(5.0, 0.0)$ respectively. Node (1) and (25) are 
fixed in \\textrm{X} and \\textrm{Y} directions. The Bernoulli beam is employed to model columns with rectangular cross 
section $h = b = 0.2 \; m$ and beams with rectangular cross section $h = 1.0 \; m$ and $b = 0.2 \; m$. A horizontal load 
is placed at node (8) with magnitude $P = 1 \; kN$, and kinematic constraints are enforced on the horizontal direction 
for all nodes from (8) to (18). Responses are verified against analytical (simplified) solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.600 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DFrame2} with \\texttt{Elastic1DLinear} material and kinematic constraints.}\n")
LaTeXfile.write("\t\label{fig:Verification-building_Elastic1DLinear}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the horizontal deformation at node (8) is : \\texttt{%#1.6g}. The maximum relative error for the reaction forces at node (1) and (25) are : \\texttt{%#1.6g} and \\texttt{%#1.6g} repectively." % (error0, error1, error2))
LaTeXfile.close()
