"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_D07'
SVL.Options['format'] = 'json'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 2.35E+09, 'nu': 0.20, 'rho': 0.00})

#CReate Section
SVL.addSection(tag=1, name='Lin2DRectangular', model='Plain', attributes={'material': 1, 'b': 0.2, 'h': 0.2})
SVL.addSection(tag=2, name='Lin2DRectangular', model='Plain', attributes={'material': 1, 'b': 0.2, 'h': 1.0})

#Create Nodes
SVL.addNode(tag=1, ndof=3, coords=[0,0])
SVL.addNode(tag=2, ndof=3, coords=[0,0.5])
SVL.addNode(tag=3, ndof=3, coords=[0,1])
SVL.addNode(tag=4, ndof=3, coords=[0,1.5])
SVL.addNode(tag=5, ndof=3, coords=[0,2])
SVL.addNode(tag=6, ndof=3, coords=[0,2.5])
SVL.addNode(tag=7, ndof=3, coords=[0,3])
SVL.addNode(tag=8, ndof=3, coords=[0,3.5])
SVL.addNode(tag=9, ndof=3, coords=[0.5,3.5])
SVL.addNode(tag=10, ndof=3, coords=[1,3.5])
SVL.addNode(tag=11, ndof=3, coords=[1.5,3.5])
SVL.addNode(tag=12, ndof=3, coords=[2,3.5])
SVL.addNode(tag=13, ndof=3, coords=[2.5,3.5])
SVL.addNode(tag=14, ndof=3, coords=[3,3.5])
SVL.addNode(tag=15, ndof=3, coords=[3.5,3.5])
SVL.addNode(tag=16, ndof=3, coords=[4,3.5])
SVL.addNode(tag=17, ndof=3, coords=[4.5,3.5])
SVL.addNode(tag=18, ndof=3, coords=[5,3.5])
SVL.addNode(tag=19, ndof=3, coords=[5,3])
SVL.addNode(tag=20, ndof=3, coords=[5,2.5])
SVL.addNode(tag=21, ndof=3, coords=[5,2])
SVL.addNode(tag=22, ndof=3, coords=[5,1.5])
SVL.addNode(tag=23, ndof=3, coords=[5,1])
SVL.addNode(tag=24, ndof=3, coords=[5,0.5])
SVL.addNode(tag=25, ndof=3, coords=[5,0])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2, 3])
SVL.addRestrain(tag=25, dof=[1, 2, 3])

#Constraint degree of freedom
SVL.addConstraint(tag=-2, name='Equal', attributes={'stag': 8, 'sdof': 1, 'mtag': 18, 'mdof': 1})
SVL.addConstraint(tag=-3, name='Equal', attributes={'stag': 9, 'sdof': 1, 'mtag': 18, 'mdof': 1})
SVL.addConstraint(tag=-4, name='Equal', attributes={'stag': 10, 'sdof': 1, 'mtag': 18, 'mdof': 1})
SVL.addConstraint(tag=-5, name='Equal', attributes={'stag': 11, 'sdof': 1, 'mtag': 18, 'mdof': 1})
SVL.addConstraint(tag=-6, name='Equal', attributes={'stag': 12, 'sdof': 1, 'mtag': 18, 'mdof': 1})
SVL.addConstraint(tag=-7, name='Equal', attributes={'stag': 13, 'sdof': 1, 'mtag': 18, 'mdof': 1})
SVL.addConstraint(tag=-8, name='Equal', attributes={'stag': 14, 'sdof': 1, 'mtag': 18, 'mdof': 1})
SVL.addConstraint(tag=-9, name='Equal', attributes={'stag': 15, 'sdof': 1, 'mtag': 18, 'mdof': 1})
SVL.addConstraint(tag=-10, name='Equal', attributes={'stag': 16, 'sdof': 1, 'mtag': 18, 'mdof': 1})
SVL.addConstraint(tag=-11, name='Equal', attributes={'stag': 17, 'sdof': 1, 'mtag': 18, 'mdof': 1})

#Create Element
SVL.addElement(tag=1, conn=[1,2], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=2, conn=[2,3], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=3, conn=[3,4], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=4, conn=[4,5], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=5, conn=[5,6], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=6, conn=[6,7], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=7, conn=[7,8], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=8, conn=[8,9], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=9, conn=[9,10], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=10, conn=[10,11], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=11, conn=[11,12], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=12, conn=[12,13], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=13, conn=[13,14], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=14, conn=[14,15], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=15, conn=[15,16], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=16, conn=[16,17], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=17, conn=[17,18], name='lin2DFrame2', attributes={'section': 2, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=18, conn=[18,19], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=19, conn=[19,20], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=20, conn=[20,21], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=21, conn=[21,22], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=22, conn=[22,23], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=23, conn=[23,24], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
SVL.addElement(tag=24, conn=[24,25], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 3})
#SVL.printAll('Elements')

#Create function
fun = {'mag': 1000.0, 'dir': [1.0, 0.0, 0.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': [8]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='Building', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': 8}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': [1, 24]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('partition')
#SVL.printAll('Nodes')
