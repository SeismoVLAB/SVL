#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
this     = filepath + '/Solution/Model2D-SSI/'
opensees = filepath + '/OpenSeeS/'

#ANALYTICAL SOLUTION:
nodalOpenSees = np.loadtxt(opensees + 'DisplacementTop.out',dtype='float')
forceOpenSees = np.loadtxt(opensees + 'ElementForce.out',dtype='float')

#SeismoVLab SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=2)
force = np.loadtxt(this + 'InternalForce.0.out',dtype='float', skiprows=4)

#COMPUTES ERRORS:
error1 = max(np.divide(nodalOpenSees - nodal[[0,1]], nodalOpenSees));
error2 = max(np.divide(forceOpenSees - force, forceOpenSees));

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-building_SSI} is a portal frame supported on a 
linear elastic soil in plain strain defined to test \\texttt{lin2DFrame2} and \\texttt{lin2DQuad4} elements with material 
type \\texttt{Elastic1DLinear} and \\texttt{Elastic2DPlaneStrain} respectively, and kinemtic constraints between solid and 
strcutural elements. The soil material has a elasticity moduli $E = 50.0 \,MPa$, and a Poisson's ratio $\\nu = 0.25$ and beam 
and column material has a elasticity moduli $E = 25.0 \,GPa$, and a Poisson's ratio $\\nu = 0.25$. Nodes (3322), (3348) 
and (3374) have coordinate $(5.0, 10.0)$, $(10.0, 10.0)$, and $(15.0, 10.0)$ respectively. All nodes at the boundary represented 
by a thick solid-black line are fixed in \\textrm{X} and \\textrm{Y} directions. The Bernoulli beam is employed to model columns and beams with rectangular 
cross section $h = 0.9\, m$ and $b = 0.6 \; m$. A horizontal load is placed at node (3347) with magnitude $P = 100 \; kN$, and kinematic 
constraints are enforced on the horizontal and vertical direction for all nodes in the interface column and soil. Responses are verified 
against numerical (OpenSees) solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.85 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DFrame2} with \\texttt{Elastic1DLinear} material and kinematic constraints.}\n")
LaTeXfile.write("\t\label{fig:Verification-building_SSI}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the horizontal deformation at node (3347) is : \\texttt{%#1.6g}. The maximum relative error for the reaction forces at node (3322), (3348), and (3374) are : \\texttt{%#1.6g}." % (error1, error2))
LaTeXfile.close()
