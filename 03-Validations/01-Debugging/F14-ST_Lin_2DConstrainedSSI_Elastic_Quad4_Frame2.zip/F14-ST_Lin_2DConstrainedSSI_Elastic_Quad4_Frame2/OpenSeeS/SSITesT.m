 clear;
 close all;


 ncol = 3; %1
 nEmb = 5;
 xcol = [5.0,10.0,15.0]; %10.0; %

 dx = 0.25;
 dy = 0.25;
 dz = 0.10;

 x = 0.0:dx:20.0;
 y = 0.0:dy:10.0;
 z = 10.0:dz:12.50;

 nx = length(x);
 ny = length(y);
 nz = length(z);
 
 bx = xcol(1):dx:xcol(end);
 bnx = length(bx);

%------------------------------------------------------------------------
% QUADS:
%------------------------------------------------------------------------
 nQuads = (nx-1)*(ny-1);

 [X,Y] = meshgrid(x,y);
 Qxyz  = [X(:), Y(:)];
 Qconn = zeros(nQuads,4);

 for i = 1:nx-1,
     for j = 1:ny-1,
         Qconn((ny-1)*(i-1) + j,:) = [j + (i-1)*ny, j + i*ny, j + i*ny + 1, j + (i-1)*ny + 1];
     end;
 end;
 
%------------------------------------------------------------------------
% FRAMES:
%------------------------------------------------------------------------
 k = 1;
 Fxyz = zeros(ncol*nz + ncol*nEmb + bnx-ncol ,2);
 for i = 1:ncol,
     for j = 1:nz,
         Fxyz(k,:) = [xcol(i),z(j)];
         k = k + 1;
     end
 end;
 
 for i = 1:ncol,
     for j = 1:nEmb,
         Fxyz(k,:) = [xcol(i),y(end) - (nEmb - j + 1)*dy];
         k = k + 1;
     end
 end
 nnn = k;
 bIndex = zeros(bnx,1);
 mmm = 1;
for i = 1:bnx,
     if(sum(bx(i) == xcol) == 0)
          Fxyz(k,:) = [bx(i),z(end)];
          bIndex(i) = k; 
          k = k + 1;
     else
         bIndex(i) = nz*mmm;
         mmm = mmm + 1;
     end
 end;

 nFrame = ncol*nz - 1 + ncol*nEmb + bnx-3;
 Fconn = zeros(nFrame,4);

 k = 1;
 for i = 1:ncol,
     for j = 1:nz-1,
         Fconn(k,:) = [j, j+1, j+1, j] + nz*(i-1);
         k = k + 1;
     end
 end;
 
 for i = 1:ncol,
     for j = 1:nEmb-1,
         Fconn(k,:) = [(i-1)*nEmb + j + ncol*nz, (i-1)*nEmb + j + ncol*nz + 1, (i-1)*nEmb + j + ncol*nz + 1, (i-1)*nEmb + j + ncol*nz];
         k = k + 1;
     end;
     j = nEmb;
     Fconn(k,:) = [(i-1)*nEmb + j + ncol*nz,(i-1)*nz + 1,(i-1)*nz + 1,(i-1)*nEmb + j + ncol*nz];
     k = k + 1;
 end;
 
 for i = 1:(bnx-1),
     Fconn(k,:) = [bIndex(i),bIndex(i+1),bIndex(i+1),bIndex(i)];
     k = k + 1;
 end;

%------------------------------------------------------------------------
% OPENSEES:
%------------------------------------------------------------------------
 fileID = fopen('SSI_TesT.tcl','w');
 fprintf(fileID,'model BasicBuilder -ndm 2 -ndf 2 \n');
 fprintf(fileID,'\n');
 fprintf(fileID,'nDMaterial ElasticIsotropic 1 50000000.00000 0.25000 2000.00000 \n');
 fprintf(fileID,'\n');

 for i =1:size(Qxyz,1),
     fprintf(fileID,'node %d %1.3f %1.3f \n', [i, Qxyz(i,:)]);
 end;
 fprintf(fileID,'\n');

 fix = [1:ny, ny+1:ny:ny*(nx-1),ny*(nx-1)+1:nx*ny]; %1:ny:ny*nx; %
 for i = 1:length(fix),
     fprintf(fileID,'fix %d 1 1 \n', fix(i));
 end
 fprintf(fileID,'\n');

 for i =1:size(Qconn,1),
     fprintf(fileID,'element quad %d %d %d %d %d 1.00 PlaneStrain 1 \n', [i, Qconn(i,:)]);
 end;
 fprintf(fileID,'\n');

 fprintf(fileID,'model BasicBuilder -ndm 2 -ndf 3 \n');
 fprintf(fileID,'\n');

 n = size(Qxyz,1);
 for i =1:size(Fxyz,1),
     fprintf(fileID,'node %d %1.3f %1.3f \n', [i + n, Fxyz(i,:)]);
 end;
 fprintf(fileID,'\n');

 nNodes = size(Qxyz,1) + size(Fxyz,1);
 
 
 for i = 1:ncol,
     for j = 1:nEmb,
         indj = (i-1)*nEmb + j + ncol*nz;
         indi = find(Qxyz(:,1) == Fxyz(indj,1) & Qxyz(:,2) ==Fxyz(indj,2));
         
         fprintf(fileID,'equalDOF %d %d 1 2 \n', [indi,indj+n]);
         
     end;
     indi = find(Qxyz(:,1) == xcol(i) & Qxyz(:,2) == y(end));
     fprintf(fileID,'equalDOF %d %d 1 2 \n', [indi,n + (i-1)*nz + 1]);
     
 end
 fprintf(fileID,'\n');

 m = size(Qconn,1);
 fprintf(fileID,'geomTransf Linear 1 \n');
 for i =1:size(Fconn,1),
     fprintf(fileID,'element elasticBeamColumn %d %d %d 5.400000e-01 25000000000 3.645000e-02 1 \n', [i+m, Fconn(i,[1,2]) + n]);
 end;
 fprintf(fileID,'\n');
 
 fprintf(fileID,'timeSeries Linear 1 \n');
 fprintf(fileID,'pattern Plain 1 1 { \n');
 fprintf(fileID,'\t load %d 100000 0.0 0.0 \n',n + nz);
 fprintf(fileID,'} \n');
 fprintf(fileID,'\n');

 fprintf(fileID,'recorder Node -file DisplacementTop.out -node %d -dof 1 2 disp \n',n + nz);
 fprintf(fileID,'recorder Node -file DisplacementNodes.out -nodeRange 1 %d -dof 1 2 disp \n',nNodes);
 fprintf(fileID,'recorder Element -file ElementForce.out -ele %d %d %d globalForce \n',[nQuads + 1,nQuads + nz,nQuads + 2*nz - 1]);
 fprintf(fileID,'\n');
 fprintf(fileID,'\n');

 fprintf(fileID,'constraints Transformation \n');
 fprintf(fileID,'numberer Plain \n');
 fprintf(fileID,'algorithm Linear \n');
 fprintf(fileID,'system ProfileSPD \n');
 fprintf(fileID,'integrator LoadControl 1.0 \n');
 fprintf(fileID,'analysis Static \n');
 fprintf(fileID,'analyze 1 \n');

 fprintf(fileID,'\n');
 fprintf(fileID,'wipe');
    
 fclose(fileID);

 system('./OpenSees < SSI_TesT.tcl');
 file1 = 'DisplacementNodes.out';


 figure(1);
 xyz = [Qxyz;Fxyz];
 p   = patch('Vertices',xyz,'Faces',Qconn,'facecolor',[0.675 0.925 1],'facealpha',0.80,'LineWidth',0.5);
 h   = patch('Vertices',xyz,'Faces',Fconn + n,'facecolor',[0.675 0.925 1],'MarkerSize',3,'Marker','.','LineWidth',2.0);
 axis equal;
 grid on;
 box on;
 drawnow;


 amp = 100;
 values1 = load(file1);

 xdir = values1(1:2:end)';
 ydir = values1(2:2:end)';

 set(p,'Vertices',xyz + amp*[xdir,ydir]);
 set(h,'Vertices',xyz + amp*[xdir,ydir]);
 drawnow;
