#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
L      = 1.0
h      = 0.2
E      = 100000.0
I      = 1.0/12.0*h**4
q      = 10.0

this   = filepath + '/Solution/QuadPlaneStrainElasticStatic/'

#ANALYTICAL SOLUTION:
delta    = -q*L**4/8.0/E/I
reaction = np.array([0.0, q*L, -q*L**2/2.0])

#SeismoVLAB SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out' ,dtype='float', skiprows=3)
force = np.loadtxt(this + 'Reaction.0.out',dtype='float', skiprows=3)

nodeForce  = force[1] + force[3] #+ q*h/2.0
nodeMoment = h/2.0*(force[2] - force[0])
force      = np.array([nodeForce, nodeMoment])

#COMPUTES ERRORS:
error0 = abs((nodal[1] - delta)/delta);
error1 = max(abs(np.divide(force - reaction[[1,2]], reaction[[1,2]])));

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-Cantilever_Quad4_2DSurfaceLoad} is a cantilever beam 
defined to test \\texttt{lin2DQuad4} elements with material type \\texttt{Elastic2DPlaneStress} and a point load. The 
material has a elasticity modulus $E = 100000 \;Pa$, and a Poisson's ratio $\\nu = 0.30$. Nodes (1) and node (11) have 
coordinate $(0.0, 0.0)$ and $(1.0, 0.0)$ respectively. Node (1) and (2) are fixed i.e, displacement in horizontal and 
vertical directions are fixed, while the others are free. The the element thickness is $t = 0.20 \; m$, and the element 
height is $h = 0.20 \; m$. The beam is subjected to a distributed load $q = 10\;[N/m]$ at Node (12). Responses are verified against 
analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.350 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DQuad4} and Surface Load in 2D.}\n")
LaTeXfile.write("\t\label{fig:Verification-Cantilever_Quad4_2DSurfaceLoad}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the vertical deformation at node (12) is : \\texttt{%#1.6g}. The maximum relative error for the reaction forces at node (1) is : \\texttt{%#1.6g}." % (error0, error1))
LaTeXfile.close()
