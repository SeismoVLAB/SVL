#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 
ResultFigure = filepath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this    = filepath + '/Solution/SupportMotion/'

#ANALYTICAL SOLUTION:
L   = 10.0
x   = np.arange(0.00, L, 0.01)
y   = -0.5*(1 - 3*np.power(x,2)/L**2 + 2.0*np.power(x,3)/L**3) - 0.1*(x - 2.0*np.power(x,2)/L + np.power(x,3)/L**2)

#SeismoVLAB SOLUTION:
pos   = np.arange(0.00, L+0.1, 0.625)
displacement = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=18)
displacement = displacement[24,:]
displacement = displacement[1::3]

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(10.5,9.0))
plt.plot(pos, displacement, 'r.', x, y, 'b-')
plt.xlabel("$x$", fontsize=30)
plt.ylabel("$v$", fontsize=30)
plt.xlim((0,10.0))
plt.ylim((-0.6,0.0))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:D22-DY_Rectangular_SupportMotion_Elastic_Frame2} and is 
defined to test \\texttt{lin3Drame2} element with material type \\texttt{Elastic1DLinear}. For this example, 
all beam members have a rectangular cross-section with height $h = 1$ and width $b=1$, and modulus of elasticity, 
$E = 20000$. The beam is $10$ units long and is discretized with 16 equal length beam elements and 17 nodes. Support motion 
is enforced so that $\\Delta = 0.5$, and $\\Theta = 0.1$ at Node (1). The responses are verified against analytical 
solution. Figure~\\ref{fig:Verification_D22-DY_Rectangular_SupportMotion_Elastic_Frame2} shows the displacement in vertical 
direction along the beam. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.4250 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3Drame2} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:D22-DY_Rectangular_SupportMotion_Elastic_Frame2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.350\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal Displacement along the beam: Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_D22-DY_Rectangular_SupportMotion_Elastic_Frame2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.close()
