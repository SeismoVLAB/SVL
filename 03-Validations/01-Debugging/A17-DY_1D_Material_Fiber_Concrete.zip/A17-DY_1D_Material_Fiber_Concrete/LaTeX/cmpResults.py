#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#Get file path
pwdpath = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwdpath + "/LaTeX/ModelTest.png" 
ResultFigure = pwdpath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
dt       = 0.01
this     = pwdpath + '/Solution/ZeroPlastic/'
openSeeS = pwdpath + '/OpenSees/'
time     = np.arange(dt, 20.0, dt)

#OPENSEES SOLUTION:
nt = len(time)
results = np.loadtxt(openSeeS + 'results.out', dtype='float', skiprows=0)

#SeismoVLAB SOLUTION:
strain2 = np.loadtxt(this + 'Strain.0.out', dtype='float', skiprows=3)
stress2 = np.loadtxt(this + 'Stress.0.out', dtype='float', skiprows=3)

#COMPUTES ERRORS:
delta = abs(results[0:nt,0] - strain2)

#Root mean square error.
rms = np.sqrt(np.mean(delta**2))

#Maximum absolute difference.
mad = max(delta)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 3, 1)
plt.plot(time, strain2, 'r-', time[:nt:5], results[:nt:5,0], 'b.')
plt.xlabel("$t$"               , fontsize=30)
plt.ylabel("$\epsilon_{11}(t)$", fontsize=30)
plt.xlim((0,20))
plt.grid(True)

plt.subplot(1, 3, 2)
plt.plot(time, stress2, 'r-', time[:nt:5], results[:nt:5,1], 'b.')
plt.xlabel("$t$"             , fontsize=30)
plt.ylabel("$\sigma_{11}(t)$", fontsize=30)
plt.xlim((0,20))
plt.grid(True)

plt.subplot(1, 3, 3)
plt.plot(strain2, stress2, 'r-', results[:nt:5,0], results[:nt:5,1], 'b.')
plt.xlabel("$\epsilon_{11}(t)$", fontsize=30)
plt.ylabel("$\sigma_{11}(t)$"  , fontsize=30)
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_Concrete1DFiber} and is defined to 
test \\texttt{ZeroLength1D} element with material type \\texttt{Concrete1DFiber}. The material has compression strength
$f_c = -5.73$, $e_{cc} = -0.003$, crusing strength $f_{cu} = -1.146$, $e_{cu} = -0.021$, $\\lambda = 0.05$, tensile strength 
$ft = 0.28$, elasticity modulus $Et = 430.0$. The nodes (1), and (2) have the coordinate $(x,y) = (0.0, 0.0)$. Node (1) and (2) 
are fixed in \\textrm{X}- and \\textrm{Y}-directions, but a horizontal support motion is prescribed at Node (2) as 
$\\Delta(t) = 0.0013 \cdot t \, \sin(0.4 \pi\,t)$. The responses are verified against OpenSees solution. 
Figure~\\ref{fig:Verification_Concrete1DFiber} shows uniaxial strain, stress, and material constitutive response 
at node (2). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.25 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{ZeroLength1D} with \\texttt{Concrete1DFiber} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_Concrete1DFiber}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.945\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): OpenSees ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_Concrete1DFiber}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The root mean square error for the strain is : \\texttt{%#1.6g}, while The maximum absolute difference for the strain is : \\texttt{%#1.6g}." % (rms, mad))
LaTeXfile.close()
