"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_E02'
SVL.Options['format'] = 'json'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic2DPlaneStress', attributes={'E': 1.0E+05, 'nu': 0.30, 'rho': 0.00})

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.0,0.0])
SVL.addNode(tag=2, ndof=2, coords=[0.2,0.0])
SVL.addNode(tag=3, ndof=2, coords=[0.2,0.2])
SVL.addNode(tag=4, ndof=2, coords=[0.0,0.2])
SVL.addNode(tag=5, ndof=2, coords=[0.4,0.0])
SVL.addNode(tag=6, ndof=2, coords=[0.4,0.2])
SVL.addNode(tag=7, ndof=2, coords=[0.6,0.0])
SVL.addNode(tag=8, ndof=2, coords=[0.6,0.2])
SVL.addNode(tag=9, ndof=2, coords=[0.8,0.0])
SVL.addNode(tag=10, ndof=2, coords=[0.8,0.2])
SVL.addNode(tag=11, ndof=2, coords=[1.0,0.0])
SVL.addNode(tag=12, ndof=2, coords=[1.0,0.2])
SVL.addNode(tag=13, ndof=2, coords=[0.1,0.0])
SVL.addNode(tag=14, ndof=2, coords=[0.2,0.1])
SVL.addNode(tag=15, ndof=2, coords=[0.1,0.2])
SVL.addNode(tag=16, ndof=2, coords=[0.0,0.1])
SVL.addNode(tag=17, ndof=2, coords=[0.3,0.0])
SVL.addNode(tag=18, ndof=2, coords=[0.4,0.1])
SVL.addNode(tag=19, ndof=2, coords=[0.3,0.2])
SVL.addNode(tag=20, ndof=2, coords=[0.5,0.0])
SVL.addNode(tag=21, ndof=2, coords=[0.6,0.1])
SVL.addNode(tag=22, ndof=2, coords=[0.5,0.2])
SVL.addNode(tag=23, ndof=2, coords=[0.7,0.0])
SVL.addNode(tag=24, ndof=2, coords=[0.8,0.1])
SVL.addNode(tag=25, ndof=2, coords=[0.7,0.2])
SVL.addNode(tag=26, ndof=2, coords=[0.9,0.0])
SVL.addNode(tag=27, ndof=2, coords=[1.0,0.1])
SVL.addNode(tag=28, ndof=2, coords=[0.9,0.2])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=4, dof=[1, 2])
SVL.addRestrain(tag=16, dof=[1, 2])

#Create Element
SVL.addElement(tag=1, conn=[ 1,  2,  3,  4, 13, 14, 15, 16], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=2, conn=[ 2,  5,  6,  3, 17, 18, 19, 14], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=3, conn=[ 5,  7,  8,  6, 20, 21, 22, 18], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=4, conn=[ 7,  9, 10,  8, 23, 24, 25, 21], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=5, conn=[ 9, 11, 12, 10, 26, 27, 28, 24], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})

#Create function
fun = {'mag': 10.0, 'dir': [0.0, -1.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'type': 'Constant', 'fun': 1, 'list': [12]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='QuadPlaneStrainElasticStatic', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [11,12]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': [1]}
SVL.addRecorder(tag=2, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
