#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

dt    = 0.003
time  = np.arange(0.0, 4.5, dt)

#FIGURE OUTPUT NAMES:
ModelFigure  = os.getcwd() + "/LaTeX/ModelTest.png" 
ResultFigure = os.getcwd() + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this   = 'Solution/SupportMotion/'

#ANALYTICAL SOLUTION:
solution = np.loadtxt('OpenSEES/Node_displacement.out',dtype='float', skiprows=0)

#SeismoVLab SOLUTION:
disp  = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=52)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 25})
plt.figure(figsize=(42.5,10))

y  = np.arange(0.0, 10.2, 0.2)

plt.subplot(1, 5, 1)
plt.plot(disp[250,::3], y, 'r-', solution[250,1::2], y, 'b.')
plt.xlabel("$x(t=0.75)$", fontsize=30)
plt.ylabel("$y(t=0.75)$", fontsize=30)
plt.xlim((-0.5,0.5))
plt.ylim((0,10))
plt.grid(True)

plt.subplot(1, 5, 2)
plt.plot(disp[500,::3], y, 'r-', solution[500,1::2], y, 'b.')
plt.xlabel("$x(t=1.50)$", fontsize=30)
plt.ylabel("$y(t=1.50)$", fontsize=30)
plt.xlim((-0.5,0.5))
plt.ylim((0,10))
plt.grid(True)

plt.subplot(1, 5, 3)
plt.plot(disp[750,::3], y, 'r-', solution[750,1::2], y, 'b.')
plt.xlabel("$x(t=2.25)$", fontsize=30)
plt.ylabel("$y(t=2.25)$", fontsize=30)
plt.xlim((-0.5,0.5))
plt.ylim((0,10))
plt.grid(True)

plt.subplot(1, 5, 4)
plt.plot(disp[1000,::3], y, 'r-', solution[1000,1::2], y, 'b.')
plt.xlabel("$x(t=3.00)$", fontsize=30)
plt.ylabel("$y(t=3.00)$", fontsize=30)
plt.xlim((-0.5,0.5))
plt.ylim((0,10))
plt.grid(True)

plt.subplot(1, 5, 5)
plt.plot(disp[1250,::3], y, 'r-', solution[1250,1::2], y, 'b.')
plt.xlabel("$x(t=3.75)$", fontsize=30)
plt.ylabel("$y(t=3.75)$", fontsize=30)
plt.xlim((-0.5,0.5))
plt.ylim((0,10))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-model_SupportMotion_Dynamic} is defined to test dynamic \\texttt{SupportMotion}. The problem is a beam 
defined to test \\texttt{lin2DFrame2} element with material type \\texttt{Elastic1DLinear}. The material has a elasticity modulus $E = 10$, and a Poisson's ratio $\\nu = 0.25$. Nodes (1) and node (51) have 
coordinate $(0.0, 0.0)$ and $(10.0, 0.0)$ respectively. Node (1) and (51) are pinned i.e, displacement are fixed. The Bernoulli beam has a rectangular cross section with $h = b = 0.60 \; m$. Responses are verified against OpenSEES solution. Figure~\\ref{fig:Verification_SupportMotion_Dynamics} shows the deformed configuration at different time steps. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.55 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{SuportMotion} constraints.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_SupportMotion_Dynamic}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.925\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Deformed configuration at different time steps: Analytical ({\color{blue}{$\dots$}}), SeismoVLab (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_SupportMotion_Dynamics}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.close()
