#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#Get file path
pwdpath = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwdpath + "/LaTeX/ModelTest.png" 
ResultFigure = pwdpath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
Po     = 1.000
d      = 0.050
c      = 0.200
k      = 4.000
m      = 1.000
wn     = np.sqrt(k/m)
wd     = wn*np.sqrt(1.0 - d**2)

dt     = 0.10
this   = pwdpath + '/Solution/NodalMass/'
time   = np.arange(dt, 25.1, dt)

#ANALYTICAL SOLUTION:
x0     = m*wn**2*1.00/k
ground = np.loadtxt('SupportMotion.txt', dtype='float', skiprows=2)
disp1  = x0/(2*d)*(np.exp(-d*wn*time)*(np.cos(wd*time) + d/np.sqrt(1.0 - d**2)*np.sin(wd*time)) - np.cos(wn*time))

#SeismoVLAB SOLUTION:
displacement = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=3)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 2, 1)
plt.plot(time, displacement[:,2], 'r-', time+0.5*dt, disp1, 'b.')
plt.xlabel("$t \;[s]$", fontsize=30)
plt.ylabel("$U(t)$" , fontsize=30)
plt.xlim((0,25))
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(time, displacement[:,0], 'r-', time, ground, 'b.')
plt.xlabel("$t \;[s]$", fontsize=30)
plt.ylabel("$U_g(t)$" , fontsize=30)
plt.xlim((0,25))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_MassSpringDashpot_supportMotion} and 
correspond to a mass-spring-dashpot oscillator for which $M = 1 \;[kg]$, $K = 4 \;[N/m]$, $C = 0.2 \;[N\,s/m]$. 
This problem tests \\texttt{Point Mass} and \\texttt{ZeroLength1D}. The nodes $(1)$, and $(2)$ have the coordinate 
$(x,y) = (0.0, 0.0)$. Node $(1)$ is fixed in \\textrm{X}- and \\textrm{Y}-directions, while node (2) is fixed in 
\\textrm{Y}-direction. For dynamic analysis, a support motion is applied at node (1) is defined as 
$u_g(t) = 1.000 \, \sin(\omega_n \,t) \; m$, with $\omega_n = 2 \;[rad/s]$. The responses are verified against analytical 
solution. Figure~\\ref{fig:Verification_MassSpringDashpot_supportMotion} shows the displacement and reactive force responses at node (2). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.2250 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{ZeroLength1D} with \\texttt{Viscous1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_MassSpringDashpot_supportMotion}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.925\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_MassSpringDashpot_supportMotion}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.close()
