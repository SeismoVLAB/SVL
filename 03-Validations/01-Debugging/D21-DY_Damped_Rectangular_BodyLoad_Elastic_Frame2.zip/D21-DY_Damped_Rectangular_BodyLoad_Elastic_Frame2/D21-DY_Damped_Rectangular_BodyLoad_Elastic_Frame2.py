"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file']      = 'Debugging_D21'
SVL.Options['format']    = 'svl'
SVL.Options['massform']  = 'lumped'
SVL.Options['nparts']    = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Damping
SVL.addDamping(tag=1, name='Rayleigh', attributes={'am': 0.0000, 'ak': 0.0078483, 'list': 'ALL'})

#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 20000.0, 'nu': 0.30, 'rho': 0.10})

#CReate Section
SVL.addSection(tag=1, name='Lin2DRectangular', model='Plain', attributes={'material': 1, 'h': 1.0, 'b': 1.0, 'theta': 0.0, 'ip': 10})

#Create Nodes
nNodes = 17
for k in range(nNodes):
    SVL.addNode(tag=(k+1), ndof=3, coords=[10.0*float(k)/(nNodes-1), 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=17, dof=[1, 2])

#Create Element
for k in range(nNodes-1):
    SVL.addElement(tag=(k+1), conn=[k+1, k+2], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 5})
#SVL.printAll('Elements')

#Create function
fun = {'file': 'BodyLoad.txt', 'dir': [0.0, -1.0]}
SVL.addFunction(tag=1, name='TimeSerie', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Body', 'list': 'ALL'}
SVL.addLoad(tag=1, name='ElementLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='CantileverBeam', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': 9}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Reaction.out', 'ndps': 8, 'resp': 'Reaction', 'list': 1}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': 1}
SVL.addRecorder(tag=3, attributes=rec)

rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8}
SVL.addRecorder(tag=4, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 230})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.02})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('partition')
#SVL.printAll('Nodes')
