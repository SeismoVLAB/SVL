#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

pwd = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwd + "/LaTeX/ModelTest.png" 
ResultFigure = pwd + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this    = pwd + '/Solution/CantileverBeam/'
matlab  = pwd + '/MatLab/Results.txt'
time    = np.arange(0.02, 4.61, 0.02)

#ANALYTICAL SOLUTION:
analytical = np.loadtxt(matlab, dtype='float', skiprows=0)

#SeismoVLAB SOLUTION:
reaction     = np.loadtxt(this + 'Reaction.0.out', dtype='float', skiprows=2)
displacement = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 2, 1)
plt.plot(time, displacement[:,1], 'r-', analytical[:,0]+0.01, analytical[:,1], 'b.')
plt.xlabel("$t \;[s]$", fontsize=30)
plt.ylabel("$v(t)$" , fontsize=30)
plt.xlim((0,4.0))
plt.ylim((-0.016, 0.0))
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(time, reaction[:,1], 'r-', analytical[:,0]+0.01, analytical[:,2], 'b.')
plt.xlabel("$t\;[s]$"  , fontsize=30)
plt.ylabel("$V(t)$", fontsize=30)
plt.xlim((0,4.0))
plt.ylim((0,1.0))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:D20-DY_Free_Rectangular_BodyLoad_Elastic_Frame2} and is 
defined to test \\texttt{lin3Drame2} element with material type \\texttt{Elastic1DLinear}. For this example, 
all beam members have a rectangular cross-section with height $h = 1$ and width $b=1$, and modulus of elasticity, 
$E = 20000$. The beam is $10$ units long and is discretized with 16 equal length beam elements and 17 nodes. A  
dynamic body load is added for all elements with constant magnitude $0.1$. Rayleigh damping is added such that $a_0 = 0.0$ 
and $a_1 = 0.0078$. The responses are verified against analytical solution. 
Figure~\\ref{fig:Verification_D20-DY_Free_Rectangular_BodyLoad_Elastic_Frame2} shows the 
displacement in vertical direction at node (9) as well as the shear force reaction at node (1). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.2750 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3Drame2} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:D20-DY_Free_Rectangular_BodyLoad_Elastic_Frame2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.900\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Displacement Nodal responses at node (5) and Shear reaction force at node (1): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_D20-DY_Free_Rectangular_BodyLoad_Elastic_Frame2}\n")
LaTeXfile.write("\end{figure}\n")
#LaTeXfile.write("\n")
#LaTeXfile.write("The root mean square error for the displacements and reaction are : (\\texttt{%#1.6g}, \\texttt{%#1.6g}), while the maximum relative error for the displacement and reaction are : (\\texttt{%#1.6g},\\texttt{%#1.6g}) respectively." % (rms1,rms2,mad1,mad2))
LaTeXfile.close()
