#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#FIGURE OUTPUT NAMES:
ModelFigure  = os.getcwd() + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
L      = 1.0
h      = 0.2
E      = 100000.0
I      = 1.0/12.0*h**4
q      = 10.0 # since equivalent is 50.0 x 0.2 (beam)

this     = 'Solution/ShellWall/'

#ANALYTICAL SOLUTION:
eps      = 1E-15
delta    = q*L**4/8.0/E/I
reaction = np.array([0.0, -q*L, q*L**2/2.0])

#SeismoVLAB SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out' , dtype='float', skiprows=3)
nodal = np.reshape(nodal, (2,6))

force = np.loadtxt(this + 'Reaction.0.out', dtype='float', skiprows=3)

nodeForce  = force[1] + force[7]
nodeMoment = force[3] + force[9]
force      = np.array([nodeForce, nodeMoment])

#COMPUTES ERRORS:
error0 = abs((nodal[0,1] - delta)/delta);
error1 = max(abs(np.divide(force - reaction[[1,2]], reaction[[1,2]])));

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-Shell4_Wall_SurfaceLoad} is a vertical shell (wall) elements defined to 
test \\texttt{lin3DShell4} elements with material type \\texttt{Elastic2DPlaneStress}. The slab elements have material with elasticity 
moduli $E = 100000.0 \;Pa$, and a Poisson's ratio $\\nu = 0.30$. Nodes (1), (2), (11), and (12) have coordinate $(0.0, 0.0, 0.0)$, 
$(0.2, 0.0, 0.0)$, and $(0.2, 0.0, 1.0)$, and $(0.0, 0.0, 1.0)$ respectively. Nodes (1) and (2) at the boundaries are clamped, i.e., displacements and 
rotation along/about \\textrm{X}, \\textrm{Y} and \\textrm{Z} are restrained. The shell has a thickness of $t_h = 0.2\;m$. A horizontal out-plane 
surface load is added with magnitude $q = 50 \; N/m^2$ and direction $\hat{n} = (0,1,0)$. Responses are verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.150 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3DShell4} with \\texttt{Elastic2DPlaneStress} material and Surface Load.}\n")
LaTeXfile.write("\t\label{fig:Verification-Shell4_Wall_SurfaceLoad}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the horizontal deformation at node (11) and (12) is : \\texttt{%#1.6g}. The maximum relative error for the reaction forces at node (1) is : \\texttt{%#1.6g}." % (error0, error1))
LaTeXfile.close()
