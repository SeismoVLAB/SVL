"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_A05'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
mat = {'k1': 1.2497e+07, 'k2': 4.5668e+12, 'k3': -1.1125e+18, 'rho': 0.0}
SVL.addMaterial(tag=1, name='Hertzian1DLinear', attributes=mat)

mat = {'eta': 20.9144}
SVL.addMaterial(tag=2, name='Viscous1DLinear', attributes=mat)

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.0, 0.0])
SVL.addNode(tag=2, ndof=2, coords=[0.0, 0.0])

#Create Mass
SVL.addMass(tag=2, dof=[1,2], vals=[0.0035, 0.0035])

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=2, dof=2)

#Create Element
elem = {'material': 1, 'dir': 1}
SVL.addElement(tag=1, conn=[1, 2], name='ZeroLength1D', attributes=elem)

elem = {'material': 2, 'dir': 1}
SVL.addElement(tag=2, conn=[1, 2], name='ZeroLength1D', attributes=elem)

#Create function
fun = {'file': 'MagnetForce.txt', 'dir': [1.0, 0.0]}
SVL.addFunction(tag=1, name='TimeSerie', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'TimeSerie', 'list': [2]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': 1, 'factor': 1.0}
SVL.addCombinationCase(tag=1, name='HertzianOscillator', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': 2}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Acceleration.out', 'ndps': 8, 'resp': 'accel', 'list': 2}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'ForceSpring.out', 'ndps': 8, 'resp': 'Stress', 'list': 1}
SVL.addRecorder(tag=3, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'ForceDashpot.out', 'ndps': 8, 'resp': 'Stress', 'list': 2}
SVL.addRecorder(tag=4, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 20001})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Newton', 'nstep': 50})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 1E-7})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('partition')
#SVL.printAll('Nodes')
