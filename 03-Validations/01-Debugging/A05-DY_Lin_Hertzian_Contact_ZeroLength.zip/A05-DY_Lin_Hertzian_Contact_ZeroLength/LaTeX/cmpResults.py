#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#Get file path
pwdpath = os.getcwd()

#FIGURE OUTPUT NAMES:
ModelFigure  = pwdpath + "/LaTeX/ModelTest.png" 
ResultFigure = pwdpath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
m     = 0.0035
dt    = 1.0E-7
time  = np.arange(dt, 0.002, dt)
this  = pwdpath + '/Solution/HertzianOscillator/'

#ANALYTICAL SOLUTION:
force  = np.loadtxt('MagnetForce.txt', dtype='float', skiprows=2)
disp1  = np.loadtxt('./Numerical/solution.txt', dtype='float', skiprows=0)

#SeismoVLab SOLUTION:
disp2        = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)
acceleration = np.loadtxt(this + 'Acceleration.0.out', dtype='float', skiprows=2)
ForceSpring  = np.loadtxt(this + 'ForceSpring.0.out', dtype='float', skiprows=2)
ForceDashpot = np.loadtxt(this + 'ForceDashpot.0.out', dtype='float', skiprows=2)

Reaction = m*acceleration[:,0] + ForceSpring + ForceDashpot

#COMPUTES ERRORS:
delta1 = abs(disp1[:,1] - disp2[:,0])
delta2 = abs(force - Reaction)

#Root mean square error.
rms1 = np.sqrt(np.mean(delta1**2))
rms2 = np.sqrt(np.mean(delta2**2))

#Maximum absolute difference.
mad1 = max(delta1)
mad2 = max(delta2)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 2, 1)
plt.plot(time, disp2[:,0], 'r-', disp1[::20,0], disp1[::20,1], 'b.')
plt.xlabel("$t \;[s]$", fontsize=30)
plt.ylabel("$U_x(t)$" , fontsize=30)
plt.xlim((0,0.002))
plt.ylim((-6E-7,6E-7))
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(time, Reaction, 'r-', time[::20], force[::20], 'b.')
plt.xlabel("$t\;[s]$"  , fontsize=30)
plt.ylabel("$R_{x}(t)$", fontsize=30)
plt.xlim((0,0.002))
plt.ylim((-1,1))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_HertzianOscillator} and 
correspond to a Hertzian contact oscillator for which $M = 0.0035 \;[kg]$, $k_1 = 4 \;[N/m]$, $k_2 = 4 \;[N/m]$,
$k_3 = 4 \;[N/m]$, and $C = 0.2 \;[N\,s/m]$. This problem tests \\texttt{Hertzian1DLinear} and \\texttt{ZeroLength1D}. 
The nodes $(1)$, and $(2)$ have the coordinate $(x,y) = (0.0, 0.0)$. Node $(1)$ is fixed in \\textrm{X}- and 
\\textrm{Y}-directions, while node (2) is fixed in \\textrm{Y}-direction. For dynamic analysis, the nodal force applied at 
node (2) is defined as $P(t) = 1.000 \, \cos(\omega \,t) \; N$, with $\omega = 6.2832 \\cdot 10^{4} \;[rad/s]$. The responses 
are verified against analytical solution. Figure~\\ref{fig:Verification_HertzianOscillator} shows the displacement and 
reactive force responses at node (2). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.2350 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{ZeroLength1D} with \\texttt{Hertzian1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_HertzianOscillator}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.925\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): Analytical ({\color{blue}{$\dots$}}), SeismoVLab (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_HertzianOscillator}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The root mean square error for the displacements and reaction are : (\\texttt{%#1.6g}, \\texttt{%#1.6g}), while the maximum relative error for the displacement and reaction are : (\\texttt{%#1.6g},\\texttt{%#1.6g}) respectively." % (rms1,rms2,mad1,mad2))
LaTeXfile.close()
