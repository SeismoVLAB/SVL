#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
eps    = 1E-15
this   = filepath + '/Solution/CantileverBeam/'

#ANALYTICAL SOLUTION:
P  = 1000
E  = 68.9E9
h  = 0.20
b  = 0.05
L  = 1.00
nu = 0.33
A  = b*h
I  = b*h**3/12.0

delta    = P*L**3/3.0/E/I + P*L*(12.0 + 11.0*nu)/5.0/A/E
reaction = np.array([0.0, -1000.0, -1000.0])

#SeismoVLab SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=2)
force = np.loadtxt(this + 'InternalForce.0.out',dtype='float', skiprows=2)

#COMPUTES ERRORS:
error1 = abs((nodal[1] - delta)/delta)
error2 = max(np.divide(force[0:3] - reaction, reaction + eps))

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:CantileverBeam_Tim_Elastic1DLinear} is 
defined to test \\texttt{lin2DFrame2} element with material type \\texttt{Elastic1DLinear}. The 
material has a elasticity moduli $E = 68.9 \;GPa$, and a Poisson's ratio $\\nu = 0.33$. Nodes (1) 
and node (2) have coordinate $(0.0, 0.0)$ and $(1.0, 0.0)$ respectively. Node (1) is fixed 
in \\textrm{X} and \\textrm{Y} directions, while node (2) is free. The Timoshenko beam has a 
rectangular cross section with $h = 0.20 \; m$ and $b = 0.05 \; m$. A vertical load is placed at 
node (2) with magnitude $P = 1000 \; N$. Responses are verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.325 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DFrame2} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:CantileverBeam_Tim_Elastic1DLinear}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the vertical deformation is : \\texttt{%#1.6g}, while the maximum relative error for the reaction forces are : \\texttt{%#1.6g}." % (error1, error2))
LaTeXfile.close()
