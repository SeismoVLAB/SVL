#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 
ResultFigure = filepath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this   = filepath + '/Solution/NonLinearTrussBeam/'

#ANALYTICAL SOLUTION:
solution  = np.loadtxt('Numerical/pvsu.txt', dtype='float', skiprows=0)

#SeismoVLAB SOLUTION:
displacement = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)
displacement = np.append(0.0,displacement[:,1])
Load = 20.0*np.arange(0.0, 1.01, 0.01)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(10.5,9.0))
plt.plot(-displacement, Load, 'r-', solution[:,0], solution[:,1], 'b.')
plt.xlabel("$w\, [cm]$", fontsize=30)
plt.ylabel("$P\, [N]$", fontsize=30)
plt.xlim((0,8.0))
plt.ylim((0,20.0))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_Corrotational2D_Truss_Beam} and is 
defined to test \\texttt{kin2DTruss2} element with material type \\texttt{Elastic1DLinear}. For this example, all 
truss members have a cross-sectional area, $A = 0.1 \,[in^2]$, and modulus of elasticity, $E = 29000 \,[ksi]$. The 
truss is 10 inches long, and horizontal and vertical members are 0.5 inch long. As a result of the above dimensions 
there are 42 nodes and 81 members. A vertical load of $20\,[kips]$ is placed at Node (42) The tolerance used for 
equilibrium iterations is $10^{-6}$. The responses are verified against numerical solution provied by Louie L. Yaw. 
Figure~\\ref{fig:Verification_Corrotational2D_Truss_Beam} shows the force displacement curve at node (42). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.45 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{kin2DTruss2} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_Corrotational2D_Truss_Beam}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.35\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_Corrotational2D_Truss_Beam}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.close()
