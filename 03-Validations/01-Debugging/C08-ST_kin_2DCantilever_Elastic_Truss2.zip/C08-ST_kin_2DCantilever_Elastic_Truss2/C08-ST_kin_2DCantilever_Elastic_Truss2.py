"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_C08'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 29000, 'nu': 0.25, 'rho': 0.0})

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0,0])
SVL.addNode(tag=2, ndof=2, coords=[0,0.5])
SVL.addNode(tag=3, ndof=2, coords=[0.5,0])
SVL.addNode(tag=4, ndof=2, coords=[0.5,0.5])
SVL.addNode(tag=5, ndof=2, coords=[1,0])
SVL.addNode(tag=6, ndof=2, coords=[1,0.5])
SVL.addNode(tag=7, ndof=2, coords=[1.5,0])
SVL.addNode(tag=8, ndof=2, coords=[1.5,0.5])
SVL.addNode(tag=9, ndof=2, coords=[2,0])
SVL.addNode(tag=10, ndof=2, coords=[2,0.5])
SVL.addNode(tag=11, ndof=2, coords=[2.5,0])
SVL.addNode(tag=12, ndof=2, coords=[2.5,0.5])
SVL.addNode(tag=13, ndof=2, coords=[3,0])
SVL.addNode(tag=14, ndof=2, coords=[3,0.5])
SVL.addNode(tag=15, ndof=2, coords=[3.5,0])
SVL.addNode(tag=16, ndof=2, coords=[3.5,0.5])
SVL.addNode(tag=17, ndof=2, coords=[4,0])
SVL.addNode(tag=18, ndof=2, coords=[4,0.5])
SVL.addNode(tag=19, ndof=2, coords=[4.5,0])
SVL.addNode(tag=20, ndof=2, coords=[4.5,0.5])
SVL.addNode(tag=21, ndof=2, coords=[5,0])
SVL.addNode(tag=22, ndof=2, coords=[5,0.5])
SVL.addNode(tag=23, ndof=2, coords=[5.5,0])
SVL.addNode(tag=24, ndof=2, coords=[5.5,0.5])
SVL.addNode(tag=25, ndof=2, coords=[6,0])
SVL.addNode(tag=26, ndof=2, coords=[6,0.5])
SVL.addNode(tag=27, ndof=2, coords=[6.5,0])
SVL.addNode(tag=28, ndof=2, coords=[6.5,0.5])
SVL.addNode(tag=29, ndof=2, coords=[7,0])
SVL.addNode(tag=30, ndof=2, coords=[7,0.5])
SVL.addNode(tag=31, ndof=2, coords=[7.5,0])
SVL.addNode(tag=32, ndof=2, coords=[7.5,0.5])
SVL.addNode(tag=33, ndof=2, coords=[8,0])
SVL.addNode(tag=34, ndof=2, coords=[8,0.5])
SVL.addNode(tag=35, ndof=2, coords=[8.5,0])
SVL.addNode(tag=36, ndof=2, coords=[8.5,0.5])
SVL.addNode(tag=37, ndof=2, coords=[9,0])
SVL.addNode(tag=38, ndof=2, coords=[9,0.5])
SVL.addNode(tag=39, ndof=2, coords=[9.5,0])
SVL.addNode(tag=40, ndof=2, coords=[9.5,0.5])
SVL.addNode(tag=41, ndof=2, coords=[10,0])
SVL.addNode(tag=42, ndof=2, coords=[10,0.5])

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1,2])
SVL.addRestrain(tag=2, dof=[1,2])

#Create Element
SVL.addElement(tag=1, conn=[1,2], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=2, conn=[1,3], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=3, conn=[1,4], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=4, conn=[2,4], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=5, conn=[3,4], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=6, conn=[3,5], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=7, conn=[3,6], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=8, conn=[4,6], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=9, conn=[5,6], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=10, conn=[5,7], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=11, conn=[5,8], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=12, conn=[6,8], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=13, conn=[7,8], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=14, conn=[7,9], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=15, conn=[7,10], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=16, conn=[8,10], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=17, conn=[9,10], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=18, conn=[9,11], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=19, conn=[9,12], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=20, conn=[10,12], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=21, conn=[11,12], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=22, conn=[11,13], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=23, conn=[11,14], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=24, conn=[12,14], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=25, conn=[13,14], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=26, conn=[13,15], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=27, conn=[13,16], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=28, conn=[14,16], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=29, conn=[15,16], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=30, conn=[15,17], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=31, conn=[15,18], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=32, conn=[16,18], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=33, conn=[17,18], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=34, conn=[17,19], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=35, conn=[17,20], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=36, conn=[18,20], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=37, conn=[19,20], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=38, conn=[19,21], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=39, conn=[19,22], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=40, conn=[20,22], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=41, conn=[21,22], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=42, conn=[21,23], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=43, conn=[21,24], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=44, conn=[22,24], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=45, conn=[23,24], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=46, conn=[23,25], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=47, conn=[23,26], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=48, conn=[24,26], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=49, conn=[25,26], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=50, conn=[25,27], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=51, conn=[25,28], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=52, conn=[26,28], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=53, conn=[27,28], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=54, conn=[27,29], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=55, conn=[27,30], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=56, conn=[28,30], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=57, conn=[29,30], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=58, conn=[29,31], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=59, conn=[29,32], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=60, conn=[30,32], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=61, conn=[31,32], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=62, conn=[31,33], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=63, conn=[31,34], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=64, conn=[32,34], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=65, conn=[33,34], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=66, conn=[33,35], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=67, conn=[33,36], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=68, conn=[34,36], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=69, conn=[35,36], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=70, conn=[35,37], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=71, conn=[35,38], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=72, conn=[36,38], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=73, conn=[37,38], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=74, conn=[37,39], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=75, conn=[37,40], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=76, conn=[38,40], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=77, conn=[39,40], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=78, conn=[39,41], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=79, conn=[39,42], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=80, conn=[40,42], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})
SVL.addElement(tag=81, conn=[41,42], name='kin2DTruss2', attributes={'material': 1, 'area': 0.10})

#Create function
fun = {'mag': 20.0, 'dir': [0.0, -1.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': [42]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='NonLinearTrussBeam', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [42]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8, 'nsamp': 1}
SVL.addRecorder(tag=2, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 100})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Newton', 'nstep': 50, 'cnvgtol': 1.0E-06, 'cnvgtest': 'RelativeIncrementalDisplacement'})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()
