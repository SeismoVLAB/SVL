#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
L      = 1.0
h      = 0.2
E      = 100000.0
I      = 1.0/12.0*h**4
q      = 10.0

this   = filepath + '/Solution/HexaElasticStatic/'

#ANALYTICAL SOLUTION:
delta    = -q*L**4/8.0/E/I
reaction = np.array([0.0, q*L, -q*L**2/2.0])

#SeismoVLab SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out' , dtype='float', skiprows=5)
force = np.loadtxt(this + 'Reaction.0.out', dtype='float', skiprows=9)

nodeForce  = force[2] + force[5] + force[8] + force[11] + force[14] + force[17] + force[20] + force[23]
nodeMoment = h/2.0*(force[6]+force[9]+force[15]-force[0]-force[3]-force[12])
force      = np.array([nodeForce, nodeMoment])

#COMPUTES ERRORS:
error0 = abs((nodal[11] - delta)/delta);
error1 = max(abs(np.divide(force - reaction[[1,2]], reaction[[1,2]])));

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-Cantilever_Hexa20_3DSurfaceLoad} is a cantilever beam 
defined to test \\texttt{lin3DHexa20} elements with material type \\texttt{Elastic3DLinear} and a surface load. The 
material has a elasticity modulus $E = 100000 \;Pa$, and a Poisson's ratio $\\nu = 0.30$. Nodes (1) and node (6) have 
coordinate $(0.0, 0.0)$ and $(1.0, 0.0)$ respectively. Node (1), (7), (13), (19), (30), (46), (57), and (63) are fixed i.e, 
displacement in horizontal and vertical directions are fixed, while the others are free. The the element thickness is $t = 0.20 \; m$, 
and the element height is $h = 0.20 \; m$. The beam is subjected to a surface load $q = 50\;[N/m^2]$ at Node (18) and (24). Responses 
are verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.375 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3DHexa20} and Surface Load in 3D.}\n")
LaTeXfile.write("\t\label{fig:Verification-Cantilever_Hexa20_3DSurfaceLoad}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the vertical deformation at node (24) is : \\texttt{%#1.6g}. The maximum relative error for the reaction forces is : \\texttt{%#1.6g}." % (error0, error1))
LaTeXfile.close()
