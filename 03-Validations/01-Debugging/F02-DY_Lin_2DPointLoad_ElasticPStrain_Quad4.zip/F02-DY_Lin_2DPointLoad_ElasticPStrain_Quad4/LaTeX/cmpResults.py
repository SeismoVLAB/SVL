#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 
ResultFigure = filepath + "/LaTeX/ResultTest.png"
StressFigure = filepath + "/LaTeX/StressTest.png"

#INPUT VARIABLES:
dt       = 0.025
eps      = 1E-15
this     = filepath + '/Solution/QuadPlaneStrainElasticDynamic/'
openSeeS = filepath + '/OpenSees/'

#OPENSEES SOLUTION:
dis1    = np.loadtxt(openSeeS + 'displacement.out', dtype='float', skiprows=0) 
vel1    = np.loadtxt(openSeeS + 'velocity.out'    , dtype='float', skiprows=0) 
acc1    = np.loadtxt(openSeeS + 'acceleration.out', dtype='float', skiprows=0) 
stress1 = np.loadtxt(openSeeS + 'stress.out', dtype='float', skiprows=0)

#SeismoVLAB SOLUTION:
time    = np.arange(0.0, 5.0, dt) + dt
dis2    = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)
vel2    = np.loadtxt(this + 'Velocity.0.out'    , dtype='float', skiprows=2)
acc2    = np.loadtxt(this + 'Acceleration.0.out', dtype='float', skiprows=2)
stress2 = np.loadtxt(this + 'Stress.0.out', dtype='float', skiprows=2)

#COMPUTES ERRORS:
error1x = np.sqrt(np.mean((dis1[:,1] - dis2[:,0])**2))
error1y = np.sqrt(np.mean((dis1[:,2] - dis2[:,1])**2))
error2x = np.sqrt(np.mean((vel1[:,1] - vel2[:,0])**2))
error2y = np.sqrt(np.mean((vel1[:,2] - vel2[:,1])**2))
error3x = np.sqrt(np.mean((acc1[:,1] - acc2[:,0])**2))
error3y = np.sqrt(np.mean((acc1[:,2] - acc2[:,1])**2))

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 2, 1)
plt.plot(time, dis2[:,0], 'r-', dis1[:,0], dis1[:,1], 'b.')
plt.xlabel("$t$"               , fontsize=30)
plt.ylabel("$u_x (t)$", fontsize=30)
plt.xlim((0,5))
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(time, dis2[:,1], 'r-', dis1[:,0], dis1[:,2], 'b.')
plt.xlabel("$t$"             , fontsize=30)
plt.ylabel("$u_y (t)$", fontsize=30)
plt.xlim((0,5))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 3, 1)
plt.plot(time, stress2[:,9]/1E6, 'r-', stress1[:,0], stress1[:,7]/1E6, 'b.')
plt.xlabel("$t$"               , fontsize=30)
plt.ylabel("$\sigma_{xx}(t) \; MPa$", fontsize=30)
plt.xlim((0,5))
plt.grid(True)

plt.subplot(1, 3, 2)
plt.plot(time, stress2[:,10]/1E6, 'r-', stress1[:,0], stress1[:,8]/1E6, 'b.')
plt.xlabel("$t$"             , fontsize=30)
plt.ylabel("$\sigma_{yy} (t) \; MPa$", fontsize=30)
plt.xlim((0,5))
plt.grid(True)

plt.subplot(1, 3, 3)
plt.plot(time, stress2[:,11]/1E6, 'r-', stress1[:,0], stress1[:,9]/1E6, 'b.')
plt.xlabel("$t$"             , fontsize=30)
plt.ylabel("$\\tau_{xy} (t) \; MPa$" , fontsize=30)
plt.xlim((0,5))
plt.grid(True)

plt.savefig("LaTeX/StressTest.png")
plt.close()


#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-QuadPlaneStrainElasticStatic} and is defined 
to test \\texttt{lin2DQuad4} element with material type provided in \\texttt{Elastic2DPlaneStrain}. The material has 
$E = 208 \; MPa$, $\\nu = 0.3$, and $\\rho = 2000 \; kg/m^3$. Node (1) has coordinates $(0.0,0.0)$ and is fixed in \\textrm{X} and 
\\textrm{Y} directions. Node (2) has coordinates $(2.0,0.0)$ and is fixed in \\textrm{Y} direction. Two nodal forces are prescribed at 
node (4) with $P_1 = 0.01 \cdot f(t)$ and $P_2=0.02 \cdot f(t)$ with $f(t) = 107.5 \cdot t \, \sin(2 \pi\,t)$. The responses are verified 
against OpenSees. Figure~\\ref{fig:Verification-QuadPlaneStrainElasticDynamic-displacement} shows nodal displacements in \\textrm{X}, \\textrm{Y} 
directions at node (4). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
#LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.215 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DQuad4} with \\texttt{Elastic2DPlaneStrain} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_Plastic1DJ2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.925\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (4): OpenSEES ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification-QuadPlaneStrainElasticDynamic-displacement}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=\\textwidth]{"+StressFigure+"}\n")
LaTeXfile.write("\t\caption{Material responses at integration point 4: OpenSEES ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification-QuadPlaneStrainElasticDynamic-displacement-IP}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The root mean square error for displacements at node (4) is : (\\texttt{%#1.6g}, \\texttt{%#1.6g}), while the maximum relative error for the velocity and acceleration are : (\\texttt{%#1.6g},\\texttt{%#1.6g}), and (\\texttt{%#1.6g},\\texttt{%#1.6g}) respectively." % (error1x,error1y, error2x, error2y, error3x, error3y))
LaTeXfile.close()
