#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
eps      = 1E-15
this     = filepath + '/Solution/QuadPlaneStrainElasticStatic/'
openSeeS = filepath + '/OpenSees/'

#OPENSEES SOLUTION:
dis1    = np.loadtxt(openSeeS + 'displacement.out', dtype='float', skiprows=0) 
strain1 = np.loadtxt(openSeeS + 'strain.out', dtype='float', skiprows=0)
stress1 = np.loadtxt(openSeeS + 'stress.out', dtype='float', skiprows=0)

strain1 = strain1[[0,1,2,3,4,5,9,10,11,6,7,8]]
stress1 = stress1[[0,1,2,3,4,5,9,10,11,6,7,8]]

#SeismoVLab SOLUTION:
dis2    = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=4)
strain2 = np.loadtxt(this + 'Strain.0.out', dtype='float', skiprows=2)
stress2 = np.loadtxt(this + 'Stress.0.out', dtype='float', skiprows=2)

#COMPUTES ERRORS:
error1 = abs(max(np.divide(dis1 - dis2, dis1 + eps))) #np.sqrt(np.mean((dis1 - dis2)**2))
error2 = abs(max(np.divide(strain1 - strain2, strain1 + eps))) #np.sqrt(np.mean((strain1 - strain2)**2))
error3 = abs(max(np.divide(stress1 - stress2, stress1 + eps))) #np.sqrt(np.mean((stress1 - stress2)**2))

#GENERATE THE LATEX FILE:
Description = """The Problem is shown in Figure~\\ref{fig:Verification-QuadPlaneStrainElasticStatic} and is defined 
to test \\texttt{lin2DQuad4} element with material type provided in \\texttt{Elastic2DPlaneStrain}. The material has 
$E = 208 \; MPa$, $\\nu = 0.3$, and $\\rho = 2000 \; kg/m^3$. Node (1) has coordinates $(0.0,0.0)$ and is fixed in 
\\textrm{X} and \\textrm{Y} directions. Node (2) has coordinates $(2.0,0.0)$ and is fixed in \\textrm{Y} direction. 
Two nodal forces are placed at node (4) with $P_1=1 \;MN$ and $P_2=2 \; MN$. The responses are verified against OpenSees. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.200 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Verification for \\texttt{lin2DQuad4} with \\texttt{Elastic2DPlaneStrain} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-QuadPlaneStrainElasticStatic}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The maximum absolute relative error for the displacements is : \\texttt{%#1.6g}, while the maximum relative error for the strains and stresses are : \\texttt{%#1.6g}, \\texttt{%#1.6g} respectively." % (error1, error2, error3))
LaTeXfile.close()
