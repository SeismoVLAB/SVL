"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_J12'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic3DLinear', attributes={'E': 5.0E+07, 'nu': 0.25, 'rho': 2000.0})
SVL.addMaterial(tag=2, name='Elastic3DLinear', attributes={'E': 5.0E+07, 'nu': 0.25, 'rho': 2000.0})

#Create the PML domain
opts1 = {
    'ne': [1, 1, 10], 
    'class': 'PML3DHexa8', 
    'ndof' : 9, 
    'P0': [0, 0, 0], 
    'P1': [1.0, 0, 0], 
    'P2': [0, 1.0, 0], 
    'P3': [0, 0, 10.0],
    'elems': 'HEXA8',
    'attributes': {'material': 2, 'n': 2.0, 'L': 10.0, 'R': 1E-5, 'x0': [0.5, 0.5, 10.0], 'npml': [0.0, 0.0, -1.0], 'rule': 'Gauss', 'np': 8}
    }
mesh1 = SVL.makeDomainVolume(options=opts1)
#SVL.printFormatted(mesh1['Nodes'])

#Create the Hexahedron domain
opts2 = {
    'ne': [1, 1, 90], 
    'class': 'Lin3DHexa8', 
    'ndof' : 3, 
    'P0': [  0,   0, 10.0], 
    'P1': [1.0,   0, 10.0], 
    'P2': [  0, 1.0, 10.0], 
    'P3': [  0,   0, 100.0],
    'elems': 'HEXA8',
    'attributes': {'material': 1, 'rule': 'Gauss', 'np': 8}
    }
mesh2 = SVL.makeDomainVolume(options=opts2)
#SVL.printFormatted(mesh2['Nodes'])

#Merge both domain togeteher
mesh1 = SVL.mergeDomain(mesh1, mesh2)

#Assign the merge mesh to Entities
SVL.Entities['Nodes'] = mesh1['Nodes']
SVL.Entities['Elements'] = mesh1['Elements']

#Restrain degree of freedom
for nTag in SVL.Entities['Nodes']:
    if nTag <= 4:
        SVL.addRestrain(tag=nTag, dof=[1,2,3])
    else:
        SVL.addRestrain(tag=nTag, dof=[1,2])

#Constraint degree of freedom
SVL.addConstraint(tag=-2, name='Equal', attributes={'stag':41, 'sdof': 3, 'mtag':45, 'mdof': 3})
SVL.addConstraint(tag=-3, name='Equal', attributes={'stag':42, 'sdof': 3, 'mtag':46, 'mdof': 3})
SVL.addConstraint(tag=-4, name='Equal', attributes={'stag':43, 'sdof': 3, 'mtag':47, 'mdof': 3})
SVL.addConstraint(tag=-5, name='Equal', attributes={'stag':44, 'sdof': 3, 'mtag':48, 'mdof': 3})

#Create function
fun = {'file': 'ricker-SoilColumnElasticPlaneStrainPML.txt', 'dir': [0.0, 0.0, 0.5E+05]}
SVL.addFunction(tag=1, name='TimeSerie', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'TimeSerie', 'list': [405, 406, 407, 408]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='SoilColumnElasticPlaneStrainPML', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8, 'nsamp': 5}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [45, 405]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'NODE', 'file': 'Velocity.out', 'ndps': 8, 'resp': 'vel', 'list': [45, 405]}
SVL.addRecorder(tag=3, attributes=rec)

rec = {'name': 'NODE', 'file': 'Acceleration.out', 'ndps': 8, 'resp': 'accel', 'list': [45, 405]}
SVL.addRecorder(tag=4, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 1000})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'ExtendedNewmark', 'dt': 0.010})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()
