"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#Total moment
m0 = 83.775

SVL.Options['file'     ] = 'Debugging_P02'
SVL.Options['update'   ] = 'Progressive'
SVL.Options['nparts'   ] = 1
SVL.Options['dimension'] = 2

#Create Recorder
SVL.addRecorder(tag=1, attributes={'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': 11})
SVL.addRecorder(tag=2, attributes={'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': 1})
SVL.addRecorder(tag=3, attributes={'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8})

#==============================================================================
# FIRST STAGE : ONE-THIRD LOAD
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 100.0, 'nu': 0.33, 'rho': 0.00})

#CReate Section
SVL.addSection(tag=1, name='Lin2DRectangular', model='Plain', attributes={'material': 1, 'b': 2.0, 'h': 2.0})

#Create Nodes
nNodes = 11
for k in range(nNodes):
    SVL.addNode(tag=(k+1), ndof=3, coords=[float(k), 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2, 3])

#Create Element
for k in range(nNodes-1):
    SVL.addElement(tag=(k+1), conn=[k+1, k+2], name='kin2DFrame2', attributes={'section': 1})
#SVL.printAll('Elements')

#Create function
SVL.addFunction(tag=1, name='Constant', attributes={'mag': m0/3, 'dir': [0.0, 0.0, 1.0]})

#Create a Load
SVL.addLoad(tag=1, name='PointLoad', attributes={'fun': 1, 'type': 'Concentrated', 'list': [11]})

#Create a Combination
SVL.addCombinationCase(tag=1, name='Stage-1', attributes={'load': [1], 'factor': [1.0]})

#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 100})
SVL.addAlgorithm(tag=1, attributes={'name': 'Newton', 'nstep': 100, 'cnvgtol': 1.0E-03, 'cnvgtest': 'RelativeIncrementalDisplacement'})
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles(combo=1)

#==============================================================================
# SECOND STAGE : ANOTHER THIRD LOAD
#==============================================================================
#Create function
SVL.addFunction(tag=2, name='Constant', attributes={'mag': m0/3, 'dir': [0.0, 0.0, 1.0]})

#Create a Load
SVL.addLoad(tag=2, name='PointLoad', attributes={'fun': 2, 'type': 'Concentrated', 'list': [11]})

#Create a Combination
SVL.addCombinationCase(tag=2, name='Stage-2', attributes={'load': [1], 'factor': [1.0]})

#Create Analysis
SVL.addAnalysis(tag=2, attributes={'name': 'Static', 'nt': 100})
SVL.addAlgorithm(tag=2, attributes={'name': 'Newton', 'nstep': 100, 'cnvgtol': 1.0E-03, 'cnvgtest': 'RelativeIncrementalDisplacement'})
SVL.addIntegrator(tag=2, attributes={'name': 'Static'})
SVL.addSolver(tag=2, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=2, combo=2, attributes={'analysis': 2, 'algorithm': 2, 'integrator': 2, 'solver': 2})

#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles(combo=2)

#==============================================================================
# SECOND STAGE : ANOTHER THIRD LOAD
#==============================================================================
#Create function
SVL.addFunction(tag=3, name='Constant', attributes={'mag': m0/3, 'dir': [0.0, 0.0, 1.0]})

#Create a Load
SVL.addLoad(tag=3, name='PointLoad', attributes={'fun': 3, 'type': 'Concentrated', 'list': [11]})

#Create a Combination
SVL.addCombinationCase(tag=3, name='Stage-3', attributes={'load': [1], 'factor': [1.0]})

#Create Analysis
SVL.addAnalysis(tag=3, attributes={'name': 'Static', 'nt': 100})
SVL.addAlgorithm(tag=3, attributes={'name': 'Newton', 'nstep': 100, 'cnvgtol': 1.0E-03, 'cnvgtest': 'RelativeIncrementalDisplacement'})
SVL.addIntegrator(tag=3, attributes={'name': 'Static'})
SVL.addSolver(tag=3, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=3, combo=3, attributes={'analysis': 3, 'algorithm': 3, 'integrator': 3, 'solver': 3})

#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles(combo=3)
