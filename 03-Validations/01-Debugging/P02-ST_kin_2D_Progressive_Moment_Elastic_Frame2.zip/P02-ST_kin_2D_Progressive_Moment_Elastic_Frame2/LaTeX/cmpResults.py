#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 
ResultFigure = filepath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this   = filepath + '/Solution/'

#ANALYTICAL SOLUTION:
solution  = np.loadtxt('Numerical/pvsu.txt', dtype='float', skiprows=0)

#SeismoVLAB SOLUTION:
Phase1 = np.loadtxt(this + 'Stage-1/Displacement.0.out', dtype='float', skiprows=2)
Phase2 = np.loadtxt(this + 'Stage-2/Displacement.0.out', dtype='float', skiprows=2)
Phase3 = np.loadtxt(this + 'Stage-3/Displacement.0.out', dtype='float', skiprows=2)

displacement = np.concatenate(([0.0],Phase1[:,1],Phase2[:,1],Phase3[:,1]), axis=0)
Load = 83.775*np.arange(0.0, 1.00 + 0.01/3, 0.01/3)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(10.5,9.0))
plt.plot(displacement, Load, 'r-', solution[:,0], solution[:,1], 'b.')
plt.xlabel("$v\, [in]$", fontsize=30)
plt.ylabel("$M_z\, [kip-in]$", fontsize=30)
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is the same as shown in Figure~\\ref{fig:Verification-model_Corrotational2D_Beam_ML} and is 
defined to test \\texttt{Progressive} analysis option. For this example, 
all beam members have a cross-sectional area, $A = 4.0\,[in^2]$, second area moment of inertia,
$I = 1.3333\,[in^4]$ and modulus of elasticity, $E = 100\,[ksi]$. The beam is $10\,[in]$ long and is
discretized with 10 equal length beam elements and 11 nodes. A moment is placed at Node (11) of 
magnitude $M_c = 2 \pi \\textrm{EI}/\\textrm{L} \,[kip-in]$. This moment is applied in three different stages: First, 
a $M = M_c/3$ moment is applied, then an extra $M_c/3$ is applied, and finally the last $M_c/3$ is applied. Results 
should coincide with numerical solution provied by Louie L. Yaw. Figure~\\ref{fig:Verification_Progressive_Corrotational2D_Beam_ML} at node (11). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.35\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Moment displacement curve at (42): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_Progressive_Corrotational2D_Beam_ML}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.close()
