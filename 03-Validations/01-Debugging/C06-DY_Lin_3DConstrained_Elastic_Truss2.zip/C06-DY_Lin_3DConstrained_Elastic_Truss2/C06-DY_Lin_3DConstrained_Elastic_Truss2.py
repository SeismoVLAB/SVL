"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_C06'
SVL.Options['format'] = 'json'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 7.50E+06, 'nu': 0.20, 'rho': 2500.0})

#Create Nodes
SVL.addNode(tag=1, ndof=3, coords=[0.00, 0.00, 0.00])
SVL.addNode(tag=2, ndof=3, coords=[0.00, 0.00, 1.00])
SVL.addNode(tag=3, ndof=3, coords=[0.00, 0.00, 2.00])
SVL.addNode(tag=4, ndof=3, coords=[1.00, 0.00, 2.00])
SVL.addNode(tag=5, ndof=3, coords=[1.00, 0.00, 1.00])
SVL.addNode(tag=6, ndof=3, coords=[1.00, 0.00, 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2, 3])
SVL.addRestrain(tag=2, dof=2)
SVL.addRestrain(tag=3, dof=2)
SVL.addRestrain(tag=4, dof=2)
SVL.addRestrain(tag=5, dof=2)
SVL.addRestrain(tag=6, dof=[1, 2, 3])

#Constraint degree of freedom
SVL.addConstraint(tag=-2, name='Equal', attributes={'stag': 4, 'sdof': 1, 'mtag': 3, 'mdof': 1})
SVL.addConstraint(tag=-3, name='Equal', attributes={'stag': 5, 'sdof': 1, 'mtag': 2, 'mdof': 1})

#Create Element
SVL.addElement(tag=1, conn=[1, 2], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
SVL.addElement(tag=2, conn=[2, 3], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
SVL.addElement(tag=3, conn=[3, 4], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
SVL.addElement(tag=4, conn=[4, 5], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
SVL.addElement(tag=5, conn=[5, 6], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
SVL.addElement(tag=6, conn=[1, 5], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
SVL.addElement(tag=7, conn=[2, 6], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
SVL.addElement(tag=8, conn=[2, 4], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
SVL.addElement(tag=9, conn=[3, 5], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
SVL.addElement(tag=10, conn=[2, 5], name='lin3DTruss2', attributes={'material': 1, 'area': 0.25})
#SVL.printAll('Elements')

#Create function
fun = {'file': 'PointLoad.txt', 'dir': [1.0, 0.0, 0.0]}
SVL.addFunction(tag=1, name='TimeSerie', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'TimeSerie', 'list': [2, 3]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='ConstrainedTruss', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Animation.out', 'ndps': 8, 'resp': 'disp', 'list': [1, 2, 3, 4, 5, 6]}
SVL.addRecorder(tag=1, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 201})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.025})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
