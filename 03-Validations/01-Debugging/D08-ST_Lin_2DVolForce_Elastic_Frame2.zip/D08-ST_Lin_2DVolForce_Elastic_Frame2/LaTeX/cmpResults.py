#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
L      = 1.0
h      = 0.05
g      = 9.8067
rho    = 2500
E      = 68.90E9
I      = 1.0/12.0*h**4
q      = rho*g*h**2

this   = filepath + '/Solution/Cantilever2D/'

#ANALYTICAL SOLUTION:
delta    = -q*L**4/8.0/E/I
reaction = np.array([0.0, q*L, q*L**2/2.0])

#SeismoVLAB SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=2)
force = np.loadtxt(this + 'Reaction.0.out',dtype='float', skiprows=2)

#COMPUTES ERRORS:
error0 = abs((nodal[1] - delta)/delta);
error1 = max(abs(np.divide(force[[1,2]] - reaction[[1,2]], reaction[[1,2]])));

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-Cantilever_SelfWeight2D} is a cantilever beam 
defined to test \\texttt{lin2DFrame2} element with material type \\texttt{Elastic1DLinear} and gravity load. The 
material has a elasticity modulus $E = 68.9 \;GPa$, and a Poisson's ratio $\\nu = 0.33$, and a density of $\\rho = 2500 \; kg/m^3$. 
Nodes (1) and node (6) have coordinate $(0.0, 0.0)$ and $(1.0, 0.0)$ respectively. Node (1) is fixed in \\textrm{X}
and \\textrm{Y} directions, while node (6) is free. The Bernoulli beam has a rectangular cross section with $h = b = 0.05 \; m$. The beam is 
subjected to its own weight. Responses are verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.425 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin2DFrame2} and Self-Weight Load in 2D.}\n")
LaTeXfile.write("\t\label{fig:Verification-Cantilever_SelfWeight2D}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the vertical deformation at node (6) is : \\texttt{%#1.6g}. The maximum relative error for the reaction forces at node (1) is : \\texttt{%#1.6g}." % (error0, error1))
LaTeXfile.close()
