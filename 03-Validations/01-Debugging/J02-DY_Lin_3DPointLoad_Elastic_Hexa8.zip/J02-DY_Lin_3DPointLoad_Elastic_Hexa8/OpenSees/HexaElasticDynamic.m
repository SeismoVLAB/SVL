clc; clear; close all;

opensees = 'HexaElasticDynamic-OpenSees/';
this     = 'HexaElasticDynamic/';

dis1 = load([opensees 'displacement.out']);
vel1 = load([opensees 'velocity.out']);
acc1 = load([opensees 'acceleration.out']); 
stress1 = load([opensees 'stress.out']);

dis2 = dlmread([this 'Displacement.0.out'],' ', 2, 0);
vel2 = dlmread([this 'Velocity.0.out'],' ', 2, 0);
acc2 = dlmread([this 'Acceleration.0.out'],' ', 2, 0); 
stress2 = dlmread([this 'Stress.0.out'],' ', 2, 0);

t1 = dis1(:,1);

t2 = 0.025:0.025:200*0.025;

h = figure; 
h.PaperUnits = 'inches';
h.PaperSize=[8 2];
h.Units = 'inches';
h.PaperPosition=[0 0 8 2];
title('Displacement')
subplot(1,3,1)
plot(t1,dis1(:,4),'b.',t2,dis2(:,1),'r-');
xlabel('time [s]');ylabel('u_x(t) [m]');
grid on;xlim([0 5]);
subplot(1,3,2)
plot(t1,dis1(:,2),'b.',t2,dis2(:,2),'r-');
xlabel('time [s]');ylabel('u_y(t) [m]');
grid on;xlim([0 5]);
subplot(1,3,3)
plot(t1,dis1(:,3),'b.',t2,dis2(:,3),'r-');
xlabel('time [s]');ylabel('u_z(t) [m]');
grid on;xlim([0 5]);
print(h,'-dpng',[this 'displacement.png']);
print(h,'-dpng',[this 'displacement.png']);

h = figure; 
title('Acceleration')
subplot(1,3,1)
plot(t1,acc1(:,4),'b.',t2,acc2(:,1),'r-');
xlabel('time [s]');ylabel('a_x(t) [m]');
subplot(1,3,2)
plot(t1,acc1(:,2),'b.',t2,acc2(:,2),'r-');
xlabel('time [s]');ylabel('a_y(t) [m]');
subplot(1,3,3)
plot(t1,acc1(:,3),'b.',t2,acc2(:,3),'r-');
xlabel('time [s]');ylabel('a_z(t) [m]');
h = figure; hold all;
for i = 1:6
    plot(t1,stress1(:,i+1),'b.',t2,stress2(:,i),'r-');
    xlabel('time [s]');ylabel('\sigma_{ij}(t) [Pa]');
end