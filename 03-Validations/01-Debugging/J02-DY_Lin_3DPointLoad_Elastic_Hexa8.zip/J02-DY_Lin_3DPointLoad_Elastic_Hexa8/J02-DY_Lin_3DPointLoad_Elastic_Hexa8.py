"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_J02'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic3DLinear', attributes={'E': 2.080E+08, 'nu': 0.30, 'rho': 2000.0})

#Create Nodes (for quads)
SVL.addNode(tag=1, ndof=3, coords=[0.00, 0.00, 0.00])
SVL.addNode(tag=2, ndof=3, coords=[2.00, 0.00, 0.00])
SVL.addNode(tag=3, ndof=3, coords=[2.00, 2.00, 0.00])
SVL.addNode(tag=4, ndof=3, coords=[0.00, 2.00, 0.00])
SVL.addNode(tag=5, ndof=3, coords=[0.00, 0.00, 2.00])
SVL.addNode(tag=6, ndof=3, coords=[2.00, 0.00, 2.00])
SVL.addNode(tag=7, ndof=3, coords=[2.00, 2.00, 2.00])
SVL.addNode(tag=8, ndof=3, coords=[0.00, 2.00, 2.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1,2,3])
SVL.addRestrain(tag=2, dof=[3])
SVL.addRestrain(tag=3, dof=[3])
SVL.addRestrain(tag=4, dof=[3])

#Create Element
SVL.addElement(tag=1, conn=[1,2,3,4,5,6,7,8], name='lin3DHexa8', attributes={'material': 1, 'rule': 'Gauss', 'np': 8})

#Create function
SVL.addFunction(tag=1, name='TimeSerie', attributes={'file': 'StressLoad.txt', 'dir': [0.01, 0.0, 0.0]})
SVL.addFunction(tag=2, name='TimeSerie', attributes={'file': 'StressLoad.txt', 'dir': [0.0, 0.01, 0.0]})
SVL.addFunction(tag=3, name='TimeSerie', attributes={'file': 'StressLoad.txt', 'dir': [0.0, 0.0, -0.05]})

#Create a Load
SVL.addLoad(tag=1, name='PointLoad', attributes={'fun': 1, 'type': 'TimeSerie', 'list': [6]})
SVL.addLoad(tag=2, name='PointLoad', attributes={'fun': 2, 'type': 'TimeSerie', 'list': [8]})
SVL.addLoad(tag=3, name='PointLoad', attributes={'fun': 3, 'type': 'TimeSerie', 'list': [7]})

#Create a Combination
combo = {'load': [1,2,3], 'factor': [1.0,1.0,1.0]}
SVL.addCombinationCase(tag=1, name='HexaElasticDynamic', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [7]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Velocity.out', 'ndps': 8, 'resp': 'vel', 'list': [7]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'NODE', 'file': 'Acceleration.out', 'ndps': 8, 'resp': 'accel', 'list': [7]}
SVL.addRecorder(tag=3, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Stress.out', 'ndps': 8, 'resp': 'Stress', 'list': [1]}
SVL.addRecorder(tag=4, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Strain.out', 'ndps': 8, 'resp': 'Strain', 'list': [1]}
SVL.addRecorder(tag=5, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 201})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.025})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()
