"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_D11'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 100.0, 'nu': 0.33, 'rho': 0.00})

#CReate Section
SVL.addSection(tag=1, name='Lin2DRectangular', model='Plain', attributes={'material': 1, 'b': 2.0, 'h': 2.0})

#Create Nodes
nNodes = 11
for k in range(nNodes):
    SVL.addNode(tag=(k+1), ndof=3, coords=[float(k), 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2, 3])

#Create Element
for k in range(nNodes-1):
    SVL.addElement(tag=(k+1), conn=[k+1, k+2], name='kin2DFrame2', attributes={'section': 1})
#SVL.printAll('Elements')

#Create function
fun = {'mag': 83.775, 'dir': [0.0, 0.0, 1.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': [11]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='CantileverBeam', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': 11}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': 1}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 100})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Newton', 'nstep': 100, 'cnvgtol': 1.0E-03, 'cnvgtest': 'RelativeIncrementalDisplacement'})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()
