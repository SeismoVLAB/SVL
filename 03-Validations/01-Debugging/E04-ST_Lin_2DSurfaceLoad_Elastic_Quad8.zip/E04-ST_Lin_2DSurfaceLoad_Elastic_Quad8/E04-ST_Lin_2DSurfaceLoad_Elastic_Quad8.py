"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_E04'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic2DPlaneStress', attributes={'E': 1.0E+05, 'nu': 0.30, 'rho': 0.00})

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.00, 0.00])
SVL.addNode(tag=2, ndof=2, coords=[0.20, 0.00])
SVL.addNode(tag=3, ndof=2, coords=[0.20, 0.20])
SVL.addNode(tag=4, ndof=2, coords=[0.00, 0.20])
SVL.addNode(tag=5, ndof=2, coords=[0.40, 0.00])
SVL.addNode(tag=6, ndof=2, coords=[0.40, 0.20])
SVL.addNode(tag=7, ndof=2, coords=[0.60, 0.00])
SVL.addNode(tag=8, ndof=2, coords=[0.60, 0.20])
SVL.addNode(tag=9, ndof=2, coords=[0.80, 0.00])
SVL.addNode(tag=10, ndof=2, coords=[0.80, 0.20])
SVL.addNode(tag=11, ndof=2, coords=[1.00, 0.00])
SVL.addNode(tag=12, ndof=2, coords=[1.00, 0.20])
SVL.addNode(tag=13, ndof=2, coords=[0.10, 0.00])
SVL.addNode(tag=14, ndof=2, coords=[0.20, 0.10])
SVL.addNode(tag=15, ndof=2, coords=[0.10, 0.20])
SVL.addNode(tag=16, ndof=2, coords=[0.00, 0.10])
SVL.addNode(tag=17, ndof=2, coords=[0.30, 0.00])
SVL.addNode(tag=18, ndof=2, coords=[0.40, 0.10])
SVL.addNode(tag=19, ndof=2, coords=[0.30, 0.20])
SVL.addNode(tag=20, ndof=2, coords=[0.50, 0.00])
SVL.addNode(tag=21, ndof=2, coords=[0.60, 0.10])
SVL.addNode(tag=22, ndof=2, coords=[0.50, 0.20])
SVL.addNode(tag=23, ndof=2, coords=[0.70, 0.00])
SVL.addNode(tag=24, ndof=2, coords=[0.80, 0.10])
SVL.addNode(tag=25, ndof=2, coords=[0.70, 0.20])
SVL.addNode(tag=26, ndof=2, coords=[0.90, 0.00])
SVL.addNode(tag=27, ndof=2, coords=[1.00, 0.10])
SVL.addNode(tag=28, ndof=2, coords=[0.90, 0.20])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=4, dof=[1, 2])
SVL.addRestrain(tag=16, dof=[1, 2])

#Create Element
SVL.addElement(tag=1, conn=[ 2,  3,  4,  1, 14, 15, 16, 13], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=2, conn=[ 5,  6,  3,  2, 18, 19, 14, 17], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=3, conn=[ 7,  8,  6,  5, 21, 22, 18, 20], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=4, conn=[ 9, 10,  8,  7, 24, 25, 21, 23], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=5, conn=[11, 12, 10,  9, 27, 28, 24, 26], name='lin2DQuad8', attributes={'material': 1, 'th': 0.20, 'rule': 'Gauss', 'np': 9})

#Create Surfaces
SVL.addSurface(tag=1, etag=1, conn=[4, 15,  3])
SVL.addSurface(tag=2, etag=2, conn=[3, 19,  6])
SVL.addSurface(tag=3, etag=3, conn=[6, 22,  8])
SVL.addSurface(tag=4, etag=4, conn=[8, 25, 10])
SVL.addSurface(tag=5, etag=5, conn=[10, 28, 12])

#Create function
fun = {'mag': 50.0, 'dir': [0.0, -1.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'surface', 'list': [1, 2, 3, 4, 5]}
SVL.addLoad(tag=1, name='ElementLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='QuadPlaneStrainElasticStatic', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [11,12]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': [1]}
SVL.addRecorder(tag=2, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
