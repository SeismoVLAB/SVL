#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 
ResultFigure = filepath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
this   = filepath + '/Solution/NonLinearTrussBeam/'

#ANALYTICAL SOLUTION:
solution  = np.loadtxt('Numerical/pvsu.txt', dtype='float', skiprows=0)

#SeismoVLab SOLUTION:
displacement = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=2)
displacement = np.append(0.0,displacement[:,2])
Load = 0.00035*np.arange(0.0, 1.01, 0.01)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(10.5,9.0))
plt.plot(-displacement, 1000*Load, 'r-', -solution[:,0], -1000*solution[:,1], 'b.')
plt.xlabel("$w\, [cm]$", fontsize=30)
plt.ylabel("$P\, [N]$", fontsize=30)
plt.ylim((0,0.35))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_Corrotational3D_Truss_Beam} and is 
defined to test \\texttt{kin3DTruss2} element with material type \\texttt{Elastic1DLinear}. For this example, the 
cantilevered space truss is $10 \,[m]$ long, $0.2 \,[m]$ wide and $0.5 \,[m]$ deep. The truss has two top chord 
members and two bottom chord members. For all truss members (both nodes at y=0 or both nodes at y=0.2 inches) the 
area used is $1.0 \,[cm^2]$. All members have a modulus of elasticity of $E = 1 \,[kN/cm^2]$. The nodes at the support 
for the cantilever are restrained in the xyz directions. Two vertical forces of magnitude $3.5 \, 10^{-4} [kN]$ are 
placed at Node (42) and (84).  The tolerance used for equilibrium iterations is $10^{-6}$. The responses are 
verified against numerical solution provied by Louie L. Yaw. Figure~\\ref{fig:Verification_Corrotational3D_Truss_Beam} 
shows the force displacement curve at node (42). \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.55 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{kin3DTruss2} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_Corrotational3D_Truss_Beam}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.35\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Force displacement curve at (42): Analytical ({\color{blue}{$\dots$}}), SeismoVLab (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_Corrotational3D_Truss_Beam}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.close()
