"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_F04'
SVL.Options['format'] = 'json'
SVL.Options['massform'] = 'lumped'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 2

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#create Damping
SVL.addDamping(tag=1, name='Rayleigh', attributes={'am': 0.00, 'ak': 0.001, 'list': 1})

#Create Material
SVL.addMaterial(tag=1, name='PlasticPlaneStrainBA', attributes={'K': 2.9E+07, 'G': 2.0E+07, 'rho': 2000.0, 'h0': 0.0, 'h': 2.0E+06, 'm': 1.5, 'Su': 5.0E+04, 'beta': 0.5})

#Create Nodes
SVL.addNode(tag=1, ndof=2, coords=[0.00, 0.00])
SVL.addNode(tag=2, ndof=2, coords=[2.00, 0.00])
SVL.addNode(tag=3, ndof=2, coords=[2.00, 2.00])
SVL.addNode(tag=4, ndof=2, coords=[0.00, 2.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2])
SVL.addRestrain(tag=2, dof=2)
SVL.addRestrain(tag=3, dof=2)
SVL.addRestrain(tag=4, dof=2)

#Create Element
SVL.addElement(tag=1, conn=[1, 2, 3, 4], name='lin2DQuad4', attributes={'material': 1, 'th': 1.0, 'rule': 'Gauss', 'np': 4})
#SVL.printAll('Elements')

#Create function
fun = {'file': 'tri.in', 'dir': [4.0E+04, 0.00]}
SVL.addFunction(tag=1, name='TimeSerie', attributes=fun)

#Create a Load
load = {'type': 'TimeSerie', 'fun': 1, 'list': [3,4]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='QuadPlasticBADynamic', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [3]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Velocity.out', 'ndps': 8, 'resp': 'vel', 'list': [3]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'NODE', 'file': 'Acceleration.out', 'ndps': 8, 'resp': 'accel', 'list': [3]}
SVL.addRecorder(tag=3, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Stress.out', 'ndps': 8, 'resp': 'stress', 'list': [1]}
SVL.addRecorder(tag=4, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Strain.out', 'ndps': 8, 'resp': 'strain', 'list': [1]}
SVL.addRecorder(tag=5, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 15001})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Newton', 'nstep': 100, 'cnvgtol': 1.0E-06, 'cnvgtest': 'RelativeIncrementalDisplacement'})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.01})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('partition')
#SVL.printAll('Nodes')
