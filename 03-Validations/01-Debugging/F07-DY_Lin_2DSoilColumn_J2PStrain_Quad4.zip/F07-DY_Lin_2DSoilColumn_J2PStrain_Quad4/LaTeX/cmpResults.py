#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 
ResultFigure = filepath + "/LaTeX/ResultTest.png"
StressFigure = filepath + "/LaTeX/StressTest.png"
RickerFigure = filepath + "/LaTeX/Ricker.png"

#INPUT VARIABLES:
dt       = 0.001
this     = filepath + '/Solution/SoilColumnPlasticPlaneStrainJ2/'
openSeeS = filepath + '/OpenSees/'

#Ricker Pulse:
ricker  = np.loadtxt('ricker-SoilColumnPlasticPlaneStrainJ2.in', dtype='float', skiprows=2)

#OPENSEES SOLUTION:
dis1    = np.loadtxt(openSeeS + 'displacement.out', dtype='float', skiprows=0) 
vel1    = np.loadtxt(openSeeS + 'velocity.out'    , dtype='float', skiprows=0) 
acc1    = np.loadtxt(openSeeS + 'acceleration.out', dtype='float', skiprows=0) 
strain1 = np.loadtxt(openSeeS + 'strain.out', dtype='float', skiprows=0)
stress1 = np.loadtxt(openSeeS + 'stress.out', dtype='float', skiprows=0)

#SeismoVLab SOLUTION:
time    = np.arange(0.0, 9.999, dt) + dt
dis2    = np.loadtxt(this + 'Displacement.0.out', dtype='float', skiprows=3)
vel2    = np.loadtxt(this + 'Velocity.0.out'    , dtype='float', skiprows=3)
acc2    = np.loadtxt(this + 'Acceleration.0.out', dtype='float', skiprows=3)
strain2 = np.loadtxt(this + 'Strain.0.out', dtype='float', skiprows=2)
stress2 = np.loadtxt(this + 'Stress.0.out', dtype='float', skiprows=2)

#COMPUTES RMS ERRORS AT NODE 201:
error1x = np.sqrt(np.mean((dis1[:,3] - dis2[:,2])**2))
error1y = np.sqrt(np.mean((dis1[:,4] - dis2[:,3])**2))
error2x = np.sqrt(np.mean((vel1[:,3] - vel2[:,2])**2))
error2y = np.sqrt(np.mean((vel1[:,4] - vel2[:,3])**2))
error3x = np.sqrt(np.mean((acc1[:,3] - acc2[:,2])**2))
error3y = np.sqrt(np.mean((acc1[:,4] - acc2[:,3])**2)) 

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 18})
plt.figure(figsize=(10,7.5))

plt.plot(time, ricker)
plt.xlabel("$t$", fontsize=25)
plt.ylabel("$f(t) \; m/s$", fontsize=25)
plt.xlim((0,10))
plt.grid(True)
plt.savefig("LaTeX/Ricker.png")
plt.close()

plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 2, 1)
plt.plot(time, acc2[:,0], 'r-', acc1[0::3,0], acc1[0::3,1], 'b.')
plt.xlabel("$t$", fontsize=30)
plt.ylabel("$a_x(z = 0,t) \; m/s^2$", fontsize=30)
plt.xlim((0,10))
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(time, acc2[:,2], 'r-', acc1[0::3,0], acc1[0::3,3], 'b.')
plt.xlabel("$t$", fontsize=30)
plt.ylabel("$a_x(z = H,t) \; m/s^2$", fontsize=30)
plt.xlim((0,10))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(30,8.5))

plt.subplot(1, 3, 1)
plt.plot(strain2[:,9], stress2[:,9]/1E3, 'r-', strain1[0::25,7], stress1[0::25,7]/1E3, 'b.')
plt.xlabel("$\epsilon_{xx} (t)$"    , fontsize=30)
plt.ylabel("$\sigma_{xx}(t) \; kPa$", fontsize=30)
plt.xlim((-0.0010,0.0010))
plt.ylim((-10,10))
plt.grid(True)

plt.subplot(1, 3, 2)
plt.plot(strain2[:,10], stress2[:,10]/1E3, 'r-', strain1[0::25,8], stress1[0::25,8]/1E3, 'b.')
plt.xlabel("$\epsilon_{yy} (t)$"     , fontsize=30)
plt.ylabel("$\sigma_{yy} (t) \; kPa$", fontsize=30)
plt.xlim((-0.0010,0.0010))
plt.ylim((-10,10))
plt.grid(True)

plt.subplot(1, 3, 3)
plt.plot(2.0*1000*strain2[:,11], stress2[:,11]/1E3, 'r-', 1000*strain1[0::25,9], stress1[0::25,9]/1E3, 'b.')
plt.xlabel("$\gamma_{xy} (t) \, \\times \, 10^{-3}$"    , fontsize=30)
plt.ylabel("$\\tau_{xy} (t) \; kPa$", fontsize=30)
plt.grid(True)

plt.savefig("LaTeX/StressTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """1D site response analysis in a truncated half-space can be modeled numerically using the setting shown in 
Figure~\\ref{fig:Verification-J2-SoilColumn}a. We consider a soil column with height $H=100 \, m$ and width $B = 1 \,m$. \\texttt{linQuad2D4} 
element with \\texttt{PlasticPlaneStrainJ2} material is used for discretization. In total, 100 elements are used, i.e., $n = 100$. 
$E = 13 \; MPa$, $\\nu = 0.3$, and $\\rho = 2000 \; kg/m^3$. The half-space is truncated by using Lysmer dashpots and is modeled using 
\\texttt{ZeroLength1D} element with \\texttt{Viscous1DLinear} material. $c_r = \\rho_r V_r B/2$ where $\\rho_r = \\rho$ and $V_r = 50$ m/s. 
Incoming waves are modeled by nodal forces $f_r(t) = \\rho_r V_r B/2 \cdot f(t)$ applied at nodes (1) and (2). The function $f(t)$ is the velocity 
of the incident motion at depth $H$ and is shown in Figure~\\ref{fig:Verification-J2-SoilColumn}b. Rayleigh damping is used to model small 
strain damping with mass and stiffness proportional coefficients of 0.12442 and 0.00079, respectively. The same problem is modeled in 
OpenSees for verification. Accelerations at nodes (1) and (201) are shown in Figure~\\ref{fig:Verification-J2-SoilColumn-acceleration}. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\\begin{center}\n")
LaTeXfile.write("\t\subfigure[]{\n")
LaTeXfile.write("\t\t\\includegraphics[width=0.25 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t}\n")
LaTeXfile.write("\t\subfigure[]{\n")
LaTeXfile.write("\t\t\includegraphics[width=0.425 \\textwidth]{"+RickerFigure+"}\n")
LaTeXfile.write("\t}\n")
LaTeXfile.write("\t\end{center}\n")
LaTeXfile.write("\t\caption{Varification for 1D site response analysis in an elastic half-space.}\n")
LaTeXfile.write("\t\label{fig:Verification-J2-SoilColumn}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.95\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Accelerations at $z=H$ and $z=0$: Opensees ({\color{blue}{$\dots$}}), SeismoVLab (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification-J2-SoilColumn-acceleration}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.95\\textwidth]{"+StressFigure+"}\n")
LaTeXfile.write("\t\caption{Material responses at element 50 integration point 4: OpenSEES ({\color{blue}{$\dots$}}), SeismoVLab (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification-J2-SoilColumn-acceleration-IP}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The root mean square error for the displacements at node (201) is : (\\texttt{%#1.6g}, \\texttt{%#1.6g}), while the maximum relative error for the velocity and acceleration are : (\\texttt{%#1.6g},\\texttt{%#1.6g}), and (\\texttt{%#1.6g},\\texttt{%#1.6g}) respectively." % (error1x,error1y, error2x, error2y, error3x, error3y))
LaTeXfile.close()
