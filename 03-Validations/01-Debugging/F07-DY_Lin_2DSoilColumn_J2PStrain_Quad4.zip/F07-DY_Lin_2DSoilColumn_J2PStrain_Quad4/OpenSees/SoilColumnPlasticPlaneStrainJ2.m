clc; clear; close all;

opensees = 'SoilColumnPlasticPlaneStrainJ2-OpenSees/';
this     = 'SoilColumnPlasticPlaneStrainJ2/';

dis1 = load([opensees 'displacement.out']);
vel1 = load([opensees 'velocity.out']);
acc1 = load([opensees 'acceleration.out']); 
stress1 = load([opensees 'stress.out']); stress1(:,1) = [];
strain1 = load([opensees 'strain.out']); strain1(:,1) = [];

dis2 = dlmread([this 'Displacement.0.out'],'', 3, 0);
vel2 = dlmread([this 'Velocity.0.out'],'', 3, 0);
acc2 = dlmread([this 'Acceleration.0.out'],'', 3, 0); 
stress2 = dlmread([this 'Stress.0.out'],'', 2, 0);
strain2 = dlmread([this 'Strain.0.out'],'', 2, 0);

% ricker = load('ricker-OpenSees.in');
% ricker = ricker(2:end);
% 
% t1 = dis1(:,1);

t1 = 0:0.001:9999*0.001;t2 = t1(2:end);

% [rw,t] = ricker(2,5000,0.001,1);
% csvwrite('rickePlasticPlaneStrainJ2-OpenSees',rw');

%% plot input incident wave
% h = figure;
% h.PaperUnits = 'inches';
% h.PaperSize=[4 3];
% h.Units = 'inches';
% h.PaperPosition=[0 0 4 3];
% plot(t2,ricker,'b-'); grid on;
% xlabel('time [s]'); ylabel('f(t) [m/s]');
% print(h,'-dpng',[this 'ricker.png']);
% print(h,'-dpng',[this 'ricker.png']);
%%

h = figure; 
title('Displacement')
subplot(1,2,1); hold all;
plot(t1,dis1(:,2),'b-');
plot(t2,dis2(:,1),'r--');
xlabel('time [s]');ylabel('u_x(t) @ z = 0 [m]');
grid on;
subplot(1,2,2); hold all;
plot(t1,dis1(:,4),'b-');
plot(t2,dis2(:,3),'r--');
xlabel('time [s]');ylabel('u_x(t) @ z = H [m]');
grid on;
print(h,'-dpng',[this 'displacement.png']);
print(h,'-dpng',[this 'displacement.png']);

h = figure; 
title('Velocity')
subplot(1,2,1); hold all;
plot(t1,vel1(:,2),'b-');
plot(t2,vel2(:,1),'r--');
xlabel('time [s]');ylabel('v_x(t) @ z = 0 [m/s]');
grid on;
subplot(1,2,2);hold all;
plot(t1,vel1(:,4),'b-');
plot(t2,vel2(:,3),'r--');
xlabel('time [s]');ylabel('v_x(t) @ z = H [m/s]');
grid on;
print(h,'-dpng',[this 'velocity.png']);
print(h,'-dpng',[this 'velocity.png']);

h = figure; 
h.PaperUnits = 'inches';
h.PaperSize=[8 3];
h.Units = 'inches';
h.PaperPosition=[0 0 8 3];
title('Acceleration')
subplot(1,2,1); hold all;
plot(t1,acc1(:,2),'b-');
plot(t2,acc2(:,1),'r--');
xlabel('time [s]');ylabel('a_x(t) @ z = 0 [m/s/s]');
grid on;
legend('opensees','software')
subplot(1,2,2); hold all;
plot(t1,acc1(:,4),'b-');
plot(t2,acc2(:,3),'r--');
xlabel('time [s]');ylabel('a_x(t) @ z = H [m/s/s]');
grid on;
print(h,'-dpng',[this 'acceleration.png']);
print(h,'-dpng',[this 'acceleration.png']);
%%
h = figure; hold all;
h.PaperUnits = 'inches';
h.PaperSize=[4 3];
h.Units = 'inches';
h.PaperPosition=[0 0 4 3];
plot(strain1(:,3),stress1(:,3),'b');
plot(2*strain2(:,3),stress2(:,3),'r--');grid on;
xlabel('\epsilon_{12}');ylabel('\sigma_{12} [Pa]');
print(h,'-dpng',[this 'stressstrain.png']);
print(h,'-dpng',[this 'stressstrain.png']);