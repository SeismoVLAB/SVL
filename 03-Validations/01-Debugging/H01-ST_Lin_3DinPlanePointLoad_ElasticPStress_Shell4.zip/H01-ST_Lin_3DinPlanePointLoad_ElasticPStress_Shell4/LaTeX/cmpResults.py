#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
eps      = 1E-15
this     = filepath + '/Solution/ShellWall/'
opensees = filepath + '/ETABS/'

#ANALYTICAL SOLUTION:
nodalETABS = np.loadtxt(opensees + 'Displacement.out',dtype='float')
forceETABS = np.loadtxt(opensees + 'Reactions.out',dtype='float')

#SeismoVLAB SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=3)
nodal = np.reshape(nodal, (2,6))

force = np.loadtxt(this + 'InternalForce.0.out',dtype='float', skiprows=2)
force = np.reshape(force, (4,6))
force = force[[0,1],:]

#COMPUTES ERRORS:
error1 = np.amax(np.absolute(np.divide(nodalETABS - nodal, nodalETABS + eps)))
error2 = np.amax(np.absolute(np.divide(forceETABS - force, forceETABS + eps)))

print('\x1B[33mALERT H01-ST_Lin \x1B[0m: The drilling is not being matched for lin3DShell4.')

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:Verification-Shell_inPlane} is a vertical shell (wall) element defined to 
test \\texttt{lin3DShell4} elements with material type \\texttt{Elastic2DPlaneStress}. The wall element has material with elasticity 
moduli $E = 25.0 \,GPa$, and a Poisson's ratio $\\nu = 0.25$. Nodes (1), (2), (3), and (4) have coordinate $(5.0, 0.0, 0.0)$, 
$(0.0, 0.0, 0.0)$, and $(0.0, 0.0, 5.0)$, and $(5.0, 0.0, 5.0)$ respectively. Nodes (1) and (2) are clamped, i.e., displacements and 
rotation along/about \\textrm{X}, \\textrm{Y} and \\textrm{Z} are restrained. The shell has a thickness of $t_h = 0.1\;m$. A horizontal in-plane load is 
placed at node (4) with magnitude $P = 10 \; kN$ and direction $\hat{n} = (-1,0,0)$. Responses are verified against numerical (ETABS) solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.275 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3DShell4} with \\texttt{Elastic2DPlaneStress} material and kinematic constraints.}\n")
LaTeXfile.write("\t\label{fig:Verification-Shell_inPlane}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the horizontal deformation at node (3) and (4) is : \\texttt{%#1.6g}. The maximum relative error for the reaction forces at node (1) and (2) is : \\texttt{%#1.6g}." % (error1, error2))
LaTeXfile.close()
