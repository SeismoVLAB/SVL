#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 

#INPUT VARIABLES:
this   = filepath + '/Solution/Cantilever3DBeam/'

#ANALYTICAL SOLUTION:
P  = 1000.0
L  = 3.50
E  = 25E9
h  = 1.00
b  = 0.40
nu = 0.25
k  = 10.0*(1.0 + nu)/(12.0 + 11.0*nu)
G  = E/(2.0*(1 + nu))
A  = b*h
I22 = h*b**3/12.0
I33 = b*h**3/12.0

delta    = np.array([P*L/A/E, P*L/k/A/G + P*L**3/3.0/E/I22, -P*L/k/A/G -P*L**3/3.0/E/I33])/np.sqrt(3)
reaction = np.array([-P, -P,  P, 0.0, -P*L, -P*L])/np.sqrt(3)

#SeismoVLAB SOLUTION:
nodal = np.loadtxt(this + 'Displacement.0.out',dtype='float', skiprows=2)
force = np.loadtxt(this + 'InternalForce.0.out',dtype='float', skiprows=2)

#COMPUTES ERRORS:
error1 = max((nodal[0:3] - delta)/delta);
error2 = max(np.divide(force[0:6] - reaction, reaction + eps));

#GENERATE THE LATEX FILE:
Description = """The problem showed in Figure~\\ref{fig:CantileverBeam_3DTimoshenko_Elastic1DLinear} is 
defined to test \\texttt{lin2DFrame2} element with material type \\texttt{Elastic1DLinear}. The material 
has a elasticity moduli $E = 25.0 \;GPa$, and a Poisson's ratio $\\nu = 0.25$. Nodes (1) and node (2) have 
coordinate $(0.0, 0.0, 0.0)$ and $(3.5, 0.0, 0.0)$ respectively. Node (1) is fixed in \\textrm{X} and 
\\textrm{Y} directions, while node (2) is free. The Timoshenko beam has a rectangular cross section 
with $h = 1.0\;m$ and $b = 0.4 \; m$. A load is placed at node (2) with magnitude $P = 1 \; kN$ and 
direction $\hat{n}=(1,1,-1)$. Responses are verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.285 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3DFrame2} with \\texttt{Elastic1DLinear} material.}\n")
LaTeXfile.write("\t\label{fig:CantileverBeam_3DTimoshenko_Elastic1DLinear}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The relative error for the vertical deformation is : \\texttt{%#1.6g}, while the maximum relative error for the reaction forces are : \\texttt{%#1.6g}." % (error1, error2))
LaTeXfile.close()
