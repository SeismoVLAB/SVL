"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_H05'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 2.5E+10, 'nu': 0.25, 'rho': 2500.0})
SVL.addMaterial(tag=2, name='Elastic2DPlaneStress', attributes={'E': 2.5E+10, 'nu': 0.25, 'rho': 2500.0})


#Create Section
SVL.addSection(tag=1, name='Lin3DRectangular', model='Plain', attributes={'material': 1, 'h': 0.75, 'b': 0.25})
SVL.addSection(tag=2, name='Lin3DThinArea', model='Plain', attributes={'material': 2, 'th': 0.1})

#Create Nodes (for quads)
SVL.addNode(tag=1, ndof=6, coords=[0.00, 0.00, 0.00])
SVL.addNode(tag=2, ndof=6, coords=[5.00, 0.00, 0.00])
SVL.addNode(tag=3, ndof=6, coords=[5.00, 5.00, 0.00])
SVL.addNode(tag=4, ndof=6, coords=[0.00, 5.00, 0.00])
SVL.addNode(tag=5, ndof=6, coords=[0.00, 0.00, 3.50])
SVL.addNode(tag=6, ndof=6, coords=[5.00, 0.00, 3.50])
SVL.addNode(tag=7, ndof=6, coords=[5.00, 5.00, 3.50])
SVL.addNode(tag=8, ndof=6, coords=[0.00, 5.00, 3.50])
#SVL.printAll('Nodes')

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1,2,3,4,5,6])
SVL.addRestrain(tag=2, dof=[1,2,3,4,5,6])
SVL.addRestrain(tag=3, dof=[1,2,3,4,5,6])
SVL.addRestrain(tag=4, dof=[1,2,3,4,5,6])

#Diaphragm constraint
SVL.addDiaphragm(tag=1, attributes={'tag': 9, 'axis': 'Z', 'list': [5,6,7,8]})

#Create Element
SVL.addElement(tag=1, conn=[1,5], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 5})
SVL.addElement(tag=2, conn=[2,6], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 5})
SVL.addElement(tag=3, conn=[3,7], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 5})
SVL.addElement(tag=4, conn=[4,8], name='lin3DFrame2', attributes={'section': 1, 'formulation': 'Bernoulli', 'rule': 'Gauss', 'np': 5})
SVL.addElement(tag=5, conn=[5,6,7,8], name='lin3DShell4', attributes={'section': 2, 'rule': 'Gauss', 'np': 9})
#SVL.printAll('Elements')

#Create function
#TODO: Check the direction may be is in Y???
fun = {'mag': 10000.0, 'dir': [1.0, 0.0, 0.0, 0.0, 0.0, 0.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': 8}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='Diaphragm', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [5,6,7,8]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': [1,2,3,4]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 1})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Enforce diaphragm constraints
SVL.ApplyConstraints()

#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
