#!/usr/bin/python3

import os
import numpy as np
import matplotlib.pyplot as plt

#The path
filepath = os.getcwd() 

#FIGURE OUTPUT NAMES:
ModelFigure  = filepath + "/LaTeX/ModelTest.png" 
ResultFigure = filepath + "/LaTeX/ResultTest.png" 

#INPUT VARIABLES:
P = 10.0
A = 1.00
L = 1.00
E = 1.00
H = 0.25
K = 0.25
Sy = 5.0
ey = Sy/E
Et = E*(K+H)/(E+K+H)

this = filepath + '/Solution/TrussAxialPlastic/'

#SeismoVLAB SOLUTION:
strain = np.loadtxt(this + 'Strain.0.out', dtype='float', skiprows=2)
stress = np.loadtxt(this + 'Stress.0.out', dtype='float', skiprows=2)

#ANALYTICAL SOLUTION:
Strain = strain
Stress = np.multiply(E*Strain, Strain <= ey) + np.multiply(Sy + Et*(Strain-ey), Strain > ey)

#COMPUTES ERRORS:
delta = abs(strain - Strain)
error1 = max(delta)

delta = abs(stress - Stress)
error2 = max(delta)

#GENERATE THE COMPARISON PLOTS:
plt.rcParams.update({'font.size': 22})
plt.figure(figsize=(7.5,7.5))
plt.plot(strain, stress, 'r-', Strain, Stress, 'b.')
plt.xlabel("$\epsilon_{11}(t)$", fontsize=30)
plt.ylabel("$\sigma_{11}(t)$"  , fontsize=30)
plt.xlim((0,20.0))
plt.ylim((0,10.0))
plt.grid(True)

plt.savefig("LaTeX/ResultTest.png")
plt.close()

#GENERATE THE LATEX FILE:
Description = """Problem setting is shown in Figure~\\ref{fig:Verification-model_lin2DTruss2_plastic} and defined 
to test \\texttt{lin3DTruss2} element with material type \\texttt{Plastic1DJ2}. The material has elasticity modulus  
$E = 1.00 \; Pa$, and a Poisson's ratio $\\nu = 0.25$, hardening modulus $H = 0.25 \; Pa$, and kinematic modulus 
$K = 0.25 \; Pa$, the yield stress is taken as $\sigma_Y = 5.0 \; Pa$. The nodes (1), and (2) have the coordinate 
$(0.0, 0.0)$ and $(1.0, 0.0)$ respectively. Node (1) is fixed in \\textrm{X}-, \\textrm{Y}-, and \\textrm{Z}-directions, 
while node (2) is fixed in \\textrm{Y}-, and \\textrm{Z}-direction. The truss has an area of $1.00 \; m^2$, and 
a length of $L = 1.00 \; m$. For static analysis, the nodal force applied at node (2) is defined as $P = 1 \; kN$. The 
responses are verified against analytical solution. \n"""

LaTeXfile = open("LaTeX/LaTeXFile.tex", "w+")
LaTeXfile.write(Description)
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.205 \\textwidth]{"+ModelFigure+"}\n")
LaTeXfile.write("\t\caption{Varification for \\texttt{lin3DTruss2} with \\texttt{Plastic1DJ2} material.}\n")
LaTeXfile.write("\t\label{fig:Verification-model_lin2DTruss2_plastic}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("\\begin{figure}[H]\n")
LaTeXfile.write("\t\centering\n")
LaTeXfile.write("\t\includegraphics[width=0.285\\textwidth]{"+ResultFigure+"}\n")
LaTeXfile.write("\t\caption{Nodal responses at node (2): Analytical ({\color{blue}{$\dots$}}), SeismoVLAB (\protect\\redline).}\n")
LaTeXfile.write("\label{fig:Verification_Plastic1DJ2_lin2DTruss2}\n")
LaTeXfile.write("\end{figure}\n")
LaTeXfile.write("\n")
LaTeXfile.write("The maximum absolute error for the strain and stress are : \\texttt{%#1.6g}, \\texttt{%#1.6g} respectively." % (error1, error2))
LaTeXfile.close()
