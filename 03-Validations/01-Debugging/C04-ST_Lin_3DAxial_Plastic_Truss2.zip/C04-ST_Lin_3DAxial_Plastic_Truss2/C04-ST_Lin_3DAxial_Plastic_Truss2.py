"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_C04'
SVL.Options['nparts'] = 1
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
material= {'E': 1.0E+00, 'nu': 0.30000, 'rho': 1.00000, 'k': 0.25000, 'h': 0.25000, 'Sy': 5.000000E+00}
SVL.addMaterial(tag=1, name='Plastic1DJ2', attributes=material)

#Create Nodes
SVL.addNode(tag=1, ndof=3, coords=[0.00, 0.00, 0.00])
SVL.addNode(tag=2, ndof=3, coords=[1.00, 0.00, 0.00])

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1, 2, 3])
SVL.addRestrain(tag=2, dof=[2, 3])

#Create Element
SVL.addElement(tag=1, conn=[1, 2], name='lin3DTruss2', attributes={'material': 1, 'area': 1.0})

#Create function
fun = {'mag': 10.0, 'dir': [1.0, 0.0, 0.0]}
SVL.addFunction(tag=1, name='Constant', attributes=fun)

#Create a Load
load = {'fun': 1, 'type': 'Constant', 'list': [2]}
SVL.addLoad(tag=1, name='PointLoad', attributes=load)

#Create a Combination
combo = {'load': [1], 'factor': [1.0]}
SVL.addCombinationCase(tag=1, name='TrussAxialPlastic', attributes=combo)

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [2]}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Stress.out', 'ndps': 8, 'resp': 'Stress', 'list': [1]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'ELEMENT', 'file': 'Strain.out', 'ndps': 8, 'resp': 'Strain', 'list': [1]}
SVL.addRecorder(tag=3, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 100})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Newton', 'nstep': 50, 'cnvgtol': 1.0E-06, 'cnvgtest': 'RelativeIncrementalDisplacement'})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'ON'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()
