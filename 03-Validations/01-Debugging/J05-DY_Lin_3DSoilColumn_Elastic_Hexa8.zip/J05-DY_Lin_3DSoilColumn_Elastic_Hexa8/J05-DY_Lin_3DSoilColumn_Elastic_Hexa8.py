"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file']      = 'Debugging_J05'
SVL.Options['format']    = 'svl'
SVL.Options['nparts']    = 1
SVL.Options['dimension'] = 3
SVL.Options['massform']  = 'lumped'

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Damping
SVL.addDamping(tag=1, name='Rayleigh', attributes={'am': 0.1244195110, 'ak': 0.0007878958, 'list': 'ALL'})

#Create Material
SVL.addMaterial(tag=1, name='Elastic3DLinear', attributes={'E': 1.3E+07, 'nu': 0.30, 'rho': 2000.0})
SVL.addMaterial(tag=2, name='Viscous1DLinear', attributes={'eta': 2.50E+04})

#Create the Hexa domain
opts1 = {
    'ne': [1, 1, 100], 
    'class': 'Lin3DHexa8', 
    'ndof' : 3, 
    'P0': [0, 0, 0], 
    'P1': [1.0, 0, 0], 
    'P2': [0, 1.0, 0], 
    'P3': [0, 0, 100.0],
    'elems': 'HEXA8',
    'attributes': {'material': 1, 'rule': 'Gauss', 'np': 8}
    }
mesh1 = SVL.makeDomainVolume(options=opts1)
#SVL.printFormatted(mesh1['Nodes'])

#Assign the merge mesh to Entities
SVL.Entities['Nodes'] = mesh1['Nodes']
SVL.Entities['Elements'] = mesh1['Elements']

#Add Lysmer Nodes at base
SVL.addNode(tag=405, ndof=3, coords=[0.00000, 0.00000, 0.00000])
SVL.addNode(tag=406, ndof=3, coords=[1.00000, 0.00000, 0.00000])
SVL.addNode(tag=407, ndof=3, coords=[0.00000, 1.00000, 0.00000])
SVL.addNode(tag=408, ndof=3, coords=[1.00000, 1.00000, 0.00000])

#Add Lysmer elements at base
SVL.addElement(tag=101, name='ZeroLength1D', conn=[1, 405], attributes={'material': 2, 'dir': 1})
SVL.addElement(tag=102, name='ZeroLength1D', conn=[1, 405], attributes={'material': 2, 'dir': 2})
SVL.addElement(tag=103, name='ZeroLength1D', conn=[2, 406], attributes={'material': 2, 'dir': 1})
SVL.addElement(tag=104, name='ZeroLength1D', conn=[2, 406], attributes={'material': 2, 'dir': 2})
SVL.addElement(tag=105, name='ZeroLength1D', conn=[3, 407], attributes={'material': 2, 'dir': 1})
SVL.addElement(tag=106, name='ZeroLength1D', conn=[3, 407], attributes={'material': 2, 'dir': 2})
SVL.addElement(tag=107, name='ZeroLength1D', conn=[4, 408], attributes={'material': 2, 'dir': 1})
SVL.addElement(tag=108, name='ZeroLength1D', conn=[4, 408], attributes={'material': 2, 'dir': 2})


#Restrain degree of freedom
for nTag in SVL.Entities['Nodes']:
    if nTag <= 404:
        SVL.addRestrain(tag=nTag, dof=[3])
    else:
        SVL.addRestrain(tag=nTag, dof=[1,2,3])

#Create function
SVL.addFunction(tag=1, name='TimeSerie', attributes={'file': 'ricker.in', 'dir': [25000.0, 0.0, 0.0]})
SVL.addFunction(tag=2, name='TimeSerie', attributes={'file': 'ricker.in', 'dir': [25000.0, 0.0, 0.0]})
SVL.addFunction(tag=3, name='TimeSerie', attributes={'file': 'ricker.in', 'dir': [25000.0, 0.0, 0.0]})
SVL.addFunction(tag=4, name='TimeSerie', attributes={'file': 'ricker.in', 'dir': [25000.0, 0.0, 0.0]})

#Create a Load
SVL.addLoad(tag=1, name='PointLoad', attributes={'fun': 1, 'type': 'TimeSerie', 'list': [1]})
SVL.addLoad(tag=2, name='PointLoad', attributes={'fun': 2, 'type': 'TimeSerie', 'list': [2]})
SVL.addLoad(tag=3, name='PointLoad', attributes={'fun': 3, 'type': 'TimeSerie', 'list': [3]})
SVL.addLoad(tag=4, name='PointLoad', attributes={'fun': 4, 'type': 'TimeSerie', 'list': [4]})

#Create a Combination
SVL.addCombinationCase(tag=1, name='SoilColumn', attributes={'load': [1, 2, 3, 4], 'factor': [1.0, 1.0, 1.0, 1.0]})

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
rec = {'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8, 'nsamp': 5}
SVL.addRecorder(tag=1, attributes=rec)

rec = {'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [1, 401]}
SVL.addRecorder(tag=2, attributes=rec)

rec = {'name': 'NODE', 'file': 'Velocity.out', 'ndps': 8, 'resp': 'vel', 'list': [1, 401]}
SVL.addRecorder(tag=3, attributes=rec)

rec = {'name': 'NODE', 'file': 'Acceleration.out', 'ndps': 8, 'resp': 'accel', 'list': [1, 401]}
SVL.addRecorder(tag=4, attributes=rec)

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 1000})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.010})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Eigen', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
#SVL.renderData('element')
#SVL.printAll('Nodes')
