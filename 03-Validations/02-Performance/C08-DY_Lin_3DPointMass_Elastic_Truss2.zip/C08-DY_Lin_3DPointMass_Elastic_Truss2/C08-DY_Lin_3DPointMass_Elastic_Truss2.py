"""

"""
import math
import numpy as np
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Performance_C08'
SVL.Options['nparts'] = 5
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addMaterial(tag=1, name='Elastic1DLinear', attributes={'E': 1000.0, 'nu': 0.33, 'rho': 0.00})

#Create Nodes
nNodes = 101
for k in range(nNodes):
    SVL.addNode(tag=(k+1), ndof=3, coords=[1.0*k/(nNodes-1), 0.00, 0.00])
#SVL.printAll('Nodes')

#Restrain degree of freedom
for k in range(nNodes):
    if k != 0:
        SVL.addRestrain(tag=(k+1), dof=[2, 3])
    else:
        SVL.addRestrain(tag=(k+1), dof=[1, 2, 3])

#Point masses
mass = 1.0/(nNodes-1)
for k in range(1,nNodes-1):
    SVL.addMass(tag=(k+1), dof=[1, 2, 3], vals=[mass, mass, mass])
SVL.addMass(tag=1, dof=[1, 2, 3], vals=[mass/2, mass/2, mass/2])
SVL.addMass(tag=nNodes, dof=[1, 2, 3], vals=[mass/2, mass/2, mass/2])

#Create Element
for k in range(nNodes-1):
    SVL.addElement(tag=(k+1), conn=[k+1, k+2], name='lin3DTruss2', attributes={'material': 1, 'area': 1.00})
#SVL.printAll('Elements')

#Create function
SVL.addFunction(tag=1, name='TimeSerie', attributes={'file': 'PointLoad.txt', 'dir': [1.0, 0.0, 0.0]})

#Create a Load
SVL.addLoad(tag=1, name='PointLoad', attributes={'fun': 1, 'type': 'TimeSerie', 'list': [nNodes]})

#Create a Combination
SVL.addCombinationCase(tag=1, name='Truss3DAxial', attributes={'load': [1], 'factor': [1.0]})

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
SVL.addRecorder(tag=1, attributes={'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': nNodes})
SVL.addRecorder(tag=2, attributes={'name': 'ELEMENT', 'file': 'Stress.out', 'ndps': 8, 'resp': 'Stress', 'list': 1})
SVL.addRecorder(tag=3, attributes={'name': 'ELEMENT', 'file': 'Strain.out', 'ndps': 8, 'resp': 'Strain', 'list': 1})
SVL.addRecorder(tag=4, attributes={'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8, 'nsamp': 1})

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 230})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.0025})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'MUMPS', 'option': 'SPD', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Creates the SVL Run-Analysis files
SVL.CreateRunAnalysisFiles()
