import os
import sys
import numpy as np
from Core import SeismoVLAB as SVL

import matplotlib.pyplot as plt

SVL.Options['file'     ] = 'PhaseAnalysis'
SVL.Options['update'   ] = 'Transmissive'
SVL.Options['nparts'   ] = 4
SVL.Options['dimension'] = 2

#Simulation Properties
dt  = 0.001
th  = 1.0
dh  = 1.25
nt  = 4000
xpml = 50.0
zpml = 50.0

#Material Properties
Vs  = 200.0
nu  = 0.33
rho = 2000.0
Vp  = np.sqrt(2*(1 - nu)/(1 - 2*nu))*Vs
CFL = Vp*dt/dh

if CFL > 1.0:
    print(' The CFL = ', CFL, 'must be less than 1.00!!!\n')
    exit(-1)

#Load Soil and Building Mesh Information
filepath = os.path.abspath(os.path.dirname(sys.argv[0])) + '/Mesh/Mesh.mesh'
data = SVL.parseGMSH(filepath)

#Recorder for Paraview animation
SVL.addRecorder(tag=1, attributes={'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8, 'nsamp': 10})

#==============================================================================
# FIRST PHASE - SOIL GRAVITY LOAD
#==============================================================================
#Create Soil Material
SVL.addMaterial(tag=1, name='Elastic2DPlaneStrain', attributes={'E': 2.0*(1.0 + nu)*rho*Vs**2, 'nu': nu, 'rho': rho})
SVL.addMaterial(tag=2, name='Elastic2DPlaneStrain', attributes={'E': 2.500000E+15, 'nu': 0.20000, 'rho': 2.500000E+03})

#Joint the Nodes Tags from Foundation (47) and Soil (48)
eTags = 0
nTags = set() 
for pTag in [47,48]:
    nTags.update(data['Quadrilaterals']['Node'][pTag])

#Creates Soil Nodes
for nTag in nTags:
    p = data['Vertices'][nTag-1]
    SVL.addNode(tag=nTag, ndof=2, coords=[p[0], p[1]])

#Creates Soil Elements
for pTag in [47,48]:
    for eTag in data['Quadrilaterals']['Elem'][pTag]:
        eTags += 1
        c = data['Quadrilaterals']['Data'][eTag]
        if c[4] == 47:
            SVL.addElement(tag=eTags, conn=[c[0], c[1], c[2], c[3]], name='lin2DQuad4', attributes={'material': 2, 'th': th, 'rule': 'Gauss', 'np': 4})
        if c[4] == 48:
            SVL.addElement(tag=eTags, conn=[c[0], c[1], c[2], c[3]], name='lin2DQuad4', attributes={'material': 1, 'th': th, 'rule': 'Gauss', 'np': 4})

#The Domain Reduction Information 
x0 = [0.0, 0.0]
xl = [39.9, 39.9]

DRM = {
    'theta'   : 0.0, 
    'phi'     : 0.0, 
    'x0'      : [0.0, 0.0], 
    'wave'    : 'SV',
    'field'   : 'VEL',
    'filename': 'DRM.in',
    'dt'      : dt,
    'Ts'      : nt*dt, 
    't'       : [], 
    'signal'  : [], 
    'Interior': [], 
    'Exterior': [], 
    'Elements': []
}

#Create a Ricker signal for DRM
options = {'to': 1.0, 'f0': 2.0, 'dt': dt, 'Ap': 1.0, 'Ts': nt*dt}
DRM['t'], DRM['signal'] = SVL.Ricker(options, DRM['field'])

#Finds the DRM Elements and Interior and Exterior Nodes
DRM['Interior'], DRM['Exterior'], DRM['Elements'] = SVL.GetDRMInformation(x0, xl)


#Fix Soil Boundaries (54)
tol = 1.0E-03
for pTag in [54]:
    for nTag in data['Edges']['Node'][pTag]:
        p = data['Vertices'][nTag-1]
        if np.abs(p[0] - xpml) < tol:
            SVL.addRestrain(tag=nTag, dof=[1])
        if np.abs(p[0] + xpml) < tol:
            SVL.addRestrain(tag=nTag, dof=[1])
        if np.abs(p[1] + zpml) < tol:
            SVL.addRestrain(tag=nTag, dof=[2])

#Create a Constant Function
SVL.addFunction(tag=1, name='CONSTANT', attributes={'mag': 9.8, 'dir': [0.0, -1.0]})

#Create a Gravitational Load
SVL.addLoad(tag=1, name='ElementLoad', attributes={'fun': 1, 'type': 'Body', 'list': 'ALL'})

#Create a Combination
SVL.addCombinationCase(tag=1, name='Phase-1', attributes={'load': [1], 'factor': [1.0]})

#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 100})
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})
SVL.addIntegrator(tag=1, attributes={'name': 'Static'})
SVL.addSolver(tag=1, attributes={'name': 'MUMPS', 'option': 'SPD', 'update': 'OFF'})
#SVL.addSolver(tag=1, attributes={'name': 'EIGEN', 'update': 'OFF'})

SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#Generate the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles(combo=1)

SVL.renderData('Phase-1')

#==============================================================================
# SECOND PHASE - BUILDING CONSTRUCTION
#==============================================================================
#Create Building Material
SVL.addMaterial(tag=3, name='Elastic1DLinear', attributes={'E': 2.500000E+10, 'nu': 0.2000, 'rho': 2.500000E+03})

#Create Frame Section
SVL.addSection(tag=1, name='Lin2DRectangular', model='Plain', attributes={'material': 3, 'h': 1.00000, 'b': 1.0000})

#Creates Building Nodes
for nTag in data['Edges']['Node'][100]:
    p = data['Vertices'][nTag-1]
    SVL.addNode(tag=nTag, ndof=3, coords=[p[0], p[1]])

#Constraints Foundation (47) and Building (100) Nodes
cTag = -1
for sTag in data['Edges']['Node'][100]:
    p  = data['Vertices'][sTag-1]
    xp = np.array([p[0], p[1]])
    for mTag in data['Quadrilaterals']['Node'][47]:
        q  = data['Vertices'][mTag-1]
        xq = np.array([q[0], q[1]])
        if np.linalg.norm(xp - xq) < tol:
            cTag -= 1; SVL.addConstraint(tag=cTag, name='Equal', attributes={'stag': sTag, 'sdof': 1, 'mtag': [mTag], 'mdof': [1]})
            cTag -= 1; SVL.addConstraint(tag=cTag, name='Equal', attributes={'stag': sTag, 'sdof': 2, 'mtag': [mTag], 'mdof': [2]})

#Creates Building (100) Elements
build = list()
for eTag in data['Edges']['Elem'][100]:
    eTags += 1
    c = data['Edges']['Data'][eTag]
    SVL.addElement(tag=eTags, conn=[c[0], c[1]], name='lin2DFrame2', attributes={'section': 1, 'formulation': 'bernoulli', 'rule': 'Gauss', 'np': 5})
    build.append(eTags)

#Create Gravitational function
SVL.addFunction(tag=2, name='CONSTANT', attributes={'mag': 9.8, 'dir': [0.0, -1.0]})

#Create a Load
SVL.addLoad(tag=2, name='ElementLoad', attributes={'fun': 2, 'type': 'Body', 'list': build})

#Create a Combination
SVL.addCombinationCase(tag=2, name='Phase-2', attributes={'load': [2], 'factor': [1.0]})

#Create Analysis
SVL.addAnalysis(tag=2, attributes={'name': 'Static', 'nt': 100})
SVL.addAlgorithm(tag=2, attributes={'name': 'Linear', 'nstep': 1})
SVL.addIntegrator(tag=2, attributes={'name': 'Static'})
SVL.addSolver(tag=2, attributes={'name': 'MUMPS', 'option': 'SPD', 'update': 'OFF'})
#SVL.addSolver(tag=2, attributes={'name': 'EIGEN', 'update': 'OFF'})

SVL.addSimulation(tag=2, combo=2, attributes={'analysis': 2, 'algorithm': 2, 'integrator': 2, 'solver': 2})

#Generate the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles(combo=2)

SVL.renderData('Phase-2')

#==============================================================================
# THIRD PHASE - DYNAMIC LOAD
#==============================================================================
#The Perfectly-Matched Nodes
nTags = set() 
for pTag in [49,50,51,52,53]:
    nTags.update(data['Quadrilaterals']['Node'][pTag])

for nTag in nTags:
    p = data['Vertices'][nTag-1]
    SVL.addNode(tag=nTag, ndof=5, coords=[p[0], p[1]])

#Fix and Realease Boundaries
for nTag in data['Edges']['Node'][54]:
    SVL.delRestrain(tag=nTag, dof=[1,2])

for nTag in data['Edges']['Node'][56]:
    SVL.addRestrain(tag=nTag, dof=[1,2])

#Constraints PML (55) and Soil (54) Nodes
for sTag in data['Edges']['Node'][55]:
    p  = data['Vertices'][sTag-1]
    xp = np.array([p[0], p[1]])
    for mTag in data['Edges']['Node'][54]:
        q  = data['Vertices'][mTag-1]
        xq = np.array([q[0], q[1]])
        if np.linalg.norm(xp - xq) < tol:
            cTag -= 1; SVL.addConstraint(tag=cTag, name='Equal', attributes={'stag': mTag, 'sdof': 1, 'mtag': sTag, 'mdof': 1})
            cTag -= 1; SVL.addConstraint(tag=cTag, name='Equal', attributes={'stag': mTag, 'sdof': 2, 'mtag': sTag, 'mdof': 2})

#The Perfectly-Matched Elements
L = 40.0
R = 1.0E-03
for pTag in [49,50,51,52,53]:
    x0   = []
    npml = []
    for eTag in data['Quadrilaterals']['Elem'][pTag]:
        c = data['Quadrilaterals']['Data'][eTag]
        if pTag == 49:
            x0   = [-xpml, -zpml/2.0]
            npml = [-1.0, 0.0]
        elif pTag == 50:
            x0   = [-xpml, -zpml]
            npml = [-0.70710678118, -0.70710678118]
        elif pTag == 51:
            x0   = [0.0, -zpml]
            npml = [0.0, -1.0]
        elif pTag == 52:
            x0   = [xpml, -zpml]
            npml = [0.70710678118, -0.70710678118]
        elif pTag == 53:
            x0   = [xpml, -zpml/2.0]
            npml = [1.0, 0.0]
        eTags += 1
        SVL.addElement(tag=eTags, conn=[c[0], c[1], c[2], c[3]], name='PML2DQuad4', attributes={'material': 1, 'th': th, 'n': 2.0, 'L': L, 'R': R, 'x0': x0, 'npml': npml, 'rule': 'Gauss', 'np': 4})

#Generate the DRM files for General Wave Case
SVL.WritePlaneWaveFile(DRM)

#Create function
SVL.addFunction(tag=3, name='TimeSeries', attributes={'material': [1], 'layer': [0.0], 'file': DRM['filename'], 'x0': DRM['x0'], 'df': 0.2, 'CutOffFrequency': 15.0, 'option': DRM['wave'], 'theta': DRM['theta'], 'phi': DRM['phi']})


#Create DRM load
SVL.addLoad(tag=3, name='ElementLoad', attributes={'fun': 3, 'type': 'PlaneWave', 'list': DRM['Elements']})

#Create a Combination
SVL.addCombinationCase(tag=3, name='Phase-3', attributes={'load': [3], 'factor': [1.0]})

#Create Analysis
SVL.addAnalysis(tag=3, attributes={'name': 'Dynamic', 'nt': nt})
SVL.addAlgorithm(tag=3, attributes={'name': 'Linear', 'nstep': 1})
SVL.addIntegrator(tag=3, attributes={'name': 'Newmark', 'dt': dt})
SVL.addSolver(tag=3, attributes={'name': 'MUMPS', 'option': 'SYM', 'update': 'OFF'})
#SVL.addSolver(tag=3, attributes={'name': 'EIGEN', 'update': 'OFF'})

SVL.addSimulation(tag=3, combo=3, attributes={'analysis': 3, 'algorithm': 3, 'integrator': 3, 'solver': 3})

SVL.CreateRunAnalysisFiles(combo=3)

SVL.renderData('Phase-3')
