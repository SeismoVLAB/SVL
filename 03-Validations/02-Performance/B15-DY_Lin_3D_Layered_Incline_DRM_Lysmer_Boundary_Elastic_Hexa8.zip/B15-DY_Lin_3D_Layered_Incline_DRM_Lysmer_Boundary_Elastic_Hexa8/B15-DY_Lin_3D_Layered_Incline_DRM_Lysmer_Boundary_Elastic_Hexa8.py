"""
"""
import numpy as np
import matplotlib.pyplot as plt
from Core import SeismoVLAB as SVL

#Model Options
SVL.Options['file'] = 'Performance_B09'
SVL.Options['nparts'] = 2
SVL.Options['massform'] = 'Lumped'
SVL.Options['dimension'] = 3

#Import a pre-defined domain
Lx = 120.0
Ly = 120.0
Lz = 60.0
dh = 5.0 #3
yn = -20.0

attributes = {
    'ne': [int(Lx/dh), int(Ly/dh), int(Lz/dh)],
    'ndof': 3, 
    'P0': [-Lx/2, -Ly/2, -Lz], 
    'P1': [ Lx/2, -Ly/2, -Lz], 
    'P2': [-Lx/2,  Ly/2, -Lz], 
    'P3': [-Lx/2, -Ly/2, 0.0], 
    'class': 'LIN3DHEXA8',
    'elems': 'HEXA8',
    'attributes': {'rule': 'Gauss','np': 8, 'material': 2}
}

Soil = SVL.makeDomainVolume(options=attributes)

#Appends Lysmer to Soil Boundary
SVL.setLysmerDomain(Soil, bc=['bottom','left','right','front','back'], mat = [3,3,4])

#Find DRM Nodes and Elements
x0 = np.array([ 0.0, 0.0, 0.0])
xl = np.array([50.1, 50.1, 50.0])
SVL.setDRMDomain(Soil, x0, xl)

#The Domain Reduction Information 
DRM = {
    'theta': 15.0, 
    'phi': 30.0, 
    'x0': [0.0, 0.0, 0.0], 
    'wave': 'SV',
    'field': 'VEL',
    'filename': 'Signal.txt',
    'dt': 0.0025,
    'Ts': 20.0, 
    't': [], 
    'signal': [], 
    'Interior': Soil['DRM']['Interior'], 
    'Exterior': Soil['DRM']['Exterior'], 
    'Elements': Soil['DRM']['Elements']
}

#Create a Ricker signal for DRM
options = {'to': 1.50, 'f0': 1.0, 'dt': DRM['dt'], 'Ap': 0.1, 'Ts': DRM['Ts']}
DRM['t'], DRM['signal'] = SVL.Ricker(options, DRM['field'])

SVL.WritePlaneWaveFile(DRM)

#Half-Space Parameters
Vs = 200.0
nu = 0.250
rho = 2000.0
Vp  = Vs*np.sqrt(2.0*(1.0 - nu)/(1.0 - 2.0*nu))

#Surface control points for recorders
xp = np.array([[-40.0, 0.0, 0.0], [0.0,0.0,0.0], [40.0, 0.0, 0.0]])
cPoints = SVL.Coords2Tag(Soil, xp, 1E-3)

#Create Material
SVL.addMaterial(tag=1, name='Elastic3DLinear', attributes={'E': 2.0*(1 + nu)*rho*(0.5*Vs)**2, 'nu': nu, 'rho': rho})
SVL.addMaterial(tag=2, name='Elastic3DLinear', attributes={'E': 2.0*(1 + nu)*rho*Vs**2, 'nu': nu, 'rho': rho})
SVL.addMaterial(tag=3, name='Viscous1DLinear', attributes={'eta': rho*Vs*dh*dh})
SVL.addMaterial(tag=4, name='Viscous1DLinear', attributes={'eta': rho*Vp*dh*dh})

#Create Nodes
SVL.Entities['Nodes'] = Soil['Nodes']

#Create Element
for eTag in Soil['Elements']:
    nodes = Soil['Elements'][eTag]['conn']
    xcm = np.array([0.0,0.0,0.0])
    for nTag in nodes:
        xcm += Soil['Nodes'][nTag]['coords']
    if((xcm[2]/8.0 > yn) and (Soil['Elements'][eTag]['name'] == 'LIN3DHEXA8')):
        Soil['Elements'][eTag]['attributes']['material'] = 1

SVL.Entities['Elements'] = Soil['Elements']

#Create function
SVL.addFunction(tag=1, name='TimeSeries', attributes={'material': [1,2], 'layer': [0.0, yn], 'file': DRM['filename'], 'x0': [0.0, 0.0, 0.0], 'df': 0.2, 'CutOffFrequency': 10.0, 'option': 'SV', 'theta': DRM['theta'], 'phi': DRM['phi']})

#Create DRM load
SVL.addLoad(tag=1, name='ElementLoad', attributes={'fun': 1, 'type': 'PlaneWave', 'list': DRM['Elements']})

#Create a Combination
SVL.addCombinationCase(tag=1, name='PlaneWaveDRM', attributes={'load': [1], 'factor': [1.0]})

#Create Recorder
SVL.addRecorder(tag=1, attributes={'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8, 'nsamp': 5})
SVL.addRecorder(tag=2, attributes={'name': 'NODE', 'file': 'DispControlPoints.out', 'ndps': 8, 'resp': 'disp', 'list': cPoints})
SVL.addRecorder(tag=3, attributes={'name': 'NODE', 'file': 'VelsControlPoints.out', 'ndps': 8, 'resp': 'vel', 'list':  cPoints})
SVL.addRecorder(tag=4, attributes={'name': 'NODE', 'file': 'AccelControlPoints.out', 'ndps': 8, 'resp': 'accel', 'list':  cPoints})

#Creates the simulation
SVL.addAnalysis(tag=1, attributes={'name': 'Dynamic', 'nt': 1500})
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': DRM['dt']})
SVL.addSolver(tag=1, attributes={'name': 'MUMPS', 'option': 'SYM', 'update': 'OFF'})
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#Generate the SVL Run-Analysis Files
SVL.CreateRunAnalysisFiles()

SVL.renderData()
