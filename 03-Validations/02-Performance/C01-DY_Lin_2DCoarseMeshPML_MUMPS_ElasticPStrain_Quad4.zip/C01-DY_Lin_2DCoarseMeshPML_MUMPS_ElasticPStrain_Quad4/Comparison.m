p1 = dlmread('./Solution/PML2D/Velocity.0.out','', 2, 0);
p2 = dlmread('./Solution/PML2D/Velocity.3.out','', 3, 0);
%p3 = dlmread('./Solution/PML2D/Velocity.3.out','', 2, 0);

dt = 0.01;
t = dt:dt:(10.0-dt);

subplot(1,2,1)
plot(t,p1(:,1),t,p2(:,1),t,p2(:,3), 'Linewidth', 2);
grid on;
xlabel('$t\;[s]$');
ylabel('$v_x(\cdot,t)\;[m/s]$');
legend('$x_0 = (0, 100)$','$x_1 = (26.5, 100)$','$x_{2} = (63.75, 100)$')

subplot(1,2,2)
plot(t,p1(:,2),t,p2(:,2),t,p2(:,4), 'Linewidth', 2);
grid on;
xlabel('$t\;[s]$');
ylabel('$v_z(\cdot,t)\;[m/s]$');
legend('$x_0 = (0, 100)$','$x_1 = (26.5, 100)$','$x_{2} = (63.75, 100)$')
