"""

"""
from Core import SeismoVLAB as SVL

#==============================================================================
# [1] GLOBAL MODEL SETTINGS
#==============================================================================
SVL.Options['file'] = 'Debugging_H09'
SVL.Options['format'] = 'svl'
SVL.Options['nparts'] = 2
SVL.Options['dimension'] = 3

#==============================================================================
# [2] CREATES THE FINITE ELEMENT MODEL
#==============================================================================
#Create Material
SVL.addDamping(tag=1, name='Rayleigh', attributes={'am': 0.0000, 'ak': 0.0200, 'list': 'ALL'})

#Create Material
SVL.addMaterial(tag=1, name='Elastic2DPlaneStress', attributes={'E': 3.5E+04, 'nu': 0.33, 'rho': 0.10})

#Create Section
SVL.addSection(tag=1, name='Lin3DThinArea', model='Plain', attributes={'material': 1, 'th': 1.00})

#Create Nodes (for quads)
SVL.addNode(tag=1, ndof=6, coords=[0.00000, 0.00000, 0.00000])
SVL.addNode(tag=2, ndof=6, coords=[1.00000, 0.00000, 0.00000])
SVL.addNode(tag=3, ndof=6, coords=[2.00000, 0.00000, 0.00000])
SVL.addNode(tag=4, ndof=6, coords=[3.00000, 0.00000, 0.00000])
SVL.addNode(tag=5, ndof=6, coords=[4.00000, 0.00000, 0.00000])
SVL.addNode(tag=6, ndof=6, coords=[5.00000, 0.00000, 0.00000])
SVL.addNode(tag=7, ndof=6, coords=[6.00000, 0.00000, 0.00000])
SVL.addNode(tag=8, ndof=6, coords=[7.00000, 0.00000, 0.00000])
SVL.addNode(tag=9, ndof=6, coords=[8.00000, 0.00000, 0.00000])
SVL.addNode(tag=10, ndof=6, coords=[9.00000, 0.00000, 0.00000])
SVL.addNode(tag=11, ndof=6, coords=[10.00000, 0.00000, 0.00000])
SVL.addNode(tag=12, ndof=6, coords=[0.00000, 0.00000, 1.00000])
SVL.addNode(tag=13, ndof=6, coords=[1.00000, 0.00000, 1.00000])
SVL.addNode(tag=14, ndof=6, coords=[2.00000, 0.00000, 1.00000])
SVL.addNode(tag=15, ndof=6, coords=[3.00000, 0.00000, 1.00000])
SVL.addNode(tag=16, ndof=6, coords=[4.00000, 0.00000, 1.00000])
SVL.addNode(tag=17, ndof=6, coords=[5.00000, 0.00000, 1.00000])
SVL.addNode(tag=18, ndof=6, coords=[6.00000, 0.00000, 1.00000])
SVL.addNode(tag=19, ndof=6, coords=[7.00000, 0.00000, 1.00000])
SVL.addNode(tag=20, ndof=6, coords=[8.00000, 0.00000, 1.00000])
SVL.addNode(tag=21, ndof=6, coords=[9.00000, 0.00000, 1.00000])
SVL.addNode(tag=22, ndof=6, coords=[10.00000, 0.00000, 1.00000])

#Restrain degree of freedom
SVL.addRestrain(tag=1, dof=[1,2,3,4,5,6])
SVL.addRestrain(tag=12, dof=[1,2,3,4,5,6])

#Create Element
SVL.addElement(tag=1, conn=[ 1, 12, 13, 2], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=2, conn=[ 2, 13, 14, 3], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=3, conn=[ 3, 14, 15, 4], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=4, conn=[ 4, 15, 16, 5], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=5, conn=[ 5, 16, 17, 6], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=6, conn=[ 6, 17, 18, 7], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=7, conn=[ 7, 18, 19, 8], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=8, conn=[ 8, 19, 20, 9], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=9, conn=[ 9, 20, 21, 10], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})
SVL.addElement(tag=10, conn=[10, 21, 22, 11], name='lin3dshell4', attributes={'section': 1, 'rule': 'Gauss', 'np': 9})

#Create function
SVL.addFunction(tag=1, name='TimeSerie', attributes={'file': 'PointLoad.txt', 'dir': [0.0, 0.0, -1.0, 0.0, 0.0, 0.0]})

#Create a Load
SVL.addLoad(tag=1, name='PointLoad', attributes={'fun': 1, 'type': 'TimeSerie', 'list': [11, 12]})

#Create a Combination
SVL.addCombinationCase(tag=1, name='CantileverShellBeam', attributes={'load': [1], 'factor': [1.0]})

#==============================================================================
# [3] CREATES OUTPUT FILES
#==============================================================================
#Create Recorder
SVL.addRecorder(tag=1, attributes={'name': 'NODE', 'file': 'Displacement.out', 'ndps': 8, 'resp': 'disp', 'list': [25, 26, 32]})
SVL.addRecorder(tag=2, attributes={'name': 'ELEMENT', 'file': 'InternalForce.out', 'ndps': 8, 'resp': 'InternalForce', 'list': [1]})
SVL.addRecorder(tag=3, attributes={'name': 'PARAVIEW', 'file': 'Animation.out', 'ndps': 8})

#==============================================================================
# [4] CREATES A SIMULATION
#==============================================================================
#Create Analysis
SVL.addAnalysis(tag=1, attributes={'name': 'Static', 'nt': 230})

#Create Algorithm
SVL.addAlgorithm(tag=1, attributes={'name': 'Linear', 'nstep': 1})

#Create Integrator
SVL.addIntegrator(tag=1, attributes={'name': 'Newmark', 'dt': 0.02})

#Create Solver
SVL.addSolver(tag=1, attributes={'name': 'Mumps', 'option': 'SPD', 'update': 'OFF'})

#Create Simulation
SVL.addSimulation(tag=1, combo=1, attributes={'analysis': 1, 'algorithm': 1, 'integrator': 1, 'solver': 1})

#==============================================================================
# [5] SET-UP THE FINITE ELEMENT MODEL
#==============================================================================
#Check if the model is properly done
SVL.checkWarnings()

#Set degree of freedom
SVL.setDegreeOfFreedom(plot=False)

#Generate the Entities group
SVL.createPartitions()

print(SVL.Options['run'])

#Other interesting stuff
SVL.renderData('element')
#SVL.printAll('Nodes')
